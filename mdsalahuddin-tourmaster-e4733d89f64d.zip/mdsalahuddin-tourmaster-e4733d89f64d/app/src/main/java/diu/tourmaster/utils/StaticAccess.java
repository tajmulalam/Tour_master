package diu.tourmaster.utils;

import android.os.Environment;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by tajmulalam on 1/13/18.
 */

public class StaticAccess {
    public static final String KEY_PLACE_ID_INTENT = "PLACE_ID";
    public static final String KEY_SIGHT_PLACE_ID_INTENT = "SIGHT_PLACE_ID";
    public static final String FTP_ADDRESS = "ftp://tajmulalam.info/httpdocs/";
    public static final String KEY_ACCOMMODATION_ID_INTENT = "ACCOMMODATION_ID";
    public static final String TRANSPORT_TYPE = "TRANSPORT_TYPE";
    public static final int TAB_BUS = 0;
    public static final int TAB_WATER = 1;
    public static final int TAB_AIR = 2;
    public static final int TAB_TRAIN = 3;
    public static final String KEY_RESTAURANT_ID_INTENT = "RESTAURANT_ID";
    public static final String KEY_NEAREST_TRANSACTION_ID_INTENT = "NEAREST_TRANSACTION_ID";
    public static final String HELPLINE_TYPE = "HELPLINE_TYPE";
    public static final int TAB_POLICE = 0;
    public static final int TAB_TOURIST_PLACE = 1;
    public static final int TAB_FIRE_SERVICE = 2;
    public static final int TAB_HOSPITAL = 3;
    public static final String KEY_PRODUCT_ID_INTENT = "PRODUCT_ID";
    public static final String KEY_CATEGORY_ID_ID_INTENT = "CATEGORY_ID";
    public static final String KEY_VIDEO_LINK_INTENT = "VIDEO_LINK";
    public static final String ROOT_APK_SAVE_PATH = Environment.getExternalStorageDirectory().toString() + "/‌ROCK_UNINSTALLER/APK_BACKUP";

    public static String formatDate(Date date, String format) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        return simpleDateFormat.format(date);
    }

    public static Date convertStringToDate(String date, String format) throws ParseException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        return simpleDateFormat.parse(date);
    }
}
