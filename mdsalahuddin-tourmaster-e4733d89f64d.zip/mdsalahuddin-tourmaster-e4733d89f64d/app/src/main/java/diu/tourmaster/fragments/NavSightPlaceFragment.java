package diu.tourmaster.fragments;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;

import diu.tourmaster.R;
import diu.tourmaster.activities.MainActivity;
import diu.tourmaster.activities.PlaceDetailsActivity;
import diu.tourmaster.activities.SightPlaceDetailsActivity;
import diu.tourmaster.adapters.EmptyAdapter;
import diu.tourmaster.adapters.SightSeeingPlaceListAdapter;
import diu.tourmaster.controllers.CommonController;
import diu.tourmaster.listener.SearchTextGetListener;
import diu.tourmaster.models.SightSeeingPlace;
import diu.tourmaster.models.TourismPlace;
import diu.tourmaster.utils.ConnectionChecker;
import diu.tourmaster.utils.CustomToast;
import diu.tourmaster.utils.StaticAccess;
import diu.tourmaster.utils.StaticInstance;
import diu.tourmaster.utils.Utilities;

/**
 * A simple {@link Fragment} subclass.
 */
public class NavSightPlaceFragment extends Fragment implements SightSeeingPlaceListAdapter.SightSeeingPlaceClickedListener,
        SearchTextGetListener {
    RecyclerView rvSightPlaceList;
    RecyclerView.Adapter adapter;
    private Context mContext;
    private CommonController commonController;
    private int placeID = -1;
    private MainActivity activity;
private SwipeRefreshLayout swSightPlace;
    public NavSightPlaceFragment() {
        // Required empty public constructor
    }

    // newInstance constructor for creating fragment with arguments
    public static NavSightPlaceFragment newInstance(int page, int placeID) {
        NavSightPlaceFragment sightSeeingPlacesFragment = new NavSightPlaceFragment();
        Bundle args = new Bundle();
        args.putInt("someInt", page);
        args.putInt(StaticAccess.KEY_PLACE_ID_INTENT, placeID);
        sightSeeingPlacesFragment.setArguments(args);
        return sightSeeingPlacesFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        initStaticInstance();
        receiveBundle();
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_sight_seeing_places, container, false);
        initUI(view);
        callApi();
        return view;
    }

    private void receiveBundle() {
        mContext = getContext();
        commonController = new CommonController(mContext);
        Bundle bundle = getArguments();
        placeID = bundle != null ? bundle.getInt(StaticAccess.KEY_PLACE_ID_INTENT, -1) : -1;
    }
    private void initStaticInstance() {
        mFilterList = new ArrayList<>();
        staticInstance = StaticInstance.getInstance();
        activity = (MainActivity) getActivity();
        activity.setSearchTextGetListener(this);
    }
    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        activity.setTitle(getString(R.string.sight_places));
    }

    private void callApi() {
        HashMap<String, String> params = Utilities.getInstance().getRequestParams();
        params.put("tourism_place_id", String.valueOf(placeID));
        commonController.callApi(CommonController.REQUEST_SIGHT_SEEING_PLACE_LIST_FROM_NAV, params, true);
    }

    private void initUI(View view) {
        rvSightPlaceList = view.findViewById(R.id.rvSightPlaceList);
        swSightPlace = view.findViewById(R.id.swSightPlace);
        rvSightPlaceList.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mContext);
        rvSightPlaceList.setLayoutManager(layoutManager);
        view.findViewById(R.id.vBlank).setVisibility(View.VISIBLE);
        swSightPlace.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                callApi();
            }
        });
    }

    public void showErrorMsg(String msg) {
        CustomToast.makeToastWarning(mContext, msg);
        rvSightPlaceList.setAdapter(new EmptyAdapter());
        if (swSightPlace.isRefreshing()){
            swSightPlace.setRefreshing(false);
        }

    }
    boolean isInstanceFull = false;
    public void updateSightSeeingPlaceList(List<SightSeeingPlace> placeList) {
        if (placeList != null && placeList.size() > 0) {
            if (!isInstanceFull) {
                staticInstance.setSightPlaceList(placeList);
                isInstanceFull = true;
            }
            adapter = new SightSeeingPlaceListAdapter(mContext, placeList, this);
            rvSightPlaceList.setAdapter(adapter);
            if (swSightPlace.isRefreshing()){
                swSightPlace.setRefreshing(false);
            }
        }
    }

    @Override
    public void sighSeeingPlaceClicked(SightSeeingPlace place) {
        if (ConnectionChecker.isOnline(mContext)) {
            mContext.startActivity(new Intent(mContext, SightPlaceDetailsActivity.class).putExtra(StaticAccess.KEY_SIGHT_PLACE_ID_INTENT, place.getSightseeingPlaceId()));
        }else {
            CustomToast.makeToastWarning(mContext,getString(R.string.no_internet_connection_found_n_check_your_connection));
        }
    }

    @Override
    public void searchText(String keyword) {
        if (TextUtils.isEmpty(keyword)) {
            updateSightSeeingPlaceList(staticInstance.getSightPlaceList());
        } else {
            Log.e("keyword", keyword);
            filterList(keyword);
        }
    }

    @Override
    public void resetSearch() {
        updateSightSeeingPlaceList(staticInstance.getSightPlaceList());
    }
    ///// sumon work start here
    private List<SightSeeingPlace> mFilterList;
    StaticInstance staticInstance;
    /// actual filter method
    public void filterList(String charText) {
        if (charText.length() != 0 && staticInstance.getSightPlaceList() != null && staticInstance.getSightPlaceList().size() > 0) {
            List list = new ArrayList<>();
            ListIterator<SightSeeingPlace> itr = staticInstance.getSightPlaceList().listIterator();
            while (itr.hasNext()) {
                SightSeeingPlace sightSeeingPlace = itr.next();
                if (sightSeeingPlace.getSightseeingPlaceName() != null) {
                    if (sightSeeingPlace.getSightseeingPlaceName().toLowerCase().contains(charText.toLowerCase())) {
                        list.add(sightSeeingPlace);
                    }
                }
            }
            if (mFilterList != null && mFilterList.size() > 0) {
                mFilterList.clear();
            }
            if (list.size() > 0) {
                mFilterList.addAll(list);
            }
        }
        updateSightSeeingPlaceList(mFilterList);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        if (staticInstance != null) {
            staticInstance.clearSightPlaceList();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (staticInstance != null) {
            staticInstance.clearSightPlaceList();
        }
    }
}
