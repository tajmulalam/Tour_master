package diu.tourmaster.utils;

import android.content.Context;
import android.graphics.Color;
import diu.tourmaster.R;
import libs.mjn.prettydialog.PrettyDialog;

/**
 * Created by tajmulalam on 12/29/17.
 */

public class CustomToast {

    public static void makeToast(Context mContext, String title) {
        new PrettyDialog(mContext)
                .setTitle(mContext.getString(R.string.alert))
                .setMessage(title)
                .show();

    }

    public static void makeToastWarning(Context mContext, String title) {
        new PrettyDialog(mContext)
                .setTitle(mContext.getString(R.string.alert))
                .setMessage(title)
                .show();
    }
}
