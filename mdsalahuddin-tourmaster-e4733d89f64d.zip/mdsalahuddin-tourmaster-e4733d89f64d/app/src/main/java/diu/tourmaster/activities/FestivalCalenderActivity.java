package diu.tourmaster.activities;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.design.widget.BaseTransientBottomBar;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CalendarView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;
import com.prolificinteractive.materialcalendarview.OnDateSelectedListener;
import com.prolificinteractive.materialcalendarview.OnMonthChangedListener;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.controllers.CommonController;
import diu.tourmaster.models.Festival;
import diu.tourmaster.utils.CustomToast;
import diu.tourmaster.utils.StaticAccess;
import diu.tourmaster.utils.ToolbarConfig;
import diu.tourmaster.utils.Utilities;

import static com.prolificinteractive.materialcalendarview.MaterialCalendarView.SELECTION_MODE_MULTIPLE;
import static com.prolificinteractive.materialcalendarview.MaterialCalendarView.SELECTION_MODE_SINGLE;

public class FestivalCalenderActivity extends BaseActivity {
    private FestivalCalenderActivity activity;
    private MaterialCalendarView cvFestival;
    private LinearLayout lnFestivalDes;
    private List<Festival> mFestivalList;
    //private TextView tvFestivalDes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BaseActivity.setLocale(this);

        setContentView(R.layout.activity_festival_calender);
        activity = this;
        initToolbar();
        initUI();
        apiCall(StaticAccess.formatDate(new Date(), "MM/dd/yyyy"));
    }

    private void apiCall(String reqDate) {
        HashMap<String, String> params = Utilities.getInstance().getRequestParams();
        params.put("festival_at", reqDate);
        new CommonController(activity).callApi(CommonController.REQUEST_FESTIVALS, params, true);
    }

    private void initUI() {
        mFestivalList = new ArrayList<>();
//        commonController = new CommonController(activity);
        cvFestival = findViewById(R.id.cvFestival);
        //cvFestival.setOnDateChangeListener(onDateChangeListener);
        lnFestivalDes = findViewById(R.id.lnFestivalDes);

        //tvFestivalDes = findViewById(R.id.tvFestivalDes);

        cvFestival.setOnDateChangedListener(new OnDateSelectedListener() {
            @Override
            public void onDateSelected(@NonNull MaterialCalendarView widget, @NonNull CalendarDay date, boolean selected) {
                List<Festival> festivalList = getFestivalByDate(StaticAccess.formatDate(date.getDate(), "MM/dd/yyyy"));
                updateUIByFestivals(festivalList);
            }

        });
        cvFestival.setOnMonthChangedListener(new OnMonthChangedListener() {
            @Override
            public void onMonthChanged(MaterialCalendarView widget, CalendarDay date) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                lnFestivalDes.removeAllViews();
                                initializeCalendar(mFestivalList);

                            }
                        });
                    }
                }).start();
            }
        });
    }

    private void updateUIByFestivals(List<Festival> festivalList) {
        lnFestivalDes.removeAllViews();
        if (festivalList != null && festivalList.size() > 0) {
            for (Festival fes : festivalList) {
                TextView textView = new TextView(activity);
                textView.setTextColor(Color.WHITE);
                textView.setPadding(10, 10, 10, 10);
                textView.setTextSize(18);
                textView.setText(fes.getDescription());
                LinearLayout linearLayout = new LinearLayout(activity);
                LinearLayout.LayoutParams layoutParams1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                layoutParams1.setMargins(10, 10, 10, 10);
                linearLayout.setLayoutParams(layoutParams1);
                linearLayout.setBackgroundResource(R.drawable.ic_location_bg);
                linearLayout.addView(textView);
                lnFestivalDes.addView(linearLayout);
                /*View view = new View(activity);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1);
                layoutParams.setMargins(0, 5, 5, 0);
                view.setLayoutParams(layoutParams);
                view.setBackgroundColor(Color.WHITE);
                lnFestivalDes.addView(view);*/
            }
        }

    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle(getString(R.string.festival_calender));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishTheActivity();
            }
        });
        ToolbarConfig.makeStatusBarTransparent(getWindow());

    }

    private void finishTheActivity() {
        finish();
    }

    CalendarView.OnDateChangeListener onDateChangeListener = new CalendarView.OnDateChangeListener() {
        @Override
        public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
            Calendar calendar = Calendar.getInstance();
            calendar.set(year, month, dayOfMonth);
            String dateTime = calendar.getTime().toString();
            Snackbar.make(cvFestival, dateTime, BaseTransientBottomBar.LENGTH_LONG).show();
            apiCall(StaticAccess.formatDate(calendar.getTime(), "MM/dd/yyyy"));

        }
    };

    public void showErrorMsg(String msg) {
        CustomToast.makeToastWarning(activity, msg);

    }

    public void updateList(List<Festival> festivalList) {
        this.mFestivalList = festivalList;
        //festivalList = getFestivalByDate(StaticAccess.formatDate(new Date(), "MM/dd/yyyy"));
        //updateUIByFestivals(festivalList);
        initializeCalendar(festivalList);
    }

    private void initializeCalendar(List<Festival> festivalList) {
        cvFestival.setSelectionMode(SELECTION_MODE_SINGLE); // Removes onClick functionality
        if (festivalList != null && festivalList.size() > 0) {
            for (Festival festival : festivalList) {
                try {
                    Date date = StaticAccess.convertStringToDate(festival.getFestivalAt(), "MM/dd/yyyy");
                    cvFestival.setDateSelected(date, true);
                    cvFestival.setSelectionColor(ContextCompat.getColor(activity, R.color.colorAccent));

                } catch (ParseException e) {

                }
            }
        }
        /*cvFestival.setDateSelected(Calendar.getInstance().getTime(), true);
        cvFestival.setSelectionColor(Color.GREEN);*/

    }

    private List<Festival> getFestivalByDate(String date) {
        List<Festival> festivalList = new ArrayList<>();

        for (Festival festival : mFestivalList) {
            try {
                if (StaticAccess.convertStringToDate(festival.getFestivalAt(), "MM/dd/yyyy").equals(StaticAccess.convertStringToDate(date, "MM/dd/yyyy"))) {
                    festivalList.add(festival);
                }
            } catch (ParseException e) {

            }
        }
        return festivalList;
    }
}
