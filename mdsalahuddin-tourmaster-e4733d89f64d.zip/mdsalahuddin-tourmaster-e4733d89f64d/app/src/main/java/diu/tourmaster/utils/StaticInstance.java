package diu.tourmaster.utils;

import android.util.Log;

import java.util.List;

import diu.tourmaster.models.Accommodation;
import diu.tourmaster.models.NearestTransaction;
import diu.tourmaster.models.Restaurant;
import diu.tourmaster.models.SightSeeingPlace;
import diu.tourmaster.models.TourProduct;
import diu.tourmaster.models.TourismPlace;
import diu.tourmaster.models.TravelAgent;
import diu.tourmaster.models.VideoCategory;

/**
 * Created by Md Tajmul Alam on 1/25/2018.
 */

public class StaticInstance {
    private static StaticInstance staticInstance;
    private List<TourismPlace> placeList;
    private List<SightSeeingPlace> sightPlaceList;
    private List<Accommodation> accommodationList;
    private List<Restaurant> restaurantList;
    private List<TravelAgent> travelAgentList;
    private List<TourProduct> tourProductList;
    private List<NearestTransaction> nearestTransactionList;
    private List<VideoCategory> videoCategoryList;

    public static StaticInstance getInstance() {
        if (staticInstance == null) {
            staticInstance = new StaticInstance();
            return staticInstance;
        } else {
            return staticInstance;
        }
    }

    public void setPlaceList(List<TourismPlace> placeList) {
        this.placeList = placeList;
    }

    public List<TourismPlace> getPlaceList() {
        return placeList;
    }

    public void clearPlaceList() {
        this.placeList = null;
        Log.e("list", "Clear");

    }

    public void setSightPlaceList(List<SightSeeingPlace> sightPlaceList) {
        this.sightPlaceList = sightPlaceList;
    }

    public List<SightSeeingPlace> getSightPlaceList() {
        return sightPlaceList;
    }

    public void clearSightPlaceList() {
        this.sightPlaceList = null;
        Log.e("list", "Clear");

    }

    public void setAccommodationList(List<Accommodation> accommodationList) {
        this.accommodationList = accommodationList;
    }

    public List<Accommodation> getAccommodationList() {
        return accommodationList;
    }

    public void clearAccommodationList() {
        this.accommodationList = null;
        Log.e("list", "Clear");

    }

    public void setRestaurantList(List<Restaurant> restaurantList) {
        this.restaurantList = restaurantList;
    }

    public List<Restaurant> getRestaurantList() {
        return restaurantList;
    }

    public void clearRestaurantList() {
        this.restaurantList = null;
        Log.e("list", "Clear");

    }

    public void setTravelAgentList(List<TravelAgent> travelAgentList) {
        this.travelAgentList = travelAgentList;
    }

    public List<TravelAgent> getTravelAgentList() {
        return travelAgentList;
    }

    public void clearTravelAgentsList() {
        this.travelAgentList = null;
        Log.e("list", "Clear");

    }

    public void setTourProductList(List<TourProduct> tourProductList) {
        this.tourProductList = tourProductList;
    }

    public List<TourProduct> getTourProductList() {
        return tourProductList;
    }

    public void clearTourProductList() {
        this.tourProductList = null;
        Log.e("list", "Clear");

    }

    public void setNearestTransactionList(List<NearestTransaction> nearestTransactionList) {
        this.nearestTransactionList = nearestTransactionList;
    }

    public List<NearestTransaction> getNearestTransactionList() {
        return nearestTransactionList;
    }

    public void clearNearestTransactionList() {
        this.nearestTransactionList = null;
        Log.e("list", "Clear");

    }

    public void setVideoCategoryList(List<VideoCategory> videoCategoryList) {
        this.videoCategoryList = videoCategoryList;
    }

    public List<VideoCategory> getVideoCategoryList() {
        return videoCategoryList;
    }

    public void clearVideoCategoryList() {
        this.videoCategoryList = null;
        Log.e("list", "Clear");

    }

    public void clearAll() {
        this.placeList = null;
        this.sightPlaceList = null;
        this.accommodationList = null;
        this.restaurantList = null;
        this.travelAgentList = null;
        this.tourProductList = null;
        this.nearestTransactionList = null;
        this.videoCategoryList = null;

    }
}
