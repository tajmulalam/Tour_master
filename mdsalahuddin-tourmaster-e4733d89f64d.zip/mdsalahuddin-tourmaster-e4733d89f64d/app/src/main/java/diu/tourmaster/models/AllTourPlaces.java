package diu.tourmaster.models;

import java.util.List;

/**
 * Created by tajmulalam on 1/12/18.
 */

public class AllTourPlaces {
    private String success;
    private String message;
    private List<TourismPlace> tourismPlaces = null;

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<TourismPlace> getTourismPlaces() {
        return tourismPlaces;
    }

    public void setTourismPlaces(List<TourismPlace> tourismPlaces) {
        this.tourismPlaces = tourismPlaces;
    }

}
