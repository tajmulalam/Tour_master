package diu.tourmaster.activities;

import android.content.Intent;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.miguelcatalan.materialsearchview.MaterialSearchView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;

import diu.tourmaster.R;
import diu.tourmaster.adapters.AccommodationListAdapter;
import diu.tourmaster.adapters.EmptyAdapter;
import diu.tourmaster.adapters.TourProductListAdapter;
import diu.tourmaster.controllers.CommonController;
import diu.tourmaster.models.Accommodation;
import diu.tourmaster.models.TourProduct;
import diu.tourmaster.models.TravelAgent;
import diu.tourmaster.utils.ConnectionChecker;
import diu.tourmaster.utils.CustomToast;
import diu.tourmaster.utils.StaticAccess;
import diu.tourmaster.utils.StaticInstance;
import diu.tourmaster.utils.ToolbarConfig;
import diu.tourmaster.utils.Utilities;

public class TourProductsActivity extends BaseActivity implements TourProductListAdapter.TourProductClickedListener {
    private TourProductsActivity activity;
    private RecyclerView rvTourProductList;
    private RecyclerView.Adapter adapter;
    private CommonController commonController;
    private int placeID = -1;
    private MaterialSearchView searchView;
    private List<TourProduct> mList;
private SwipeRefreshLayout swProducts;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BaseActivity.setLocale(this);

        setContentView(R.layout.activity_tour_products);
        activity = this;
        initStaticInstance();
        receiveBundle();
        initToolbar();
        initUI();
        callApi();
    }

    private void initStaticInstance() {
        mList = new ArrayList<>();
        mFilterList = new ArrayList<>();
        staticInstance = StaticInstance.getInstance();
    }

    private void receiveBundle() {
        placeID = getIntent() != null ? getIntent().getIntExtra(StaticAccess.KEY_PLACE_ID_INTENT, -1) : -1;
    }

    private void callApi() {
        HashMap<String, String> params = Utilities.getInstance().getRequestParams();
        params.put("tourism_place_id", String.valueOf(placeID));
        commonController.callApi(CommonController.REQUEST_TOUR_PRODUCTS_BY_PLACE_ID, params, true);
    }


    private void initUI() {
        commonController = new CommonController(activity);
        searchView = (MaterialSearchView) findViewById(R.id.search_view);
        searchView.setOnQueryTextListener(onQueryTextListener);
        searchView.setOnSearchViewListener(searchViewListener);

        rvTourProductList = findViewById(R.id.rvTourProductList);
        swProducts = findViewById(R.id.swProducts);
        rvTourProductList.setHasFixedSize(true);
        rvTourProductList.setLayoutManager(new LinearLayoutManager(activity));
        swProducts.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                callApi();
            }
        });
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle(getString(R.string.tourism_product));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishTheActivity();
            }
        });
        ToolbarConfig.makeStatusBarTransparent(getWindow());

    }

    private void finishTheActivity() {
        finish();
    }

    boolean isInstanceFull = false;

    public void updateTourProductList(List<TourProduct> tourProductList) {
        this.mList = tourProductList;
        if (!isInstanceFull) {
            staticInstance.setTourProductList(tourProductList);
            isInstanceFull = true;
        }
        adapter = new TourProductListAdapter(activity, tourProductList, this);
        rvTourProductList.setAdapter(adapter);
        if (swProducts.isRefreshing()){
            swProducts.setRefreshing(false);
        }

    }

    public void showErrorMsg(String msg) {
        CustomToast.makeToastWarning(activity, msg);
        rvTourProductList.setAdapter(new EmptyAdapter());
        if (swProducts.isRefreshing()){
            swProducts.setRefreshing(false);
        }

    }

    @Override
    public void tourProductClicked(TourProduct tourProduct) {
        if (ConnectionChecker.isOnline(activity)) {
            Intent intent = new Intent(activity, TourProductDetailsActivity.class);
            intent.putExtra(StaticAccess.KEY_PRODUCT_ID_INTENT, tourProduct.getProductId());
            intent.putExtra(StaticAccess.KEY_PLACE_ID_INTENT, placeID);
            startActivity(intent);
            finish();
        }else {
            CustomToast.makeToastWarning(activity,getString(R.string.no_internet_connection_found_n_check_your_connection));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        MenuItem item = menu.findItem(R.id.action_search);
        searchView.setMenuItem(item);
        return true;
    }

    public void visibleSearchBar() {
        searchView.setVisibility(View.VISIBLE);
    }

    public void makeSearchBarGone() {
        searchView.setVisibility(View.GONE);
    }

    MaterialSearchView.OnQueryTextListener onQueryTextListener = new MaterialSearchView.OnQueryTextListener() {
        @Override
        public boolean onQueryTextSubmit(String query) {
            searchInList(query);
            return false;
        }

        @Override
        public boolean onQueryTextChange(String newText) {
            searchInList(newText);
            return false;
        }
    };

    MaterialSearchView.SearchViewListener searchViewListener = new MaterialSearchView.SearchViewListener() {
        @Override
        public void onSearchViewShown() {

        }

        @Override
        public void onSearchViewClosed() {
            resetSearch();
        }
    };

    private void searchInList(String keyword) {
        if (TextUtils.isEmpty(keyword)) {
            updateTourProductList(staticInstance.getTourProductList());
        } else {
            Log.e("keyword", keyword);
            filterList(keyword);
        }
    }

    public void resetSearch() {
        updateTourProductList(staticInstance.getTourProductList());
    }

    ///// sumon work start here
    private List<TourProduct> mFilterList;
    StaticInstance staticInstance;

    /// actual filter method
    public void filterList(String charText) {
        if (charText.length() != 0 && staticInstance.getTourProductList() != null && staticInstance.getTourProductList().size() > 0) {
            List list = new ArrayList<>();
            ListIterator<TourProduct> itr = staticInstance.getTourProductList().listIterator();
            while (itr.hasNext()) {
                TourProduct tourProduct = itr.next();
                if (tourProduct.getProductName() != null) {
                    if (tourProduct.getProductName().toLowerCase().contains(charText.toLowerCase())) {
                        list.add(tourProduct);
                    }
                }
            }
            if (mFilterList != null && mFilterList.size() > 0) {
                mFilterList.clear();
            }
            if (list.size() > 0) {
                mFilterList.addAll(list);
            }
        }
        updateTourProductList(mFilterList);
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (staticInstance != null) {
            staticInstance.clearTourProductList();
        }
    }


}
