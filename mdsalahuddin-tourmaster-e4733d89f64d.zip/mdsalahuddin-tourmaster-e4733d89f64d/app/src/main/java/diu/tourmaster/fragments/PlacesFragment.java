package diu.tourmaster.fragments;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import diu.tourmaster.R;
import diu.tourmaster.activities.MainActivity;
import diu.tourmaster.activities.PlaceDetailsActivity;
import diu.tourmaster.adapters.EmptyAdapter;
import diu.tourmaster.adapters.PlaceListAdapter;
import diu.tourmaster.controllers.CommonController;
import diu.tourmaster.listener.PlaceClickListener;
import diu.tourmaster.listener.SearchTextGetListener;
import diu.tourmaster.models.TourismPlace;
import diu.tourmaster.utils.ConnectionChecker;
import diu.tourmaster.utils.CustomToast;
import diu.tourmaster.utils.StaticAccess;
import diu.tourmaster.utils.StaticInstance;
import diu.tourmaster.utils.Utilities;

/**
 * A simple {@link Fragment} subclass.
 */
public class PlacesFragment extends Fragment implements PlaceClickListener, SearchTextGetListener {

    RecyclerView rvPlaceList;
    RecyclerView.Adapter adapter;
    private Context mContext;
    private CommonController commonController;
    private SwipeRefreshLayout swPlace;

    public PlacesFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mContext = getContext();
        commonController = new CommonController(mContext);
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_places, container, false);
        initStaticInstance();
        initUI(view);
        callApi();
        return view;

    }

    private void initStaticInstance() {
        mFilterList = new ArrayList<>();
        staticInstance = StaticInstance.getInstance();
        activity = (MainActivity) getActivity();
        activity.setSearchTextGetListener(this);
    }

    private void callApi() {
        commonController.callApi(CommonController.REQUEST_PLACE_LIST, Utilities.getInstance().getRequestParams(), true);
    }

    private void initUI(View view) {
        rvPlaceList = view.findViewById(R.id.rvPlaceList);
        rvPlaceList.setHasFixedSize(true);
        final RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mContext);
        rvPlaceList.setLayoutManager(layoutManager);
        swPlace = view.findViewById(R.id.swPlace);
        swPlace.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                callApi();
            }

        });
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle(getString(R.string.tourism_places));
    }

    public void showErrorMsg(String msg) {
        CustomToast.makeToastWarning(mContext, msg);
        rvPlaceList.setAdapter(new EmptyAdapter());
        if (swPlace.isRefreshing()) {
            swPlace.setRefreshing(false);
        }

    }

    boolean isInstanceFull = false;

    public void updatePlaceList(List<TourismPlace> placeList) {
        if (placeList != null && placeList.size() > 0) {
            if (!isInstanceFull) {
                staticInstance.setPlaceList(placeList);
                isInstanceFull = true;
            }
            adapter = new PlaceListAdapter(mContext, placeList, this);
            rvPlaceList.setAdapter(adapter);
            if (swPlace.isRefreshing()) {
                swPlace.setRefreshing(false);
            }

        }
    }
    @Override
    public void clickedPlace(TourismPlace place) {
        if (ConnectionChecker.isOnline(mContext)) {
            mContext.startActivity(new Intent(mContext, PlaceDetailsActivity.class).putExtra(StaticAccess.KEY_PLACE_ID_INTENT, place.getTourismPlaceId()));
        }else {
            CustomToast.makeToastWarning(mContext,getString(R.string.no_internet_connection_found_n_check_your_connection));
        }
    }


    @Override
    public void searchText(String keyword) {
        if (TextUtils.isEmpty(keyword)) {
            updatePlaceList(staticInstance.getPlaceList());
        } else {
            Log.e("keyword", keyword);
            filterList(keyword);
        }
    }

    @Override
    public void resetSearch() {
        updatePlaceList(staticInstance.getPlaceList());
    }

    ///// sumon work start here
    private List<TourismPlace> mFilterList;
    MainActivity activity;
    StaticInstance staticInstance;

    /// actual filter method
    public void filterList(String charText) {
        if (charText.length() != 0 && staticInstance.getPlaceList() != null && staticInstance.getPlaceList().size() > 0) {
            List list = new ArrayList<>();
            ListIterator<TourismPlace> itr = staticInstance.getPlaceList().listIterator();
            while (itr.hasNext()) {
                TourismPlace tourismPlace = itr.next();
                if (tourismPlace.getPlaceName() != null) {
                    if (tourismPlace.getPlaceName().toLowerCase().contains(charText.toLowerCase())) {
                        list.add(tourismPlace);
                    }
                }
            }
            if (mFilterList != null && mFilterList.size() > 0) {
                mFilterList.clear();
            }
            if (list.size() > 0) {
                mFilterList.addAll(list);
            }
        }
        updatePlaceList(mFilterList);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        if (staticInstance != null) {
            staticInstance.clearPlaceList();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (staticInstance != null) {
            staticInstance.clearPlaceList();
        }
    }
}
