package diu.tourmaster.fragments;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.HashMap;
import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.activities.PlaceDetailsActivity;
import diu.tourmaster.activities.SightPlaceDetailsActivity;
import diu.tourmaster.adapters.EmptyAdapter;
import diu.tourmaster.adapters.SightSeeingPlaceListAdapter;
import diu.tourmaster.controllers.CommonController;
import diu.tourmaster.models.SightSeeingPlace;
import diu.tourmaster.models.TourismPlace;
import diu.tourmaster.utils.ConnectionChecker;
import diu.tourmaster.utils.CustomToast;
import diu.tourmaster.utils.StaticAccess;
import diu.tourmaster.utils.Utilities;

/**
 * A simple {@link Fragment} subclass.
 */
public class SightSeeingPlacesFragment extends Fragment implements SightSeeingPlaceListAdapter.SightSeeingPlaceClickedListener {
    RecyclerView rvSightPlaceList;
    RecyclerView.Adapter adapter;
    private Context mContext;
    private CommonController commonController;
    private int placeID = -1;
    private PlaceDetailsActivity activity;
    private SwipeRefreshLayout swSightPlace;

    public SightSeeingPlacesFragment() {
        // Required empty public constructor
    }

    // newInstance constructor for creating fragment with arguments
    public static SightSeeingPlacesFragment newInstance(int page, int placeID) {
        SightSeeingPlacesFragment sightSeeingPlacesFragment = new SightSeeingPlacesFragment();
        Bundle args = new Bundle();
        args.putInt("someInt", page);
        args.putInt(StaticAccess.KEY_PLACE_ID_INTENT, placeID);
        sightSeeingPlacesFragment.setArguments(args);
        return sightSeeingPlacesFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mContext = getContext();
        commonController = new CommonController(mContext);
        receiveBundle();
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_sight_seeing_places, container, false);
        initUI(view);
        callApi();
        return view;
    }

    private void receiveBundle() {
        activity = (PlaceDetailsActivity) getActivity();
        commonController = new CommonController(activity);
        Bundle bundle = getArguments();
        placeID = bundle != null ? bundle.getInt(StaticAccess.KEY_PLACE_ID_INTENT, -1) : -1;
    }


    private void callApi() {
        HashMap<String, String> params = Utilities.getInstance().getRequestParams();
        params.put("tourism_place_id", String.valueOf(placeID));
        commonController.callApi(CommonController.REQUEST_SIGHT_SEEING_PLACE_LIST, params, true);
    }

    private void initUI(View view) {
        view.findViewById(R.id.ivBG).setVisibility(View.GONE);
        rvSightPlaceList = view.findViewById(R.id.rvSightPlaceList);
        swSightPlace = view.findViewById(R.id.swSightPlace);
        rvSightPlaceList.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mContext);
        rvSightPlaceList.setLayoutManager(layoutManager);
        swSightPlace.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                callApi();
            }
        });
    }

    public void showErrorMsg(String msg) {
        CustomToast.makeToastWarning(mContext, msg);
        rvSightPlaceList.setAdapter(new EmptyAdapter());
        if (swSightPlace.isRefreshing()){
            swSightPlace.setRefreshing(false);
        }

    }

    public void updateSightSeeingPlaceList(List<SightSeeingPlace> placeList) {
        if (placeList != null && placeList.size() > 0) {
            adapter = new SightSeeingPlaceListAdapter(mContext, placeList, this);
            rvSightPlaceList.setAdapter(adapter);
        }
        if (swSightPlace.isRefreshing()){
            swSightPlace.setRefreshing(false);
        }
    }

    @Override
    public void sighSeeingPlaceClicked(SightSeeingPlace place) {
        if (ConnectionChecker.isOnline(mContext)) {
            mContext.startActivity(new Intent(mContext, SightPlaceDetailsActivity.class).putExtra(StaticAccess.KEY_SIGHT_PLACE_ID_INTENT, place.getSightseeingPlaceId()));
        }else {
            CustomToast.makeToastWarning(mContext, getString(R.string.no_internet_connection_found_n_check_your_connection));

        }
    }
}
