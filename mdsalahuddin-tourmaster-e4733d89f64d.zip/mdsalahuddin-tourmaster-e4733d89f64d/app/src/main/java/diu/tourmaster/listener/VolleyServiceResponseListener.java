package diu.tourmaster.listener;

/**
 * Created by tajmulalam on 1/11/18.
 */

public interface VolleyServiceResponseListener {
    void onNetWorkFailure(String url, String msg);

    void onSuccessResponse(String url, String response);
    void onErrorResponse(String url, String response);
}
