package diu.tourmaster.models;

/**
 * Created by Md Tajmul Alam on 1/16/2018.
 */

public class SliderModel {
    private String sightseeing_place_name;
    private Photos photos;

    public SliderModel() {
    }

    public String getSightseeing_place_name() {
        return sightseeing_place_name;
    }

    public void setSightseeing_place_name(String sightseeing_place_name) {
        this.sightseeing_place_name = sightseeing_place_name;
    }

    public Photos getPhotos() {
        return photos;
    }

    public void setPhotos(Photos photos) {
        this.photos = photos;
    }
}
