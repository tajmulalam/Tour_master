package diu.tourmaster.fragments;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.adapters.EmptyAdapter;
import diu.tourmaster.adapters.HelplineListAdapter;
import diu.tourmaster.adapters.TransportListAdapter;
import diu.tourmaster.controllers.CommonController;
import diu.tourmaster.models.Contact;
import diu.tourmaster.models.Transport;
import diu.tourmaster.utils.CustomToast;
import diu.tourmaster.utils.StaticAccess;
import diu.tourmaster.utils.Utilities;

public class HelplineContactsFragment extends Fragment {
    private int placeID = -1;
    private int helplineType = -1;
    private RecyclerView rvHelplineList;
    private RecyclerView.Adapter adapter;
    private Context mContext;
    private List<Contact> mContactList;
    private SwipeRefreshLayout swHelpline;

    public static HelplineContactsFragment newInstance(int helplineType, int placeID) {
        HelplineContactsFragment fragment = new HelplineContactsFragment();
        Bundle args = new Bundle();
        args.putInt(StaticAccess.HELPLINE_TYPE, helplineType);
        args.putInt(StaticAccess.KEY_PLACE_ID_INTENT, placeID);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_helpline_contacts, container, false);
        receiveArguments();
        initUI(view);
        apiCall();
        return view;
    }

    private void receiveArguments() {
        mContext = getContext();
        mContactList = new ArrayList<>();
        Bundle bundle = getArguments();
        placeID = bundle != null ? bundle.getInt(StaticAccess.KEY_PLACE_ID_INTENT, -1) : -1;
        helplineType = bundle != null ? bundle.getInt(StaticAccess.HELPLINE_TYPE, -1) : -1;
    }

    private void initUI(View view) {
        rvHelplineList = view.findViewById(R.id.rvHelplineList);
        swHelpline = view.findViewById(R.id.swHelpline);
        rvHelplineList.setLayoutManager(new LinearLayoutManager(mContext));
        rvHelplineList.setHasFixedSize(true);
        swHelpline.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                apiCall();
            }
        });
    }

    private void apiCall() {
        HashMap<String, String> params = Utilities.getInstance().getRequestParams();
        params.put("tourism_place_id", String.valueOf(placeID));
        new CommonController(mContext).callApi(CommonController.REQUEST_CONTACT_LIST_BY_PLACE, params, true);
    }

    public void showErrorMsg(String msg) {
        CustomToast.makeToastWarning(mContext, msg);
        rvHelplineList.setAdapter(new EmptyAdapter());
        if (swHelpline.isRefreshing()) {
            swHelpline.setRefreshing(false);
        }

    }

    public void updateList(List<Contact> contactList) {
        if (contactList != null && contactList.size() > 0)
            updateListByHelplineType(contactList);

    }

    private void updateListByHelplineType(List<Contact> contactList) {
        List<Contact> mList = new ArrayList<>();
        switch (helplineType) {
            case StaticAccess.TAB_POLICE:
                for (Contact contact : contactList) {
                    if (contact.getHelpLineFor().equalsIgnoreCase("P")) {
                        mList.add(contact);
                    }
                }
                break;
            case StaticAccess.TAB_TOURIST_PLACE:
                for (Contact contact : contactList) {
                    if (contact.getHelpLineFor().equalsIgnoreCase("TP")) {
                        mList.add(contact);
                    }
                }
                break;
            case StaticAccess.TAB_FIRE_SERVICE:
                for (Contact contact : contactList) {
                    if (contact.getHelpLineFor().equalsIgnoreCase("FS")) {
                        mList.add(contact);
                    }
                }
                break;
            case StaticAccess.TAB_HOSPITAL:
                for (Contact contact : contactList) {
                    if (contact.getHelpLineFor().equalsIgnoreCase("H")) {
                        mList.add(contact);
                    }
                }
                break;

        }
        if (mList.size() > 0) {
            adapter = new HelplineListAdapter(mContext, mList);
            rvHelplineList.setAdapter(adapter);
        }else {
            rvHelplineList.setAdapter(new EmptyAdapter());
        }
        if (swHelpline.isRefreshing()) {
            swHelpline.setRefreshing(false);
        }
    }
}
