package diu.tourmaster.activities;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.util.DisplayMetrics;

import java.util.Locale;

import diu.tourmaster.utils.App;
import diu.tourmaster.utils.SharedPreferenceValues;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

/**
 * Created by Md Tajmul Alam on 1/25/2018.
 */

public class BaseActivity extends AppCompatActivity {
    static Locale myLocale;

    public static void setLocale(Context mContext) {
        String lang = shortLanguage(SharedPreferenceValues.getLanguage(mContext));
        myLocale = new Locale(lang);
        Resources res = mContext.getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        conf.locale = myLocale;
        res.updateConfiguration(conf, dm);
    }

    public static String shortLanguage(String lan) {
        if (lan.equalsIgnoreCase("English")) {
            return "en";
        } else {
            return "bn";
        }
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}

