package diu.tourmaster.activities;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;
import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.utils.CustomToast;
import diu.tourmaster.utils.GPSChecker;
import diu.tourmaster.utils.LocationManagerAI;
import diu.tourmaster.utils.SharedPreferenceValues;
import diu.tourmaster.utils.ToolbarConfig;

public class TouristSecurityActivity extends BaseActivity implements View.OnClickListener {

    private LocationManagerAI lm;
    private Context mContext;
    private TextView tvLocation;
    private ImageButton ibtnSetting, ibtnHelp, ibtnlocReload;
    private String locationAddress = "";
    private ProgressBar pbLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tourist_security);
        initToolbar();
        initUI();
        checkPermission();
        if (TextUtils.isEmpty(SharedPreferenceValues.getNumber(mContext))) {
            setEmergencyNumberDialog();
        }

    }

    private void initUI() {
        mContext = this;
        lm = new LocationManagerAI(mContext, 2);
        tvLocation = findViewById(R.id.tvLocation);
        ibtnSetting = findViewById(R.id.ibtnSetting);
        ibtnlocReload = findViewById(R.id.ibtnlocReload);
        ibtnHelp = findViewById(R.id.ibtnHelp);
        pbLocation = findViewById(R.id.pbLocation);
        ibtnHelp.setOnClickListener(this);
        ibtnSetting.setOnClickListener(this);
        ibtnlocReload.setOnClickListener(this);
        tvLocation.setText(getString(R.string.loader_loading));
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle(getString(R.string.tourist_security));
        //ToolbarConfig.centerTitleAndSubtitle(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishTheActivity();
            }
        });
        ToolbarConfig.makeStatusBarTransparent(getWindow());
    }

    private void finishTheActivity() {
        finish();
    }


    /*RUNTIME PERMISSION CHECKING METHOD*/
    boolean isPermissionGranted = false;
    boolean isGpsOn = false;

    void checkPermission() {
        PermissionListener permissionlistener = new PermissionListener() {
            @Override
            public void onPermissionGranted() {
                isPermissionGranted = true;
                if (GPSChecker.checkGPS(mContext)) {
                    showProgress();
                    lm.enableLocationApi();
                    lm.startTracking();
                    // firstimeLocationWizerd();
                    isGpsOn = true;
                } else {
                    isGpsOn = false;
                    GPSChecker.showSettingForGps(mContext);
                    tvLocation.setText(getString(R.string.gps_off));
                    //checkPermission();
                }
            }

            @Override
            public void onPermissionDenied(ArrayList<String> deniedPermissions) {
                isPermissionGranted = false;
                Log.e("permission: ", deniedPermissions.toString());
                tvLocation.setText(getString(R.string.unknown_location));
            }
        };
        TedPermission.with(mContext)
                .setPermissionListener(permissionlistener)
                .setRationaleMessage(R.string.permisson_text)
                .setDeniedMessage(R.string.permisson_rejected)
                .setPermissions(
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_NETWORK_STATE,
                        Manifest.permission.RECEIVE_BOOT_COMPLETED,
                        Manifest.permission.CALL_PHONE,
                        Manifest.permission.SEND_SMS,
                        Manifest.permission.READ_PHONE_STATE,
                        Manifest.permission.CHANGE_WIFI_STATE)
                .check();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        lm.stopLocationUpdates();
        lm.stopTracking();
    }

    public void detectLocationForHelp() {
        hideProgress();
        Log.e("loc: ", String.valueOf(SharedPreferenceValues.getLocation(mContext).latitude + ":" + SharedPreferenceValues.getLocation(mContext).longitude));
        final double lat = SharedPreferenceValues.getLocation(mContext).latitude;
        final double lng = SharedPreferenceValues.getLocation(mContext).longitude;
        if (isGpsOn && lat != 0 && lng != 0) {
            if (Geocoder.isPresent()) {
                try {
                    Geocoder gc = new Geocoder(mContext);
                    List<Address> addresses = gc.getFromLocation(lat, lng, 5); // get the found Address Objects

                    List<LatLng> ll = new ArrayList<LatLng>(addresses.size()); // A list to save the coordinates if they are available
                    for (Address a : addresses) {
                        if (a.hasLatitude() && a.hasLongitude()) {
                            ll.add(new LatLng(a.getLatitude(), a.getLongitude()));
                        }
                    }
                    locationAddress = addresses.get(0).getAddressLine(0);
                    tvLocation.setText(getString(R.string.your_are_near_at) + "\n" + addresses.get(0).getAddressLine(0));
                } catch (IOException e) {
                    tvLocation.setText(getString(R.string.no_service));
                    locationAddress = getString(R.string.no_service);
                    // handle the exception
                }
            } else {
                tvLocation.setText(getString(R.string.unknown_location) + " \n" + getString(R.string.try_again));
                locationAddress = "N/A";

            }
//                tvLocation.setText("Your current location is near at:  " + SharedPreferenceValues.getWizardSelectedPlace(mContext).getSightseeingPlaceName());

        } else {
            tvLocation.setText(getString(R.string.unknown_location) + " \n" + getString(R.string.try_again));
            locationAddress = "N/A";

        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ibtnSetting:
                setEmergencyNumberDialog();
                break;
            case R.id.ibtnHelp:
                if (TextUtils.isEmpty(SharedPreferenceValues.getNumber(mContext))) {
                    setEmergencyNumberDialog();
                } else {
                    setOperationDialog();
                }
                break;
            case R.id.ibtnlocReload:
                tvLocation.setText(getString(R.string.loader_loading));
                detectLocationForHelp();
                break;
        }
    }

    private void setEmergencyNumberDialog() {
        final Dialog dialog = new Dialog(mContext, R.style.CustomAlertDialog);
        dialog.setContentView(R.layout.dialog_set_emergency_number);
        dialog.setCancelable(false);
        final EditText etEmergencyNumber = dialog.findViewById(R.id.etEmergencyNumber);
        if (!TextUtils.isEmpty(SharedPreferenceValues.getNumber(mContext))) {
            etEmergencyNumber.setText(SharedPreferenceValues.getNumber(mContext));
        }
        ImageButton ibtnBackDisplay = dialog.findViewById(R.id.ibtnBackDisplay);

        Button btnSaveNumber = dialog.findViewById(R.id.btnSaveNumber);

        btnSaveNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!TextUtils.isEmpty(etEmergencyNumber.getText().toString())) {
                    SharedPreferenceValues.clearEmergencyNumber(mContext);
                    SharedPreferenceValues.setEmergencyNumber(mContext, etEmergencyNumber.getText().toString());
                    if (!TextUtils.isEmpty(SharedPreferenceValues.getNumber(mContext))) {
                        CustomToast.makeToast(mContext, getString(R.string.no_set_done));
                    }
                    dialog.dismiss();
                }else {
                    etEmergencyNumber.setError(getString(R.string.enter_emergency_number));
                }
            }
        });
        ibtnBackDisplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void setOperationDialog() {
        final Dialog dialog = new Dialog(mContext, R.style.CustomAlertDialog);
        dialog.setContentView(R.layout.dialog_select_sms_or_call_number);
        dialog.setCancelable(false);
        ImageButton ibtnBackDisplay = dialog.findViewById(R.id.ibtnBackDisplay);
        ImageButton ibtnSms = dialog.findViewById(R.id.ibtnSms);
        ImageButton ibtnCall = dialog.findViewById(R.id.ibtnCall);
        ibtnBackDisplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        ibtnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAlertOperationDialog(true, getString(R.string.do_you_like_to_make_emergency_call_sos));
                dialog.dismiss();
            }
        });
        ibtnSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAlertOperationDialog(false, getString(R.string.emergency_sms_text));
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void showAlertOperationDialog(final boolean isCall, String text) {
        final Dialog dialog = new Dialog(mContext, R.style.CustomAlertDialog);
        dialog.setContentView(R.layout.dialog_alert_call_number);
        dialog.setCancelable(false);
        TextView tvEmergencyText = dialog.findViewById(R.id.tvEmergencyText);
        Button btnCancel = dialog.findViewById(R.id.btnCancel);
        Button btnOkCall = dialog.findViewById(R.id.btnOkCall);
        tvEmergencyText.setText(text);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        btnOkCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isCall) {
                    if (!TextUtils.isEmpty(SharedPreferenceValues.getNumber(mContext))) {
                        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", SharedPreferenceValues.getNumber(mContext), null));
                        startActivity(intent);
                       /* Intent intent = new Intent(Intent.ACTION_DIAL);
                        intent.setData(Uri.parse("tel:" + SharedPreferenceValues.getNumber(mContext)));
                        startActivity(intent);*/
                    }
                } else {
                    sendEmergencySMS();
                }
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public void sendEmergencySMS() {
        try {
            String phoneNumber = SharedPreferenceValues.getNumber(mContext);
            String message = getString(R.string.alert) +
                    getString(R.string.i_am_in_danger) + getString(R.string.location) + locationAddress
                    + " " + getString(R.string.help_me);
            /*SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(mContext, R.string.sent_sms, Toast.LENGTH_SHORT).show();*/
            sendSMS(phoneNumber, message);
        } catch (Exception e) {
            CustomToast.makeToastWarning(mContext, getString(R.string.failed_to_sent_sms));
            //Toast.makeText(mContext, , Toast.LENGTH_SHORT).show();
        }

    }

    //---sends an SMS message to another device---
    private void sendSMS(String phoneNumber, String message) {
        String SENT = "SMS_SENT";
        String DELIVERED = "SMS_DELIVERED";

        PendingIntent sentPI = PendingIntent.getBroadcast(this, 0,
                new Intent(SENT), 0);

        PendingIntent deliveredPI = PendingIntent.getBroadcast(this, 0,
                new Intent(DELIVERED), 0);

        //---when the SMS has been sent---
        registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context arg0, Intent arg1) {
                //unregisterReceiver(this);
                switch (getResultCode()) {
                    case Activity.RESULT_OK:
                        CustomToast.makeToast(mContext, getString(R.string.sms_sent));

                        //Toast.makeText(getBaseContext(),getString( R.string.sms_sent), Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                        CustomToast.makeToastWarning(mContext, getString(R.string.sent_failed));

                        //Toast.makeText(getBaseContext(), getString( R.string.sent_failed), Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_NO_SERVICE:
                        /*Toast.makeText(getBaseContext(), getString( R.string.sent_failed),
                                Toast.LENGTH_SHORT).show();*/
                        CustomToast.makeToastWarning(mContext, getString(R.string.sent_failed));

                        break;
                    case SmsManager.RESULT_ERROR_NULL_PDU:
                        /*Toast.makeText(getBaseContext(), getString( R.string.sent_failed),
                                Toast.LENGTH_SHORT).show();*/
                        CustomToast.makeToastWarning(mContext, getString(R.string.sent_failed));

                        break;
                    case SmsManager.RESULT_ERROR_RADIO_OFF:
                        /*Toast.makeText(getBaseContext(), getString( R.string.sent_failed),
                                Toast.LENGTH_SHORT).show();*/
                        CustomToast.makeToastWarning(mContext, getString(R.string.sent_failed));

                        break;
                }
            }
        }, new IntentFilter(SENT));

        //---when the SMS has been delivered---
        registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context arg0, Intent arg1) {
                //unregisterReceiver(this);
                switch (getResultCode()) {
                    case Activity.RESULT_OK:
                        /*Toast.makeText(getBaseContext(), getString(R.string.sms_deliverd),
                                Toast.LENGTH_SHORT).show();*/
                        CustomToast.makeToast(mContext, getString(R.string.sms_deliverd));

                        break;
                    case Activity.RESULT_CANCELED:
                        CustomToast.makeToastWarning(mContext, getString(R.string.sms_not_deliver));

                        /*Toast.makeText(getBaseContext(), getString(R.string.sms_not_deliver),
                                Toast.LENGTH_SHORT).show();*/
                        break;
                }
            }
        }, new IntentFilter(DELIVERED));

        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(phoneNumber, null, message, sentPI, deliveredPI);
    }

    void showProgress() {
        ibtnlocReload.setVisibility(View.GONE);
        pbLocation.setVisibility(View.VISIBLE);
    }

    void hideProgress() {
        ibtnlocReload.setVisibility(View.VISIBLE);
        pbLocation.setVisibility(View.GONE);
    }
}
