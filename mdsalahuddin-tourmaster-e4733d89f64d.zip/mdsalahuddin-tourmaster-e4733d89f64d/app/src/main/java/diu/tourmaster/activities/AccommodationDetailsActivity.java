package diu.tourmaster.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.controllers.CommonController;
import diu.tourmaster.models.Accommodation;
import diu.tourmaster.models.Photos;
import diu.tourmaster.models.SightSeeingPlace;
import diu.tourmaster.utils.Configs;
import diu.tourmaster.utils.CustomToast;
import diu.tourmaster.utils.StaticAccess;
import diu.tourmaster.utils.ToolbarConfig;
import diu.tourmaster.utils.Utilities;
import ss.com.bannerslider.banners.Banner;
import ss.com.bannerslider.banners.DrawableBanner;
import ss.com.bannerslider.banners.RemoteBanner;
import ss.com.bannerslider.views.BannerSlider;

public class AccommodationDetailsActivity extends BaseActivity implements OnMapReadyCallback {
    private TextView tvAccommodationName, tvAccommodationDetails, tvStandard, tvMobile, tvAddress;
    private MapView mapView;
    private BannerSlider bannerSlider;
    private GoogleMap map;
    private AccommodationDetailsActivity activity;
    private CommonController commonController;
    private Integer accommodationID = -1;
    private Integer placeID = -1;
    private Toolbar toolbar;
    private String number = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BaseActivity.setLocale(this);

        setContentView(R.layout.activity_accommodation_details);
        receiveIntent();
        initToolbar();
        initUI(savedInstanceState);
        callApi();
    }

    private void receiveIntent() {
        accommodationID = getIntent() != null ? getIntent().getIntExtra(StaticAccess.KEY_ACCOMMODATION_ID_INTENT, -1) : -1;
        placeID = getIntent() != null ? getIntent().getIntExtra(StaticAccess.KEY_PLACE_ID_INTENT, -1) : -1;
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishTheActivity();
            }
        });
        ToolbarConfig.makeStatusBarTransparent(getWindow());

    }

    private void finishTheActivity() {
        startActivity(new Intent(activity, AccommodationActivity.class).putExtra(StaticAccess.KEY_PLACE_ID_INTENT, placeID));
        finish();
    }

    private void initUI(Bundle savedInstanceState) {
        activity = this;
        commonController = new CommonController(activity);
        bannerSlider = findViewById(R.id.bannerSlider);
        tvAccommodationName = findViewById(R.id.tvAccommodationName);
        tvAccommodationDetails = findViewById(R.id.tvAccommodationDetails);
        tvStandard = findViewById(R.id.tvStandard);
        tvMobile = findViewById(R.id.tvMobile);
        tvAddress = findViewById(R.id.tvAddress);
        mapView = (MapView) findViewById(R.id.mapView);
        mapView.onCreate(savedInstanceState);
        mapView.getMapAsync(this);
        tvMobile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!TextUtils.isEmpty(number)) {
                    Intent intent = new Intent(Intent.ACTION_DIAL);
                    intent.setData(Uri.parse("tel:" + number));
                    startActivity(intent);
                }
            }
        });

    }

    private void callApi() {
        HashMap<String, String> params = Utilities.getInstance().getRequestParams();
        params.put("accomodation_id", String.valueOf(accommodationID));
        commonController.callApi(CommonController.REQUEST_SINGLE_ACCOMMODATION, params, true);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.map = googleMap;
        map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

        } else {
            map.setMyLocationEnabled(true);
        }
        map.setTrafficEnabled(true);
        map.setIndoorEnabled(true);
        map.setBuildingsEnabled(true);
        map.getUiSettings().setZoomControlsEnabled(true);
    }

    @Override
    public void onResume() {
        mapView.onResume();
        super.onResume();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }

    public void showErrorMsg(String msg) {
        CustomToast.makeToastWarning(activity, msg);

    }

    public void updateAccommodation(Accommodation accommodation) {
        setTitle(accommodation.getHotelName());
        tvAccommodationDetails.setText(accommodation.getDescription());
        tvAccommodationName.setText(accommodation.getHotelName());
        tvStandard.setText("Standard: "+accommodation.getStandard() + " star");
        tvMobile.setText("Contact: " + accommodation.getMobileNo());
        tvAddress.setText("Address: " + accommodation.getAddress());
        number = accommodation.getMobileNo();
        if (map != null) {

            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(new LatLng(Double.valueOf(accommodation.getLatitude()), Double.valueOf(accommodation.getLongitude())), 18);
            map.animateCamera(cameraUpdate);
            MarkerOptions marker = new MarkerOptions().position(new LatLng(Double.valueOf(accommodation.getLatitude()), Double.valueOf(accommodation.getLongitude())));
            marker.title(accommodation.getHotelName() + "\n" + accommodation.getAddress());
            map.addMarker(marker);
            //mapView.requestFocus();
            loadBannerSlider(accommodation.getPhotosList());
        }
    }

    public void loadBannerSlider(List<Photos> photosList) {
        List<Banner> banners = new ArrayList<>();
        if (photosList != null && photosList.size() > 0) {
            for (Photos photos : photosList) {
                //add banner using image url
                RemoteBanner remoteBanner = new RemoteBanner(Configs.BASE_URL + photos.getPhotoPath());
                remoteBanner.setScaleType(ImageView.ScaleType.FIT_XY);
                banners.add(remoteBanner);
                //add banner using resource drawable
            }
        } else {
            DrawableBanner drawableBanner = new DrawableBanner(R.drawable.placeholder);
            drawableBanner.setScaleType(ImageView.ScaleType.FIT_XY);
            banners.add(drawableBanner);
        }
        bannerSlider.setBanners(banners);
    }

}
