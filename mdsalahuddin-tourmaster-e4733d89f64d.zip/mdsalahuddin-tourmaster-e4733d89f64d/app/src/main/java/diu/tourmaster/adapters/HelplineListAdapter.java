package diu.tourmaster.adapters;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.models.Contact;
import diu.tourmaster.models.Transport;

/**
 * Created by tajmulalam on 1/12/18.
 */

public class HelplineListAdapter extends RecyclerView.Adapter<HelplineListAdapter.HelplineListViewHolder> {

    private Context mContext;
    private List<Contact> contactList;

    public HelplineListAdapter(Context mContext, List<Contact> contactList) {
        this.mContext = mContext;
        this.contactList = contactList;
    }

    @Override
    public HelplineListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.transport_list_custom_row, null);
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.contact_list_custom_row, null);
        return new HelplineListViewHolder(view);
    }

    public void onBindViewHolder(HelplineListViewHolder holder, final int position) {
        holder.tvNumber.setText(contactList.get(position).getContactNumber());
        holder.tvAddress.setText(contactList.get(position).getAddress());
        holder.tvNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callNumber(position);
            }
        });
        holder.ibtnPhoneCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callNumber(position);
            }
        });
    }

    private void callNumber(int position) {
        if (!TextUtils.isEmpty(contactList.get(position).getContactNumber())) {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:" + contactList.get(position).getContactNumber()));
            mContext.startActivity(intent);
        }
    }

    @Override
    public int getItemCount() {
        return contactList.size() > 0 ? contactList.size() : 0;
    }

    public class HelplineListViewHolder extends RecyclerView.ViewHolder {
        private TextView tvNumber;
        private TextView tvAddress;
        private ImageButton ibtnPhoneCall;

        public HelplineListViewHolder(View itemView) {
            super(itemView);
            tvNumber = itemView.findViewById(R.id.tvNumber);
            tvAddress = itemView.findViewById(R.id.tvAddress);
            ibtnPhoneCall = itemView.findViewById(R.id.ibtnPhoneCall);
        }
    }
}
