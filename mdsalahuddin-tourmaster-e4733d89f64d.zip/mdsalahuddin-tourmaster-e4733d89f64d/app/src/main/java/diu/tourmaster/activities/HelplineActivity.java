package diu.tourmaster.activities;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import diu.tourmaster.R;
import diu.tourmaster.fragments.HelplineContactsFragment;
import diu.tourmaster.fragments.TransportsFragment;
import diu.tourmaster.utils.StaticAccess;
import diu.tourmaster.utils.ToolbarConfig;

public class HelplineActivity extends BaseActivity {
    private int placeID = -1;
    private TabLayout tlHelpline;
    private HelplineActivity activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BaseActivity.setLocale(this);
        setContentView(R.layout.activity_helpline);
        receiveIntent();
        initToolbar();
        initUI();
    }

    private void receiveIntent() {
        activity = this;
        placeID = getIntent() != null ? getIntent().getIntExtra(StaticAccess.KEY_PLACE_ID_INTENT, -1) : -1;
    }

    private void initUI() {
        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        tlHelpline = findViewById(R.id.tlHelpline);
        tlHelpline.setTabTextColors(
                ContextCompat.getColor(activity, android.R.color.white),
                ContextCompat.getColor(activity, android.R.color.white)
        );
        TabLayout.Tab tab1 = tlHelpline.newTab();
        tab1.setText(getString(R.string.police));
        tlHelpline.addTab(tab1);
        TabLayout.Tab tab2 = tlHelpline.newTab();
        tab2.setText(getString(R.string.tourist_place));
        tlHelpline.addTab(tab2);
        TabLayout.Tab tab3 = tlHelpline.newTab();
        tab3.setText(getString(R.string.fire_service));
        tlHelpline.addTab(tab3);
        TabLayout.Tab tab4 = tlHelpline.newTab();
        tab4.setText(getString(R.string.hospital));
        tlHelpline.addTab(tab4);
        changeTabsFont();
        // perform setOnTabSelectedListener event on TabLayout
        tlHelpline.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                // get the current selected tab's position and replace the fragment accordingly
                setSelectFragment(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        setSelectFragment(0);
    }
    private void changeTabsFont() {
        Typeface typeface = Typeface.createFromAsset(activity.getAssets(), "font/rancho3.ttf");

        ViewGroup vg = (ViewGroup) tlHelpline.getChildAt(0);
        int tabsCount = vg.getChildCount();
        for (int j = 0; j < tabsCount; j++) {
            ViewGroup vgTab = (ViewGroup) vg.getChildAt(j);
            int tabChildsCount = vgTab.getChildCount();
            for (int i = 0; i < tabChildsCount; i++) {
                View tabViewChild = vgTab.getChildAt(i);
                if (tabViewChild instanceof TextView) {
                    ((TextView) tabViewChild).setTypeface(typeface);
                }
            }
        }
    }
    private void setSelectFragment(int position) {
        Fragment fragment = null;
        switch (position) {
            case 0:
                fragment = HelplineContactsFragment.newInstance(StaticAccess.TAB_POLICE, placeID);
                break;
            case 1:
                fragment = HelplineContactsFragment.newInstance(StaticAccess.TAB_TOURIST_PLACE, placeID);
                break;
            case 2:
                fragment = HelplineContactsFragment.newInstance(StaticAccess.TAB_FIRE_SERVICE, placeID);
                break;
            case 3:
                fragment = HelplineContactsFragment.newInstance(StaticAccess.TAB_HOSPITAL, placeID);
                break;
        }
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.rlHelplineContainer, fragment);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        ft.commit();
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle(getString(R.string.helpline));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishTheActivity();
            }
        });
        ToolbarConfig.makeStatusBarTransparent(getWindow());
    }

    private void finishTheActivity() {
        finish();
    }
}
