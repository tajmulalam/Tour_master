package diu.tourmaster.models;

/**
 * Created by Md Tajmul Alam on 1/21/2018.
 */

public class Transport {
    private Integer trasportId;
    private String transportName;
    private String transportType;
    private String description;
    private Integer status;
    private String createdAt;

    public Integer getTrasportId() {
        return trasportId;
    }

    public void setTrasportId(Integer trasportId) {
        this.trasportId = trasportId;
    }

    public String getTransportName() {
        return transportName;
    }

    public void setTransportName(String transportName) {
        this.transportName = transportName;
    }

    public String getTransportType() {
        return transportType;
    }

    public void setTransportType(String transportType) {
        this.transportType = transportType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}
