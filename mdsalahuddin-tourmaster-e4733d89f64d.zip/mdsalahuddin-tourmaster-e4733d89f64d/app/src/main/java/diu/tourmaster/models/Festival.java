package diu.tourmaster.models;

import java.util.List;

/**
 * Created by Md Tajmul Alam on 1/20/2018.
 */

public class Festival {
    private Integer festivalId;
    private String festivalAt;
    private String description;
    private Integer status;
    private String createdAt;

    public Integer getFestivalId() {
        return festivalId;
    }

    public void setFestivalId(Integer festivalId) {
        this.festivalId = festivalId;
    }

    public String getFestivalAt() {
        return festivalAt;
    }

    public void setFestivalAt(String festivalAt) {
        this.festivalAt = festivalAt;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

}

