package diu.tourmaster.activities;

import android.content.Intent;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

import java.util.HashMap;
import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.adapters.EmptyAdapter;
import diu.tourmaster.adapters.VideoCategoryListAdapter;
import diu.tourmaster.adapters.VideoListAdapter;
import diu.tourmaster.controllers.CommonController;
import diu.tourmaster.models.VideoFile;
import diu.tourmaster.utils.CustomToast;
import diu.tourmaster.utils.StaticAccess;
import diu.tourmaster.utils.ToolbarConfig;
import diu.tourmaster.utils.Utilities;

public class VideoListActivity extends BaseActivity implements VideoListAdapter.VideoClickedListener {
    private VideoListActivity activity;
    private RecyclerView rvVideoList;
    private RecyclerView.Adapter adapter;
    private CommonController commonController;
    private int videoCategoryID = -1;
private SwipeRefreshLayout swVideoList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BaseActivity.setLocale(this);
        setContentView(R.layout.activity_video_list);
        receiveBundle();
        initToolbar();
        initUI();
        callApi();
    }

    private void receiveBundle() {
        activity = this;
        videoCategoryID = getIntent() != null ? getIntent().getIntExtra(StaticAccess.KEY_CATEGORY_ID_ID_INTENT, -1) : -1;
    }

    private void callApi() {
        HashMap<String, String> params = Utilities.getInstance().getRequestParams();
        params.put("category_id", String.valueOf(videoCategoryID));
        commonController.callApi(CommonController.REQUEST_VIDEO_LIST_BY_CATEGORY_ID, params, true);
    }


    private void initUI() {
        commonController = new CommonController(activity);
        rvVideoList = findViewById(R.id.rvVideoList);
        swVideoList = findViewById(R.id.swVideoList);
        rvVideoList.setHasFixedSize(true);
        rvVideoList.setLayoutManager(new GridLayoutManager(activity, 2));
        swVideoList.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                callApi();
            }
        });
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle(getString(R.string.vidoe_list));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishTheActivity();
            }
        });
        ToolbarConfig.makeStatusBarTransparent(getWindow());

    }

    private void finishTheActivity() {
        startActivity(new Intent(activity, HeritageGalleryActivity.class));
        finish();
    }

    @Override
    public void onBackPressed() {
       finishTheActivity();
    }

    public void showErrorMsg(String msg) {
        CustomToast.makeToastWarning(activity, msg);
        rvVideoList.setAdapter(new EmptyAdapter());
        if (swVideoList.isRefreshing()){
            swVideoList.setRefreshing(false);
        }
    }

    public void updateVideoList(List<VideoFile> videoFileList) {
        if (videoFileList != null && videoFileList.size() > 0) {
            adapter = new VideoListAdapter(activity, videoFileList, this);
            rvVideoList.setAdapter(adapter);
        }else {
            rvVideoList.setAdapter(new EmptyAdapter());
        }

        if (swVideoList.isRefreshing()){
            swVideoList.setRefreshing(false);
        }
    }

    @Override
    public void videoClicked(VideoFile videoFile) {
        Intent intent = new Intent(activity, VideoPlayActivity.class);
        intent.putExtra(StaticAccess.KEY_VIDEO_LINK_INTENT, videoFile.getVideoLink());
        startActivity(intent);
    }
}
