package diu.tourmaster.fragments;


import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;
import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.activities.AccommodationActivity;
import diu.tourmaster.activities.FoodActivity;
import diu.tourmaster.activities.HelplineActivity;
import diu.tourmaster.activities.MainActivity;
import diu.tourmaster.activities.TransactionsActivity;
import diu.tourmaster.activities.TransportsActivity;
import diu.tourmaster.adapters.SightPlaceWizardListAdapter;
import diu.tourmaster.controllers.CommonController;
import diu.tourmaster.models.SightSeeingPlace;
import diu.tourmaster.models.TourismPlace;
import diu.tourmaster.utils.CustomToast;
import diu.tourmaster.utils.GPSChecker;
import diu.tourmaster.utils.LocationManagerAI;
import diu.tourmaster.utils.SharedPreferenceValues;
import diu.tourmaster.utils.StaticAccess;
import diu.tourmaster.utils.Utilities;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment implements View.OnClickListener {
    private LocationManagerAI lm;
    private ImageView ivReload;
    private TextView tvLocation;
    private Context mContext;
    private CommonController commonController;
    private ProgressBar pbLocation;
    private LinearLayout lnTouristSecurity, lnTouristPlace, lnSightPlace,
            lnFestivalCalender, lnHeritageGallery, lnAccommo, lnFood,
            lnLocaTransport, lnHelpline, lnNearestTransaction;
    private HorizontalScrollView scMenus, scMenus2;
    private ImageButton ibtnBackMenu1, ibtnBackMenu2, ibtnRightMenu1, ibtnRightMenu2;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    public Context getmContext() {
        return mContext;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mContext = getContext();
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        lm = new LocationManagerAI(getContext(), 1);
        commonController = new CommonController(mContext);
        checkPermission();
        initUI(view);
        return view;
    }

    private void initUI(View view) {

        tvLocation = view.findViewById(R.id.tvLocation);
        ivReload = view.findViewById(R.id.ivReload);
        pbLocation = view.findViewById(R.id.pbLocation);
        lnTouristSecurity = view.findViewById(R.id.lnTouristSecurity);
        lnTouristPlace = view.findViewById(R.id.lnTouristPlace);
        lnSightPlace = view.findViewById(R.id.lnSightPlace);
        lnFestivalCalender = view.findViewById(R.id.lnFestivalCalender);
        lnHeritageGallery = view.findViewById(R.id.lnHeritageGallery);
        lnAccommo = view.findViewById(R.id.lnAccommo);
        lnFood = view.findViewById(R.id.lnFood);
        lnLocaTransport = view.findViewById(R.id.lnLocaTransport);
        lnHelpline = view.findViewById(R.id.lnHelpline);
        lnNearestTransaction = view.findViewById(R.id.lnNearestTransaction);
        scMenus2 = view.findViewById(R.id.scMenus2);
        scMenus = view.findViewById(R.id.scMenus);
        ibtnBackMenu1 = view.findViewById(R.id.ibtnBackMenu1);
        ibtnBackMenu2 = view.findViewById(R.id.ibtnBackMenu2);
        ibtnRightMenu1 = view.findViewById(R.id.ibtnRightMenu1);
        ibtnRightMenu2 = view.findViewById(R.id.ibtnRightMenu2);

        // ibtnBackMenu1.setOnClickListener(this);
        //ibtnBackMenu2.setOnClickListener(this);
        //ibtnRightMenu1.setOnClickListener(this);
        //ibtnRightMenu2.setOnClickListener(this);
        ivReload.setOnClickListener(this);
        tvLocation.setOnClickListener(this);
        lnTouristSecurity.setOnClickListener(this);
        lnTouristPlace.setOnClickListener(this);
        lnSightPlace.setOnClickListener(this);
        lnFestivalCalender.setOnClickListener(this);
        lnHeritageGallery.setOnClickListener(this);
        lnAccommo.setOnClickListener(this);
        lnFood.setOnClickListener(this);
        lnLocaTransport.setOnClickListener(this);
        lnHelpline.setOnClickListener(this);
        lnNearestTransaction.setOnClickListener(this);
        if (SharedPreferenceValues.getWizardSelectedPlace(mContext) == null) {
            tvLocation.setText(getString(R.string.loader_loading));
            hideSpecialMenus();
        }
        tvLocation.setText(getString(R.string.loader_loading));
        hideSpecialMenus();

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle(getString(R.string.app_name));
        //firstimeLocationWizerd();
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    public void firstimeLocationWizerd() {
        Log.e("loc: ", String.valueOf(SharedPreferenceValues.getLocation(mContext).latitude + ":" + SharedPreferenceValues.getLocation(mContext).longitude));
        final double lat = SharedPreferenceValues.getLocation(mContext).latitude;
        final double lng = SharedPreferenceValues.getLocation(mContext).longitude;
        if (isGpsOn) {
            if (lat != 0 && lng != 0) {
                showProgress();
                HashMap<String, String> params = Utilities.getInstance().getRequestParams();
                params.put("latitude", String.valueOf(lat));
                params.put("longitude", String.valueOf(lng));
                commonController.callApi(CommonController.USER_LOCATION_REQUEST, params, false);
                ((MainActivity) mContext).controlDrawer(false);
                if (Geocoder.isPresent()) {
                    try {
                        Geocoder gc = new Geocoder(mContext);
                        List<Address> addresses = gc.getFromLocation(lat, lng, 5); // get the found Address Objects

                        List<LatLng> ll = new ArrayList<LatLng>(addresses.size()); // A list to save the coordinates if they are available
                        for (Address a : addresses) {
                            if (a.hasLatitude() && a.hasLongitude()) {
                                ll.add(new LatLng(a.getLatitude(), a.getLongitude()));
                            }
                        }
                        tvLocation.setText(getString(R.string.your_are_near_at) + "\n" + addresses.get(0).getAddressLine(0));
                        ((MainActivity) mContext).changeNavHeaderTitle(addresses.get(0).getAddressLine(0));
                        //visibleSpecialMenus();

                    } catch (IOException e) {
                        tvLocation.setText(getString(R.string.unknown_location) + " \n" + getString(R.string.try_again));
                        ((MainActivity) mContext).changeNavHeaderTitle(getString(R.string.unknown_location));
                        /*hideSpecialMenus();*/

                        // handle the exception
                    }
                } else {
                    tvLocation.setText(getString(R.string.unknown_location) + " \n" + getString(R.string.try_again));
                    ((MainActivity) mContext).changeNavHeaderTitle(getString(R.string.unknown_location));

                }
//                tvLocation.setText("Your current location is near at:  " + SharedPreferenceValues.getWizardSelectedPlace(mContext).getSightseeingPlaceName());

            } else {
                tvLocation.setText(getString(R.string.unknown_location) + " \n" + getString(R.string.try_again));
                ((MainActivity) mContext).changeNavHeaderTitle(getString(R.string.unknown_location));
                //hideSpecialMenus();

            }
        } else {
            GPSChecker.checkGPS(mContext);
            tvLocation.setText(getString(R.string.gps_off));

        }
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        menu.clear();
    }

    @Override
    public void onResume() {
        super.onResume();
        /*if (isPermissionGranted) {
            firstimeLocationWizerd();
        }*/
    }

    @Override
    public void onDetach() {
        super.onDetach();
        lm.stopLocationUpdates();
        lm.stopTracking();
        lm = null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }

    /*RUNTIME PERMISSION CHECKING METHOD*/
    boolean isPermissionGranted = false;
    boolean isGpsOn = false;

    void checkPermission() {
        PermissionListener permissionlistener = new PermissionListener() {
            @Override
            public void onPermissionGranted() {
                isPermissionGranted = true;
                if (GPSChecker.checkGPS(mContext)) {
                    lm.enableLocationApi();
                    lm.startTracking();
                    // firstimeLocationWizerd();
                    isGpsOn = true;
                } else {
                    isGpsOn = false;
                    GPSChecker.showSettingForGps(mContext);
                    //checkPermission();
                }
            }

            @Override
            public void onPermissionDenied(ArrayList<String> deniedPermissions) {
                isPermissionGranted = false;
                Log.e("permission: ", deniedPermissions.toString());
                tvLocation.setText(getString(R.string.gps_off));

            }
        };
        TedPermission.with(mContext)
                .setPermissionListener(permissionlistener)
                .setRationaleMessage(R.string.permisson_text)
                .setDeniedMessage(R.string.permisson_rejected)
                .setPermissions(
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_NETWORK_STATE,
                        Manifest.permission.RECEIVE_BOOT_COMPLETED,
                        Manifest.permission.CALL_PHONE,
                        Manifest.permission.CHANGE_WIFI_STATE)
                .check();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivReload:
                if (isGpsOn) {
                    if (GPSChecker.checkGPS(mContext)) {
                        isGpsOn = true;
                        hideSpecialMenus();
                        firstimeLocationWizerd();
                    } else {
                        GPSChecker.showSettingForGps(mContext);
                        tvLocation.setText(getString(R.string.gps_off));
                    }
                } else {
                    checkPermission();
                }
                break;
            case R.id.tvLocation:
                ivReload.performClick();
                break;
            case R.id.lnTouristSecurity:
                ((MainActivity) mContext).displaySelectedScreen(R.id.nav_tourist_security);

                break;
            case R.id.lnTouristPlace:
                ((MainActivity) mContext).displaySelectedScreen(R.id.nav_places);

                break;
            case R.id.lnSightPlace:
                if (((MainActivity) mContext).checkLocationIsAvailable()) {
                    ((MainActivity) mContext).displaySelectedScreen(R.id.nav_sight_places);
                } else {
                    CustomToast.makeToastWarning(mContext, getString(R.string.no_record_for_locaiton));

                }

                break;
            case R.id.lnFestivalCalender:
                ((MainActivity) mContext).displaySelectedScreen(R.id.nav_festival_calender);

                break;
            case R.id.lnHeritageGallery:
                ((MainActivity) mContext).displaySelectedScreen(R.id.nav_heritage_gallery);
                break;
            case R.id.lnAccommo:
                if (((MainActivity) mContext).checkLocationIsAvailable()) {

                    mContext.startActivity(new Intent(mContext, AccommodationActivity.class).putExtra(StaticAccess.KEY_PLACE_ID_INTENT, SharedPreferenceValues.getWizardSelectedPlace(mContext).getTourismPlaceId()));
                } else {
                    CustomToast.makeToastWarning(mContext, getString(R.string.no_record_for_locaiton));

                }
                break;
            case R.id.lnFood:
                if (((MainActivity) mContext).checkLocationIsAvailable()) {

                    mContext.startActivity(new Intent(mContext, FoodActivity.class).putExtra(StaticAccess.KEY_PLACE_ID_INTENT, SharedPreferenceValues.getWizardSelectedPlace(mContext).getTourismPlaceId()));
                } else {
                    CustomToast.makeToastWarning(mContext, getString(R.string.no_record_for_locaiton));

                }
                break;
            case R.id.lnLocaTransport:
                if (((MainActivity) mContext).checkLocationIsAvailable()) {
                    mContext.startActivity(new Intent(mContext, TransportsActivity.class).putExtra(StaticAccess.KEY_PLACE_ID_INTENT, SharedPreferenceValues.getWizardSelectedPlace(mContext).getTourismPlaceId()));
                } else {
                    CustomToast.makeToastWarning(mContext, getString(R.string.no_record_for_locaiton));
                }
                break;
            case R.id.lnHelpline:
                if (((MainActivity) mContext).checkLocationIsAvailable()) {
                    mContext.startActivity(new Intent(mContext, HelplineActivity.class).putExtra(StaticAccess.KEY_PLACE_ID_INTENT, SharedPreferenceValues.getWizardSelectedPlace(mContext).getTourismPlaceId()));
                } else {
                    CustomToast.makeToastWarning(mContext, getString(R.string.no_record_for_locaiton));

                }
                break;
            case R.id.lnNearestTransaction:
                if (((MainActivity) mContext).checkLocationIsAvailable()) {
                    mContext.startActivity(new Intent(mContext, TransactionsActivity.class).putExtra(StaticAccess.KEY_PLACE_ID_INTENT, SharedPreferenceValues.getWizardSelectedPlace(mContext).getTourismPlaceId()));
                } else {
                    CustomToast.makeToastWarning(mContext, getString(R.string.no_record_for_locaiton));
                }
                break;
            case R.id.ibtnBackMenu1:
                scMenus.scrollTo((int) scMenus.getScrollX() + 100, (int) scMenus.getScrollY());
                break;
            case R.id.ibtnRightMenu1:
                scMenus.scrollTo((int) scMenus.getScrollX() - 100, (int) scMenus.getScrollY());
                break;
            case R.id.ibtnBackMenu2:
                scMenus2.scrollTo((int) scMenus2.getScrollX() + 100, (int) scMenus2.getScrollY());
                break;
            case R.id.ibtnRightMenu2:
                scMenus2.scrollTo((int) scMenus2.getScrollX() - 100, (int) scMenus2.getScrollY());
                break;
        }
    }

    public void showErrorMsg(String msg) {
        hideProgress();
        ((MainActivity) mContext).controlDrawer(true);
        CustomToast.makeToastWarning(mContext, msg);
        lnTouristSecurity.setEnabled(false);

    }

    boolean isFirstTime = false;
    public void showUserLocation(List<TourismPlace> tourismPlaceList) {
        //Toast.makeText(mContext, msg, Toast.LENGTH_SHORT).show();
        hideProgress();
        ((MainActivity) mContext).controlDrawer(true);
        visibleSpecialMenus();
        if (tourismPlaceList != null && tourismPlaceList.size() > 0) {

            SharedPreferenceValues.clearWizardPlace(mContext);
            SharedPreferenceValues.setWizardSelectedPlace(mContext, tourismPlaceList.get(0));
            if (!isFirstTime) {
                ((MainActivity) mContext).settingEnvironmentLoginUserWise();
                isFirstTime = true;
            }

        }else {
            SharedPreferenceValues.clearWizardPlace(mContext);
            CustomToast.makeToastWarning(mContext,getString(R.string.no_record_for_locaiton));
        }

        //shoPlaceWizardDialog(sightSeeingPlaceList);
    }

    /*private void shoPlaceWizardDialog(List<SightSeeingPlace> sightSeeingPlaceList) {
        final Dialog dialog = new Dialog(mContext, R.style.CustomDialog);
        dialog.setContentView(R.layout.dialog_select_place);
        dialog.setCancelable(false);
        RecyclerView rvSightPlace = dialog.findViewById(R.id.rvSightPlace);
        ImageButton ibtnClose = dialog.findViewById(R.id.ibtnClose);
        ibtnClose.setVisibility(View.VISIBLE);
        SightPlaceWizardListAdapter.WizardPlaceSelectListener wizardPlaceSelectListener = new SightPlaceWizardListAdapter.WizardPlaceSelectListener() {
            @Override
            public void sightPlaceSelected(SightSeeingPlace sightSeeingPlace) {
                SharedPreferenceValues.clearWizardPlace(mContext);
                SharedPreferenceValues.setWizardSelectedPlace(mContext, sightSeeingPlace);
                if (dialog != null) {
                    dialog.dismiss();
                }
                tvLocation.setText(getString(R.string.your_are_near_at) + "\n" + sightSeeingPlace.getSightseeingPlaceName());
                ((MainActivity) mContext).settingEnvironmentLoginUserWise();
                //((MainActivity) mContext).changeNavHeaderTitle(sightSeeingPlace.getSightseeingPlaceName());
            }
        };
        RecyclerView.Adapter adapter = new SightPlaceWizardListAdapter(mContext, sightSeeingPlaceList, wizardPlaceSelectListener);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mContext);
        rvSightPlace.setLayoutManager(layoutManager);
        rvSightPlace.setAdapter(adapter);
        ibtnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }*/

    void showProgress() {
        ivReload.setVisibility(View.GONE);
        pbLocation.setVisibility(View.VISIBLE);
    }

    void hideProgress() {
        ivReload.setVisibility(View.VISIBLE);
        pbLocation.setVisibility(View.GONE);
    }

    void visibleSpecialMenus() {
/*        scMenus.setVisibility(View.VISIBLE);
        scMenus2.setVisibility(View.VISIBLE);
        lnSightPlace.setVisibility(View.VISIBLE);*/
        lnTouristSecurity.setEnabled(true);
        lnTouristPlace.setEnabled(true);
        lnSightPlace.setEnabled(true);
        lnFestivalCalender.setEnabled(true);
        lnHeritageGallery.setEnabled(true);
        lnAccommo.setEnabled(true);
        lnFood.setEnabled(true);
        lnLocaTransport.setEnabled(true);
        lnHelpline.setEnabled(true);
        lnNearestTransaction.setEnabled(true);
    }

    void hideSpecialMenus() {
  /*      scMenus.setVisibility(View.GONE);
        scMenus2.setVisibility(View.GONE);
        lnSightPlace.setVisibility(View.GONE);*/
        lnTouristSecurity.setEnabled(false);
        lnTouristPlace.setEnabled(false);
        lnSightPlace.setEnabled(false);
        lnFestivalCalender.setEnabled(false);
        lnHeritageGallery.setEnabled(false);
        lnAccommo.setEnabled(false);
        lnFood.setEnabled(false);
        lnLocaTransport.setEnabled(false);
        lnHelpline.setEnabled(false);
        lnNearestTransaction.setEnabled(false);
    }
}
