package diu.tourmaster.listener;

import diu.tourmaster.models.TourismPlace;

/**
 * Created by tajmulalam on 1/13/18.
 */

public interface PlaceClickListener {
    void clickedPlace(TourismPlace place);
}
