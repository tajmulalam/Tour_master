package diu.tourmaster.adapters;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.util.Log;

import diu.tourmaster.fragments.FacilitiesFragment;
import diu.tourmaster.fragments.PlaceDetailsFragment;
import diu.tourmaster.fragments.SightSeeingPlacesFragment;
import diu.tourmaster.utils.StaticAccess;

/**
 * Created by tajmulalam on 1/13/18.
 */

public class PlaceDetailsTabPagerAdapter extends FragmentStatePagerAdapter {
    private int placeID;
    PlaceDetailsFragment placeDetailsFragment;
    SightSeeingPlacesFragment sightSeeingPlacesFragment;
    FacilitiesFragment facilitiesFragment;

    public PlaceDetailsTabPagerAdapter(FragmentManager fm, int placeID) {
        super(fm);
        this.placeID = placeID;
    }

    public void initFragments() {
        placeDetailsFragment = new PlaceDetailsFragment();
        sightSeeingPlacesFragment = new SightSeeingPlacesFragment();
        facilitiesFragment = new FacilitiesFragment();


    }

    @Override
    public Fragment getItem(int position) {
        Fragment fragment = null;
        Bundle bundle = null;
        switch (position) {
            case 0:
                Log.e("tab", String.valueOf(0));
               /* fragment = placeDetailsFragment;
                bundle = new Bundle();
                bundle.putInt(StaticAccess.KEY_PLACE_ID_INTENT, placeID);
                fragment.setArguments(bundle);*/
                return PlaceDetailsFragment.newInstance(0, placeID);
            case 1:
                Log.e("tab", String.valueOf(1));

               /* fragment = sightSeeingPlacesFragment;
                bundle = new Bundle();
                bundle.putInt(StaticAccess.KEY_PLACE_ID_INTENT, placeID);
                fragment.setArguments(bundle);*/
                return SightSeeingPlacesFragment.newInstance(1, placeID);
            case 2:
                Log.e("tab", String.valueOf(2));

              /*  fragment = facilitiesFragment;
                bundle = new Bundle();
                bundle.putInt(StaticAccess.KEY_PLACE_ID_INTENT, placeID);
                fragment.setArguments(bundle);*/
                return FacilitiesFragment.newInstance(2, placeID);
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return 3;
    }

 /*   // This determines the title for each tab
    private String[] tabs = {"Details", "Sightseeing", "Facilities"};

    @Override
    public CharSequence getPageTitle(int position) {
        // Generate title based on item position
        switch (position) {
            case 0:
                return tabs[0];
            case 1:
                return tabs[1];
            case 2:
                return tabs[2];
            default:
                return null;
        }
    }*/
}
