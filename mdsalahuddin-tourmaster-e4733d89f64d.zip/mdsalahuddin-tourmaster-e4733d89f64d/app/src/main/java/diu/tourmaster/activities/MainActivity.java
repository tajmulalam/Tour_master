package diu.tourmaster.activities;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;


import com.miguelcatalan.materialsearchview.MaterialSearchView;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.fragments.FacilitiesFragment;
import diu.tourmaster.fragments.HomeFragment;
import diu.tourmaster.fragments.NavSightPlaceFragment;
import diu.tourmaster.fragments.PlacesFragment;
import diu.tourmaster.listener.SaveCompleteListener;
import diu.tourmaster.listener.SearchTextGetListener;
import diu.tourmaster.utils.ApkSaverAsynTask;
import diu.tourmaster.utils.CustomToast;
import diu.tourmaster.utils.MemoryChecker;
import diu.tourmaster.utils.SharedPreferenceValues;
import diu.tourmaster.utils.ToolbarConfig;
import diu.tourmaster.utils.TypefaceSpan;

public class MainActivity extends BaseActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    NavigationView navigationView;
    MainActivity activity;
    TextView tvLocationNav, tvLanguage;
    MaterialSearchView searchView;
    private SearchTextGetListener searchTextGetListener;
    private DrawerLayout drawer;

    public void setSearchTextGetListener(SearchTextGetListener searchTextGetListener) {
        this.searchTextGetListener = searchTextGetListener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BaseActivity.setLocale(this);
        setContentView(R.layout.activity_main);
        activity = this;
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        searchView = (MaterialSearchView) findViewById(R.id.search_view);
        searchView.setOnQueryTextListener(onQueryTextListener);
        searchView.setOnSearchViewListener(searchViewListener);
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        View header = navigationView.getHeaderView(0);
        tvLocationNav = (TextView) header.findViewById(R.id.tvLocationNav);
        tvLanguage = (TextView) header.findViewById(R.id.tvLanguage);
        tvLanguage.setText(SharedPreferenceValues.getLanguage(activity));
        tvLanguage.setOnClickListener(onClickListener);
        navigationView.setNavigationItemSelectedListener(this);
        settingEnvironmentLoginUserWise();
        displaySelectedScreen(R.id.nav_home);
        ToolbarConfig.makeStatusBarTransparent(getWindow());
    }

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            showLanguageSelectionDialog();
        }
    };

    int lanPose = -1;
    List<String> languageList = new ArrayList<>();

    private void showLanguageSelectionDialog() {
        languageList = Arrays.asList(getResources().getStringArray(R.array.language));
        final String[] items = new String[languageList.size()];
        final String[] ids = new String[languageList.size()];
        for (int i = 0; i < languageList.size(); i++) {
            items[i] = languageList.get(i);
            ids[i] = String.valueOf(languageList.get(i));
            if (!tvLanguage.getText().toString().trim().equals("")) {
                if (tvLanguage.getText().toString().trim().equals(languageList.get(i)))
                    lanPose = i;
            }
        }
        AlertDialog periodDialog = null;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.language));
        builder.setSingleChoiceItems(items, lanPose, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int item) {
                lanPose = item;
                tvLanguage.setText(items[item]);
                dialog.dismiss();
                SharedPreferenceValues.clearLanguage(activity);
                SharedPreferenceValues.setLanguage(activity, languageList.get(lanPose));
                reloadActivity();
            }
        });
        periodDialog = builder.create();
        periodDialog.show();
    }

    private void reloadActivity() {
        Intent refresh = new Intent(this, MainActivity.class);
        startActivity(refresh);
        finish();
    }

    public void settingEnvironmentLoginUserWise() {
        if (SharedPreferenceValues.getWizardSelectedPlace(activity) != null) {
            navigationView.getMenu().findItem(R.id.nav_sight_places).setVisible(true);
            navigationView.getMenu().findItem(R.id.nav_mode_of_transport).setVisible(true);
            navigationView.getMenu().findItem(R.id.nav_facilities_available).setVisible(true);
            navigationView.getMenu().findItem(R.id.nav_tourist_security).setVisible(true);
            navigationView.getMenu().findItem(R.id.nav_festival_calender).setVisible(true);
            navigationView.getMenu().findItem(R.id.nav_heritage_gallery).setVisible(true);
            navigationView.getMenu().findItem(R.id.nav_share).setVisible(true);
            navigationView.getMenu().findItem(R.id.nav_about_us).setVisible(true);
           /* if (SharedPreferenceValues.getLanguage(activity).equalsIgnoreCase("English")) {
                navigationView.getMenu().findItem(R.id.nav_communicate).setTitle(Html.fromHtml("<font color='#ffffff'>Communicate</font>"));
            } else {
                navigationView.getMenu().findItem(R.id.nav_communicate).setTitle(Html.fromHtml("<font color='#ffffff'>যোগাযোগ</font>"));
            }*/
        } else {
            navigationView.getMenu().findItem(R.id.nav_sight_places).setVisible(false);
            navigationView.getMenu().findItem(R.id.nav_mode_of_transport).setVisible(false);
            navigationView.getMenu().findItem(R.id.nav_facilities_available).setVisible(false);
            navigationView.getMenu().findItem(R.id.nav_tourist_security).setVisible(true);
            navigationView.getMenu().findItem(R.id.nav_festival_calender).setVisible(true);
            navigationView.getMenu().findItem(R.id.nav_heritage_gallery).setVisible(true);
            navigationView.getMenu().findItem(R.id.nav_share).setVisible(true);
            navigationView.getMenu().findItem(R.id.nav_about_us).setVisible(true);
            /*if (SharedPreferenceValues.getLanguage(activity).equalsIgnoreCase("English")) {
                navigationView.getMenu().findItem(R.id.nav_communicate).setTitle(Html.fromHtml("<font color='#ffffff'>Communicate</font>"));
            } else {
                navigationView.getMenu().findItem(R.id.nav_communicate).setTitle(Html.fromHtml("<font color='#ffffff'>যোগাযোগ</font>"));
            }*/
        }
        navigationView.getMenu().findItem(R.id.nav_mode_of_transport).setVisible(false);

       /* if (SharedPreferenceValues.getWizardSelectedPlace(activity) != null) {
            changeNavHeaderTitle(SharedPreferenceValues.getWizardSelectedPlace(activity).getSightseeingPlaceName());
        } else {
            changeNavHeaderTitle(getString(R.string.unknown_location));
        }*/
        changeFont();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } /*else {
            super.onBackPressed();
        }*/
        /*int count = getFragmentManager().getBackStackEntryCount();

        if (count == 0) {
            super.onBackPressed();
            //additional code
        } else {
        }*/
        boolean isHome = false;
        List<Fragment> fragmentList = getSupportFragmentManager().getFragments();
        if (fragmentList != null && fragmentList.size() > 0) {
            for (Fragment fragment : fragmentList) {
                if (fragment instanceof HomeFragment) {
                    isHome = true;
                    break;
                }
            }
        }
        if (isHome) {
            super.onBackPressed();
        } else {
            displaySelectedScreen(R.id.nav_home);
        }
    }

    private void changeFont() {
        Menu menu = navigationView.getMenu();
        Typeface typeface = Typeface.createFromAsset(activity.getAssets(), "font/rancho3.ttf");

        for (int i = 0; i < menu.size(); i++) {
            MenuItem menuItem = menu.getItem(i);

            if (menuItem != null) {
                SpannableString spannableString = new SpannableString(menuItem.getTitle());
                spannableString.setSpan(new TypefaceSpan(typeface), 0, spannableString.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

                menuItem.setTitle(spannableString);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        MenuItem item = menu.findItem(R.id.action_search);
        searchView.setMenuItem(item);
        return true;
    }

    public void visibleSearchBar() {
        searchView.setVisibility(View.VISIBLE);
    }

    public void makeSearchBarGone() {
        searchView.setVisibility(View.GONE);
    }

    MaterialSearchView.OnQueryTextListener onQueryTextListener = new MaterialSearchView.OnQueryTextListener() {
        @Override
        public boolean onQueryTextSubmit(String query) {
            searchTextGetListener.searchText(query);
            return false;
        }

        @Override
        public boolean onQueryTextChange(String newText) {
            searchTextGetListener.searchText(newText);
            return false;
        }

    };
    MaterialSearchView.SearchViewListener searchViewListener = new MaterialSearchView.SearchViewListener() {
        @Override
        public void onSearchViewShown() {

        }

        @Override
        public void onSearchViewClosed() {
            searchTextGetListener.resetSearch();
        }
    };

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        displaySelectedScreen(id);
        return true;
    }

    public void displaySelectedScreen(int id) {
        Fragment fragment = null;
        switch (id) {
            case R.id.nav_home:
                fragment = new HomeFragment();
                break;
            case R.id.nav_places:
                fragment = new PlacesFragment();
                break;
            case R.id.nav_sight_places:
                if (checkLocationIsAvailable()) {
                    fragment = NavSightPlaceFragment.newInstance(0, SharedPreferenceValues.getWizardSelectedPlace(activity).getTourismPlaceId());
                } else {
                    CustomToast.makeToastWarning(activity, getString(R.string.no_record_for_locaiton));
                }
                break;
            case R.id.nav_mode_of_transport:
                startActivity(new Intent(activity, ModeOfTransportActivity.class));
                break;
            case R.id.nav_facilities_available:
                if (checkLocationIsAvailable()) {

                    fragment = FacilitiesFragment.newInstance(0, SharedPreferenceValues.getWizardSelectedPlace(activity).getTourismPlaceId());
                } else {
                    CustomToast.makeToastWarning(activity, getString(R.string.no_record_for_locaiton));
                }
                break;

            case R.id.nav_tourist_security:
                startActivity(new Intent(activity, TouristSecurityActivity.class));
                break;
            case R.id.nav_festival_calender:
                startActivity(new Intent(activity, FestivalCalenderActivity.class));
                break;
            case R.id.nav_heritage_gallery:
                startActivity(new Intent(activity, HeritageGalleryActivity.class));
                break;
            case R.id.nav_share:
                generateApk();
                break;
            case R.id.nav_about_us:
                startActivity(new Intent(activity, AboutUsActivity.class));
                break;
            default:
                fragment = new HomeFragment();
                break;
        }
        if (fragment != null) {
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.rlContent, fragment);
            fragmentTransaction.commit();
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
    }

    public boolean checkLocationIsAvailable() {
        return SharedPreferenceValues.getWizardSelectedPlace(activity) != null;
    }

    public void changeNavHeaderTitle(String title) {
        tvLocationNav.setText(title);
    }

    public void generateApk() {
        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(getPackageName(), 0);
            File srcFile = new File(ai.publicSourceDir);
            Intent share = new Intent();
            share.setAction(Intent.ACTION_SEND);
            share.setType("application/vnd.android.package-archive");
            share.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(srcFile));
            startActivity(Intent.createChooser(share, getString(R.string.share) + " " + getString(R.string.app_name)));
        } catch (Exception e) {
            Log.e("ShareApp", e.getMessage());
        }
    }

    public void controlDrawer(boolean isEnabled) {
        if (isEnabled) {
            drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNDEFINED);
        } else {
            drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
        }
    }
}
