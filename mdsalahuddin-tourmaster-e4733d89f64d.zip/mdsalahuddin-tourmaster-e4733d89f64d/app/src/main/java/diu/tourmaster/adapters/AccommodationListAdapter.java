package diu.tourmaster.adapters;

import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.models.Accommodation;
import diu.tourmaster.utils.Configs;
import diu.tourmaster.utils.StaticAccess;

/**
 * Created by tajmulalam on 1/12/18.
 */

public class AccommodationListAdapter extends RecyclerView.Adapter<AccommodationListAdapter.AccommodationListViewHolder> {

    private Context mContext;
    private List<Accommodation> accommodationList;
    private AccommodationClickedListener accommodationClickedListener;

    public AccommodationListAdapter(Context mContext, List<Accommodation> accommodationList, AccommodationClickedListener accommodationClickedListener) {
        this.mContext = mContext;
        this.accommodationList = accommodationList;
        this.accommodationClickedListener = accommodationClickedListener;
    }

    @Override
    public AccommodationListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.place_list_custom_row, null);
        return new AccommodationListViewHolder(view);
    }


    public void onBindViewHolder(AccommodationListViewHolder holder, final int position) {
        String photoUrl = accommodationList.get(position).getPhotos() != null ? Configs.BASE_URL + accommodationList.get(position).getPhotos().getPhotoPath().replace(StaticAccess.FTP_ADDRESS, "") : "";
        if (TextUtils.isEmpty(photoUrl)) {
            Picasso.with(mContext)
                    .load(R.drawable.placeholder)
                    .error(R.drawable.placeholder)
                    .into(holder.ivPlaceImage);
        } else {
            Picasso.with(mContext)
                    .load(photoUrl)
                    .error(R.drawable.placeholder)
                    .into(holder.ivPlaceImage);
        }
        holder.tvTitle.setText(accommodationList.get(position).getHotelName());
        holder.cvPlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                accommodationClickedListener.accommodationClicked(accommodationList.get(position));
            }
        });
        holder.tvTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                accommodationClickedListener.accommodationClicked(accommodationList.get(position));

            }
        });
        holder.ivPlaceImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                accommodationClickedListener.accommodationClicked(accommodationList.get(position));

            }
        });
    }

    @Override
    public int getItemCount() {
        return accommodationList.size() > 0 ? accommodationList.size() : 0;
    }

    public class AccommodationListViewHolder extends RecyclerView.ViewHolder {
        private ImageView ivPlaceImage;
        private TextView tvTitle;
        private CardView cvPlace;

        public AccommodationListViewHolder(View itemView) {
            super(itemView);
            ivPlaceImage = itemView.findViewById(R.id.ivPlaceImage);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            cvPlace = itemView.findViewById(R.id.cvPlace);
        }
    }

    public interface AccommodationClickedListener {
        void accommodationClicked(Accommodation accommodation);
    }
}
