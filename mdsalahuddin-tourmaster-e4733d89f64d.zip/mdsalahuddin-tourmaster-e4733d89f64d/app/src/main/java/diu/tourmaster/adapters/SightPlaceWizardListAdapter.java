package diu.tourmaster.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.models.SightSeeingPlace;
import diu.tourmaster.utils.SharedPreferenceValues;

/**
 * Created by tajmulalam on 1/12/18.
 */

public class SightPlaceWizardListAdapter extends RecyclerView.Adapter<SightPlaceWizardListAdapter.SightPlaceWizardListViewHolder> {

    private Context mContext;
    private List<SightSeeingPlace> sightSeeingPlaceList;
    private WizardPlaceSelectListener wizardPlaceSelectListener;

    public SightPlaceWizardListAdapter(Context mContext, List<SightSeeingPlace> sightSeeingPlaceList, WizardPlaceSelectListener wizardPlaceSelectListener) {
        this.mContext = mContext;
        this.sightSeeingPlaceList = sightSeeingPlaceList;
        this.wizardPlaceSelectListener = wizardPlaceSelectListener;
    }

    @Override
    public SightPlaceWizardListAdapter.SightPlaceWizardListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sight_wizard_place_list_custom_row, null);
        return new SightPlaceWizardListViewHolder(view);
    }


    public void onBindViewHolder(SightPlaceWizardListViewHolder holder, final int position) {
        holder.tvSightPlace.setText(sightSeeingPlaceList.get(position).getSightseeingPlaceName());
       /* if (SharedPreferenceValues.getWizardSelectedPlace(mContext) != null && SharedPreferenceValues.getWizardSelectedPlace(mContext).getSightseeingPlaceId() == sightSeeingPlaceList.get(position).getSightseeingPlaceId()) {
            holder.ivPlaceActive.setVisibility(View.VISIBLE);
        } else {
            holder.ivPlaceActive.setVisibility(View.GONE);
        }*/
        holder.tvSightPlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                wizardPlaceSelectListener.sightPlaceSelected(sightSeeingPlaceList.get(position));
            }
        });
    }

    @Override
    public int getItemCount() {
        return sightSeeingPlaceList.size() > 0 ? sightSeeingPlaceList.size() : 0;
    }

    public class SightPlaceWizardListViewHolder extends RecyclerView.ViewHolder {
        private TextView tvSightPlace;
        private ImageView ivPlaceActive;

        public SightPlaceWizardListViewHolder(View itemView) {
            super(itemView);
            tvSightPlace = itemView.findViewById(R.id.tvSightPlace);
            ivPlaceActive = itemView.findViewById(R.id.ivPlaceActive);
        }
    }

    public interface WizardPlaceSelectListener {
        void sightPlaceSelected(SightSeeingPlace sightSeeingPlace);
    }
}
