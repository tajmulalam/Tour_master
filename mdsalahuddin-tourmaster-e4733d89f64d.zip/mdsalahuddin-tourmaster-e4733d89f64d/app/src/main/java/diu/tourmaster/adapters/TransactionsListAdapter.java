package diu.tourmaster.adapters;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.models.NearestTransaction;
import diu.tourmaster.models.Restaurant;

/**
 * Created by tajmulalam on 1/12/18.
 */

public class TransactionsListAdapter extends RecyclerView.Adapter<TransactionsListAdapter.TransactionsListViewHolder> {
    private Context mContext;
    private List<NearestTransaction> nearestTransactionList;
    private TransactionClickedListener transactionClickedListener;
    GoogleMap map;

    public TransactionsListAdapter(Context mContext, List<NearestTransaction> nearestTransactionList, TransactionClickedListener transactionClickedListener) {
        this.mContext = mContext;
        this.nearestTransactionList = nearestTransactionList;
        this.transactionClickedListener = transactionClickedListener;
    }

    @Override
    public TransactionsListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.transaction_list_custom_row, null);
        return new TransactionsListViewHolder(view);
    }


    public void onBindViewHolder(TransactionsListViewHolder holder, final int position) {

        holder.tvTitle.setText(nearestTransactionList.get(position).getBankOrBoothName());
        holder.tvAddress.setText(nearestTransactionList.get(position).getAddress());
        holder.cvPlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                transactionClickedListener.bankOrBoothClicked(nearestTransactionList.get(position));
            }
        });
        holder.tvTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                transactionClickedListener.bankOrBoothClicked(nearestTransactionList.get(position));

            }
        });
        holder.tvAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                transactionClickedListener.bankOrBoothClicked(nearestTransactionList.get(position));

            }
        });
        holder.ibtnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showInternetCheckerDialog(position);
            }
        });

    }

    @Override
    public int getItemCount() {
        return nearestTransactionList.size() > 0 ? nearestTransactionList.size() : 0;
    }

    public class TransactionsListViewHolder extends RecyclerView.ViewHolder {

        private TextView tvAddress;
        private TextView tvTitle;
        private CardView cvPlace;
        private ImageButton ibtnMap;

        public TransactionsListViewHolder(View itemView) {
            super(itemView);
            tvAddress = itemView.findViewById(R.id.tvAddress);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            cvPlace = itemView.findViewById(R.id.cvPlace);
            ibtnMap = itemView.findViewById(R.id.ibtnMap);
            // mapView.onCreate();

        }
    }

    public interface TransactionClickedListener {
        void bankOrBoothClicked(NearestTransaction nearestTransaction);
    }

    private void showInternetCheckerDialog(final int position) {
        final Dialog dialog = new Dialog(mContext, R.style.CustomAlertDialog);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog_show_map);
        dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        Button btnNetworkCheckerDone = dialog.findViewById(R.id.btnNetworkCheckerDone);
        MapView mapView = dialog.findViewById(R.id.mapView);
        mapView.onCreate(null);
        mapView.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(GoogleMap googleMap) {
                map = googleMap;
                map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                } else {
                    map.setMyLocationEnabled(true);
                }
                map.setTrafficEnabled(true);
                map.setIndoorEnabled(true);
                map.setBuildingsEnabled(true);
                map.getUiSettings().setZoomControlsEnabled(true);
                if (map != null) {
                    CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(new LatLng(Double.valueOf(nearestTransactionList.get(position).getLatitude()), Double.valueOf(nearestTransactionList.get(position).getLongitude())), 18);
                    map.animateCamera(cameraUpdate);
                    MarkerOptions marker = new MarkerOptions().position(new LatLng(Double.valueOf(nearestTransactionList.get(position).getLatitude()), Double.valueOf(nearestTransactionList.get(position).getLongitude())));
                    marker.title(nearestTransactionList.get(position).getBankOrBoothName() + "\n" + nearestTransactionList.get(position).getAddress());
                    map.addMarker(marker);

                }
            }
        });
        mapView.onResume();
        btnNetworkCheckerDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }
}
