package diu.tourmaster.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

import diu.tourmaster.R;
import diu.tourmaster.utils.CustomToast;
import diu.tourmaster.utils.StaticAccess;

public class VideoPlayActivity extends YouTubeBaseActivity {
    public static final String YT_API_KEY = "AIzaSyCq18GE0u4wUvCMZv7PBfl-YcNzjY8siSg";
    YouTubePlayerView youTubePlayerView;
    private String videoLink = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_play);
        youTubePlayerView =
                (YouTubePlayerView) findViewById(R.id.player);
        receiveIntent();
    }

    private void receiveIntent() {
        videoLink = getIntent() != null ? getIntent().getStringExtra(StaticAccess.KEY_VIDEO_LINK_INTENT) : "";
        Log.e("link", videoLink);
        if (!TextUtils.isEmpty(videoLink)) {
            playVideo(getFormatUrl(videoLink));
        }
    }

    private String getFormatUrl(String videoLink) {
        String link = videoLink.replace("https://www.youtube.com/embed/", "");
        return link.replace("https://www.youtube.com/watch?v=", "");
    }

    public void playVideo(final String videoLink) {
        youTubePlayerView.initialize(YT_API_KEY,
                new YouTubePlayer.OnInitializedListener() {
                    @Override
                    public void onInitializationSuccess(YouTubePlayer.Provider provider,
                                                        YouTubePlayer youTubePlayer, boolean b) {

                        // do any work here to cue video, play video, etc.
                        //youTubePlayer.cueVideo("5xVh-7ywKpE");
                        // or to play immediately
                        youTubePlayer.loadVideo(videoLink);
                    }

                    @Override
                    public void onInitializationFailure(YouTubePlayer.Provider provider,
                                                        YouTubeInitializationResult youTubeInitializationResult) {
                        //Toast.makeText(VideoPlayActivity.this, "Youtube Failed!", Toast.LENGTH_SHORT).show();
                        CustomToast.makeToastWarning(VideoPlayActivity.this, "Youtube Failed!");

                    }
                });
    }
}
