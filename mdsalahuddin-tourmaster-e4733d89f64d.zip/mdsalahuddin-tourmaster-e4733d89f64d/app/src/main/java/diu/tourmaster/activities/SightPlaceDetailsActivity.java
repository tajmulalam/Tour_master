package diu.tourmaster.activities;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.controllers.CommonController;
import diu.tourmaster.models.Photos;
import diu.tourmaster.models.SightSeeingPlace;
import diu.tourmaster.models.SliderModel;
import diu.tourmaster.models.TourismPlace;
import diu.tourmaster.utils.Configs;
import diu.tourmaster.utils.CustomToast;
import diu.tourmaster.utils.SharedPreferenceValues;
import diu.tourmaster.utils.StaticAccess;
import diu.tourmaster.utils.ToolbarConfig;
import diu.tourmaster.utils.Utilities;
import ss.com.bannerslider.banners.Banner;
import ss.com.bannerslider.banners.DrawableBanner;
import ss.com.bannerslider.banners.RemoteBanner;
import ss.com.bannerslider.views.BannerSlider;

public class SightPlaceDetailsActivity extends BaseActivity implements OnMapReadyCallback {

    private TextView tvPlaceName, tvPlaceDetails;
    private MapView mapView;
    private BannerSlider bannerSlider;
    private GoogleMap map;
    private SightPlaceDetailsActivity activity;
    private CommonController commonController;
    private Integer sightPlaceID = -1;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BaseActivity.setLocale(this);

        setContentView(R.layout.activity_sight_place_details);
        receiveIntent();
        initToolbar();
        initUI(savedInstanceState);
        callApi();
    }

    private void initUI(Bundle savedInstanceState) {
        activity = this;
        bannerSlider = findViewById(R.id.bannerSlider);
        tvPlaceName = findViewById(R.id.tvPlaceName);
        tvPlaceDetails = findViewById(R.id.tvPlaceDetails);
        mapView = (MapView) findViewById(R.id.mapView);
        mapView.onCreate(savedInstanceState);
        mapView.getMapAsync(this);
        commonController = new CommonController(activity);

    }

    private void initToolbar() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //ToolbarConfig.centerTitleAndSubtitle(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishTheActivity();
            }
        });
        ToolbarConfig.makeStatusBarTransparent(getWindow());
    }

    private void finishTheActivity() {
        finish();
    }

    private void receiveIntent() {
        sightPlaceID = getIntent() != null ? getIntent().getIntExtra(StaticAccess.KEY_SIGHT_PLACE_ID_INTENT, -1) : -1;
    }

    private void callApi() {
        HashMap<String, String> params = Utilities.getInstance().getRequestParams();
        params.put("sightseeing_place_id", String.valueOf(sightPlaceID));
        commonController.callApi(CommonController.REQUEST_SINGLE_SIGHT_PLACE, params, true);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.map = googleMap;
        map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

        } else {
            map.setMyLocationEnabled(true);
        }
        map.setTrafficEnabled(true);
        map.setIndoorEnabled(true);
        map.setBuildingsEnabled(true);
        map.getUiSettings().setZoomControlsEnabled(true);
    }

    @Override
    public void onResume() {
        mapView.onResume();
        super.onResume();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }

    public void showErrorMsg(String msg) {
        //Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show();
        CustomToast.makeToastWarning(activity,msg);

    }

    public void updatePlace(SightSeeingPlace place) {
        setTitle(place.getSightseeingPlaceName());
        tvPlaceDetails.setText(place.getDescription());
        tvPlaceName.setText(place.getSightseeingPlaceName());
        if (map != null) {

            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(new LatLng(Double.valueOf(place.getLatitude()), Double.valueOf(place.getLongitude())), 14);
            map.animateCamera(cameraUpdate);
            MarkerOptions marker = new MarkerOptions().position(new LatLng(Double.valueOf(place.getLatitude()), Double.valueOf(place.getLongitude())));
            marker.title(place.getSightseeingPlaceName());
            map.addMarker(marker);
            //mapView.requestFocus();
            loadBannerSlider(place.getAllPhotos());
        }
    }

    public void loadBannerSlider(List<Photos> photosList) {
        List<Banner> banners = new ArrayList<>();
        if (photosList != null && photosList.size() > 0) {
            for (Photos photos : photosList) {
                //add banner using image url
                RemoteBanner remoteBanner = new RemoteBanner(Configs.BASE_URL + photos.getPhotoPath());
                remoteBanner.setScaleType(ImageView.ScaleType.FIT_XY);
                banners.add(remoteBanner);
                //add banner using resource drawable
            }
        } else {
            DrawableBanner drawableBanner = new DrawableBanner(R.drawable.placeholder);
            drawableBanner.setScaleType(ImageView.ScaleType.FIT_XY);
            banners.add(drawableBanner);
        }
        bannerSlider.setBanners(banners);
    }

}
