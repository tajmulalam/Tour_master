package diu.tourmaster.utils;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

import java.io.File;
import java.io.IOException;
import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.listener.SaveCompleteListener;


/**
 * Created by tajmulalam on 11/6/17.
 */

public class ApkSaverAsynTask extends AsyncTask<Void, Void, Void> {
    private Context context;
    private File file;
    ProgressDialog progressDialog = null;
    private String fileName;
    private boolean isCompleteWithNoerror = false;
    SaveCompleteListener saveCompleteListener;
    boolean isMultiple = false;
    List<File> fileList;
    List<String> fileNameList;

    public ApkSaverAsynTask(Context context, File file, String fileName, SaveCompleteListener saveCompleteListener) {
        this.context = context;
        this.file = file;
        this.fileName = fileName;
        this.saveCompleteListener = saveCompleteListener;
        this.isMultiple=false;

    }

    public ApkSaverAsynTask(Context context, List<File> fileList, List<String> fileNameList, SaveCompleteListener saveCompleteListener) {
        this.context = context;
        this.fileList = fileList;
        this.fileNameList = fileNameList;
        this.saveCompleteListener = saveCompleteListener;
        this.isMultiple = true;
    }

    @Override
    protected void onPreExecute() {
        progressDialog = ProgressDialog.show(context, context.getString(R.string.loader_loading), context.getString(R.string.loader_loading));
        super.onPreExecute();
    }

    @Override
    protected Void doInBackground(Void... voids) {
        if (isMultiple) {
            for (int i = 0; i < fileList.size(); i++) {
                file = fileList.get(i);
                fileName = fileNameList.get(i);
                ///start copying one by one
                File f2 = new File(StaticAccess.ROOT_APK_SAVE_PATH);
                //f2.mkdirs();
                f2 = new File(f2.getPath() + "/" + fileName + ".apk");
                //Copier.copyFile(file, f2);
                System.out.println("File copied.");
                isCompleteWithNoerror = true;
            }
        } else {
            File f2 = new File(StaticAccess.ROOT_APK_SAVE_PATH);
            //f2.mkdirs();
            f2 = new File(f2.getPath() + "/" + fileName + ".apk");
            //Copier.copyFile(file, f2);
            /*f2.createNewFile();
            InputStream in = new FileInputStream(file);

            OutputStream out = new FileOutputStream(f2);

            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();*/
            System.out.println("File copied.");
            isCompleteWithNoerror = true;
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        progressDialog.dismiss();
        saveCompleteListener.isSavedComplete(isCompleteWithNoerror);
        super.onPostExecute(aVoid);
    }

}
