package diu.tourmaster.fragments;


import android.Manifest;
import android.animation.ObjectAnimator;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.HashMap;

import diu.tourmaster.R;
import diu.tourmaster.activities.PlaceDetailsActivity;
import diu.tourmaster.controllers.CommonController;
import diu.tourmaster.models.TourismPlace;
import diu.tourmaster.utils.CustomToast;
import diu.tourmaster.utils.StaticAccess;
import diu.tourmaster.utils.Utilities;

/**
 * A simple {@link Fragment} subclass.
 */
public class PlaceDetailsFragment extends Fragment implements OnMapReadyCallback {
    private TextView tvPlaceDetails,tvPlaceName;
    private int placeID = -1;
    private PlaceDetailsActivity activity;
    private CommonController commonController;
    MapView mapView;
    GoogleMap map;
    private ScrollView scPlaceDetails;

    public PlaceDetailsFragment() {
        // Required empty public constructor
    }

    // newInstance constructor for creating fragment with arguments
    public static PlaceDetailsFragment newInstance(int page, int placeID) {
        PlaceDetailsFragment placeDetailsFragment = new PlaceDetailsFragment();
        Bundle args = new Bundle();
        args.putInt("someInt", page);
        args.putInt(StaticAccess.KEY_PLACE_ID_INTENT, placeID);
        placeDetailsFragment.setArguments(args);
        return placeDetailsFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_place_details, container, false);
        receveBundle();
        mapView = (MapView) view.findViewById(R.id.mapView);
        mapView.onCreate(savedInstanceState);
        mapView.getMapAsync(this);
        initUI(view);
        callApi();
        return view;
    }

    private void callApi() {
        HashMap<String, String> params = Utilities.getInstance().getRequestParams();
        params.put("tourism_place_id", String.valueOf(placeID));
        commonController.callApi(CommonController.REQUEST_SINGLE_PLACE, params, true);
    }

    private void receveBundle() {
        activity = (PlaceDetailsActivity) getActivity();
        commonController = new CommonController(activity);
        Bundle bundle = getArguments();
        placeID = bundle != null ? bundle.getInt(StaticAccess.KEY_PLACE_ID_INTENT, -1) : -1;
    }

    private void initUI(View view) {
        tvPlaceDetails = view.findViewById(R.id.tvPlaceDetails);
        tvPlaceName = view.findViewById(R.id.tvPlaceName);
        scPlaceDetails = view.findViewById(R.id.scPlaceDetails);
      /*  ViewTreeObserver vto = tvPlaceDetails.getViewTreeObserver();
        vto.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    tvPlaceDetails.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                }
                ObjectAnimator.ofInt(scPlaceDetails, "scrollY", (int) tvPlaceDetails.getY()).setDuration(1500).start();
            }
        });*/

    }

    public void showErrorMsg(String msg) {
        CustomToast.makeToastWarning(activity, msg);

    }

    public void updatePlace(TourismPlace place) {
        tvPlaceDetails.setText(place.getDescription());
        tvPlaceName.setText(place.getPlaceName());
        getActivity().setTitle(place.getPlaceName());
        if (map != null) {

            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(new LatLng(Double.valueOf(place.getLatitude()), Double.valueOf(place.getLongitude())), 10);
            map.animateCamera(cameraUpdate);
            MarkerOptions marker = new MarkerOptions().position(new LatLng(Double.valueOf(place.getLatitude()), Double.valueOf(place.getLongitude())));
            marker.title(place.getPlaceName());
            map.addMarker(marker);
            //mapView.requestFocus();
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.map = googleMap;
        map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

        } else {
            map.setMyLocationEnabled(true);
        }
        map.setTrafficEnabled(true);
        map.setIndoorEnabled(true);
        map.setBuildingsEnabled(true);
        map.getUiSettings().setZoomControlsEnabled(true);
    }

    @Override
    public void onResume() {
        mapView.onResume();
        super.onResume();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }

}
