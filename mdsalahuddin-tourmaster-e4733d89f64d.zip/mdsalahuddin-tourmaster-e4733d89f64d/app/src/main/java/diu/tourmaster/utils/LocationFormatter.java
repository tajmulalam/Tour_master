package diu.tourmaster.utils;

/**
 * Created by tajmulalam on 1/10/18.
 */
public class LocationFormatter {
    public static double format4DecimalPlace(double val) {
        //That's for 4 digits precision. The number of zeros indicate the number of decimals
        return (double) Math.round(val * 10000d) / 10000d;
    }
}