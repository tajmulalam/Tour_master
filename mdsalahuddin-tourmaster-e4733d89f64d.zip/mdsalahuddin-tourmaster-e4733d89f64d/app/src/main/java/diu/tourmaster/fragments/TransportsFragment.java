package diu.tourmaster.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.adapters.EmptyAdapter;
import diu.tourmaster.adapters.TransportListAdapter;
import diu.tourmaster.controllers.CommonController;
import diu.tourmaster.models.Transport;
import diu.tourmaster.utils.CustomToast;
import diu.tourmaster.utils.StaticAccess;
import diu.tourmaster.utils.Utilities;

public class TransportsFragment extends Fragment {
    private int placeID = -1;
    private int transportType = -1;
    private RecyclerView rvTransportList;
    private RecyclerView.Adapter adapter;
    private Context mContext;
    private List<Transport> mTransportList;
    private SwipeRefreshLayout swTransport;

    public static TransportsFragment newInstance(int transportType, int placeID) {
        TransportsFragment fragment = new TransportsFragment();
        Bundle args = new Bundle();
        args.putInt(StaticAccess.TRANSPORT_TYPE, transportType);
        args.putInt(StaticAccess.KEY_PLACE_ID_INTENT, placeID);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_transports, container, false);
        receiveArguments();
        initUI(view);
        apiCall();
        return view;
    }

    private void receiveArguments() {
        mContext = getContext();
        mTransportList = new ArrayList<>();
        Bundle bundle = getArguments();
        placeID = bundle != null ? bundle.getInt(StaticAccess.KEY_PLACE_ID_INTENT, -1) : -1;
        transportType = bundle != null ? bundle.getInt(StaticAccess.TRANSPORT_TYPE, -1) : -1;
    }

    private void initUI(View view) {
        rvTransportList = view.findViewById(R.id.rvTransportList);
        swTransport = view.findViewById(R.id.swTransport);
        rvTransportList.setLayoutManager(new LinearLayoutManager(mContext));
        rvTransportList.setHasFixedSize(true);
        swTransport.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                apiCall();
            }
        });
    }

    private void apiCall() {
        HashMap<String, String> params = Utilities.getInstance().getRequestParams();
        params.put("tourism_place_id", String.valueOf(placeID));
        new CommonController(mContext).callApi(CommonController.REQUEST_TRANSPORT_LIST_BY_PLACE, params, true);
    }

    public void showErrorMsg(String msg) {
        CustomToast.makeToastWarning(mContext, msg);
        rvTransportList.setAdapter(new EmptyAdapter());
        if (swTransport.isRefreshing()){
            swTransport.setRefreshing(false);
        }

    }

    public void updateList(List<Transport> transportList) {
        if (transportList != null && transportList.size() > 0)
            updateListByTransportType(transportList);

    }

    private void updateListByTransportType(List<Transport> transportList) {
        List<Transport> mList = new ArrayList<>();
        switch (transportType) {
            case StaticAccess.TAB_BUS:
                for (Transport transport : transportList) {
                    if (transport.getTransportType().equalsIgnoreCase("BUS")) {
                        mList.add(transport);
                    }
                }
                break;
            case StaticAccess.TAB_WATER:
                for (Transport transport : transportList) {
                    if (transport.getTransportType().equalsIgnoreCase("WATER")) {
                        mList.add(transport);
                    }
                }
                break;
            case StaticAccess.TAB_AIR:
                for (Transport transport : transportList) {
                    if (transport.getTransportType().equalsIgnoreCase("AIR")) {
                        mList.add(transport);
                    }
                }
                break;
            case StaticAccess.TAB_TRAIN:
                for (Transport transport : transportList) {
                    if (transport.getTransportType().equalsIgnoreCase("TRAIN")) {
                        mList.add(transport);
                    }
                }
                break;

        }
        if (mList.size() > 0) {
            adapter = new TransportListAdapter(mContext, mList);
            rvTransportList.setAdapter(adapter);
        }else {
            rvTransportList.setAdapter(new EmptyAdapter());
        }
        if (swTransport.isRefreshing()){
            swTransport.setRefreshing(false);
        }
    }
}
