package diu.tourmaster.activities;

import android.app.Dialog;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

import diu.tourmaster.R;
import diu.tourmaster.utils.ConnectionChecker;

public class NoInternetActivity extends BaseActivity {

    private NoInternetActivity activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_no_internet);
        activity = this;
        if (ConnectionChecker.isOnline(activity)) {
            if (ConnectionChecker.isWifiAvailable(activity) || ConnectionChecker.isMobileDataAvailable(activity)) {
                finish();
            }
        } else if (!ConnectionChecker.isOnline(activity)) {
            noInternetDialog(activity);
        }
    }

    void noInternetDialog(final Context mContext) {
        final Dialog dialog = new Dialog(mContext, R.style.CustomDialog);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.no_internet_dialog);
        RelativeLayout rlTryAgain = dialog.findViewById(R.id.rlTryAgain);
        rlTryAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ConnectionChecker.isOnline(mContext)) {
                    if (ConnectionChecker.isWifiAvailable(mContext) || ConnectionChecker.isMobileDataAvailable(mContext)) {
                        dialog.dismiss();
                    }
                } else if (!ConnectionChecker.isOnline(mContext)) {
                    ///noInternetDialog(mContext);
                    dialog.dismiss();
                    finish();
                }
            }
        });
        dialog.show();
    }
}
