package diu.tourmaster.utils;

/**
 * Created by tajmulalam on 1/11/18.
 */
public class Configs {
    public static final String BASE_URL = "http://www.tajmulalam.info/";
    public static final String URL_LOCATION_URL = BASE_URL + "TourismPlace/GetUserExactLoaction";
    public static final String URL_PLACE_LIST = BASE_URL + "TourismPlace/GetAllTourismPlaces";

    public static final String URL_SINGLE_PLACE = BASE_URL + "TourismPlace/GetPlaceByID";
    public static final String URL_SIGHT_SEEING_PLACE_LIST = BASE_URL + "SightseeingPlace/GetSightPlacesByPlaceID";
    public static final String URL_PlACE_WISE_ALL_SIGHT_PLACE_IMAGES = BASE_URL + "SightseeingPlace/SlidersByPlaceID";
    public static final String URL_SINGLE_SIGHT_PLACE = BASE_URL + "SightseeingPlace/GetSightseeingPlaceByID";
    public static final String URL_ACCOMMODATIONS_BY_PLACE_ID = BASE_URL + "Accommodation/GetAccommodationByPlaceID";
    public static final String URL_SINGLE_ACCOMMODATION = BASE_URL + "Accommodation/GetAccommodationByID";
    //    public static final String URL_FESTIVAL_LIST = BASE_URL + "Festivals/GetFestivalByDate";
    public static final String URL_FESTIVAL_LIST = BASE_URL + "Festivals/GetAllFestivals";
    public static final String URL_TRANSPORT_LIST_BY_PLACE = BASE_URL + "Transports/GetTransportByPlaceID";
    public static final String URL_RESTAURANTS_BY_PLACE = BASE_URL +"Foods/GetRestaurantsByPlaceID";
    public static final String URL_SINGLE_RESTAURANT = BASE_URL +"Foods/GetRestaurantByID";
    public static final String URL_BANKS_BY_PLACE = BASE_URL +"Transections/GetNearestTransectionByPlaceID";
    public static final String URL_TRAVEL_AGENT_BY_PLACE = BASE_URL +"TravelAgents/GetTravelAgentsByPlaceID";
    public static final String URL_TOUR_PRODUCTS_BY_PLACE = BASE_URL + "TourProducts/GetTourProductsByPlaceID";
    public static final String URL_CONTACT_LIST_BY_PLACE = BASE_URL+"Helpline/GetHelplneByPlaceID";
    public static final String URL_SINGLE_PRODUCT = BASE_URL + "TourProducts/GetProductByID";
    public static final String URL_VIDEO_CATEGORY_BY_PLACE = BASE_URL +"HeritageVideosCategory/GetAllVideoCategory";
    public static final String URL_VIDEO_LIST = BASE_URL + "HeritageVideoGallery/GetVideosByCategoryID";
}
