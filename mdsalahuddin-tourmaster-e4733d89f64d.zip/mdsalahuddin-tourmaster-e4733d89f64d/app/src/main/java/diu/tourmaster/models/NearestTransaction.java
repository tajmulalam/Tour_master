package diu.tourmaster.models;

/**
 * Created by Md Tajmul Alam on 1/21/2018.
 */

public class NearestTransaction {
    private Integer boothId;
    private String bankOrBoothName;
    private String latitude;
    private String longitude;
    private String address;
    private String description;
    private Integer status;
    private String createdAt;

    public Integer getBoothId() {
        return boothId;
    }

    public void setBoothId(Integer boothId) {
        this.boothId = boothId;
    }

    public String getBankOrBoothName() {
        return bankOrBoothName;
    }

    public void setBankOrBoothName(String bankOrBoothName) {
        this.bankOrBoothName = bankOrBoothName;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}
