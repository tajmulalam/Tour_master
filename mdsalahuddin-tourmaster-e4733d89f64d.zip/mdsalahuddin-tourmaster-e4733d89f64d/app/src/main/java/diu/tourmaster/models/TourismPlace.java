package diu.tourmaster.models;

import java.util.List;

/**
 * Created by tajmulalam on 1/12/18.
 */



public class TourismPlace {

    private Integer tourismPlaceId;
    private String placeName;
    private String latitude;
    private String longitude;
    private String description;
    private Integer status;
    private String createdAt;
    private List<Photos> photosList;
    private String coverPhoto;

    public Integer getTourismPlaceId() {
        return tourismPlaceId;
    }

    public void setTourismPlaceId(Integer tourismPlaceId) {
        this.tourismPlaceId = tourismPlaceId;
    }

    public String getPlaceName() {
        return placeName;
    }

    public void setPlaceName(String placeName) {
        this.placeName = placeName;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public List<Photos>  getPhotosList() {
        return photosList;
    }

    public void setPhotosList(List<Photos>  photosList) {
        this.photosList = photosList;
    }

    public void setCoverPhoto(String coverPhoto) {
        this.coverPhoto = coverPhoto;
    }

    public String getCoverPhoto() {
        return coverPhoto;
    }
}