package diu.tourmaster.activities;

import android.content.Intent;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.miguelcatalan.materialsearchview.MaterialSearchView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;

import diu.tourmaster.R;
import diu.tourmaster.adapters.AccommodationListAdapter;
import diu.tourmaster.adapters.EmptyAdapter;
import diu.tourmaster.adapters.VideoCategoryListAdapter;
import diu.tourmaster.controllers.CommonController;
import diu.tourmaster.models.Accommodation;
import diu.tourmaster.models.NearestTransaction;
import diu.tourmaster.models.VideoCategory;
import diu.tourmaster.utils.ConnectionChecker;
import diu.tourmaster.utils.CustomToast;
import diu.tourmaster.utils.StaticAccess;
import diu.tourmaster.utils.StaticInstance;
import diu.tourmaster.utils.ToolbarConfig;
import diu.tourmaster.utils.Utilities;

public class HeritageGalleryActivity extends BaseActivity implements VideoCategoryListAdapter.VideoCategoryClickedListener {
    private HeritageGalleryActivity activity;
    private RecyclerView rvCategoryList;
    private RecyclerView.Adapter adapter;
    private CommonController commonController;
    private MaterialSearchView searchView;
    private List<VideoCategory> mList;
private SwipeRefreshLayout swHeritages;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BaseActivity.setLocale(this);

        setContentView(R.layout.activity_heritage_gallery);
        activity = this;
        initStaticInstance();
        initToolbar();
        initUI();
        callApi();
    }

    private void initStaticInstance() {
        mList = new ArrayList<>();
        mFilterList = new ArrayList<>();
        staticInstance = StaticInstance.getInstance();
    }

    private void callApi() {
        HashMap<String, String> params = Utilities.getInstance().getRequestParams();
        commonController.callApi(CommonController.REQUEST_VIDEO_CATEGORY_BY_PLACE_ID, params, true);
    }


    private void initUI() {
        commonController = new CommonController(activity);
        searchView = (MaterialSearchView) findViewById(R.id.search_view);
        searchView.setOnQueryTextListener(onQueryTextListener);
        searchView.setOnSearchViewListener(searchViewListener);
        rvCategoryList = findViewById(R.id.rvCategoryList);
        swHeritages = findViewById(R.id.swHeritages);
        rvCategoryList.setHasFixedSize(true);
        rvCategoryList.setLayoutManager(new GridLayoutManager(activity, 2));
        swHeritages.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                callApi();
            }
        });
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle(getString(R.string.heritage_gallery));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishTheActivity();
            }
        });
        ToolbarConfig.makeStatusBarTransparent(getWindow());

    }

    private void finishTheActivity() {
        finish();
    }

    boolean isInstanceFull = false;

    public void updateCategoryList(List<VideoCategory> categoryList) {
        this.mList = categoryList;
        if (!isInstanceFull) {
            staticInstance.setVideoCategoryList(categoryList);
            isInstanceFull = true;
        }
        adapter = new VideoCategoryListAdapter(activity, categoryList, this);
        rvCategoryList.setAdapter(adapter);
        if (swHeritages.isRefreshing()){
            swHeritages.setRefreshing(false);
        }
    }

    public void showErrorMsg(String msg) {
        //Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show();
        CustomToast.makeToastWarning(activity, msg);
        rvCategoryList.setAdapter(new EmptyAdapter());
        if (swHeritages.isRefreshing()){
            swHeritages.setRefreshing(false);
        }

    }
    @Override
    public void categoryClicked(VideoCategory videoCategory) {
        if (ConnectionChecker.isOnline(activity)) {
            Intent intent = new Intent(activity, VideoListActivity.class);
            intent.putExtra(StaticAccess.KEY_CATEGORY_ID_ID_INTENT, videoCategory.getCategoryId());
            startActivity(intent);
            finish();
        }else {
            CustomToast.makeToastWarning(activity,getString(R.string.no_internet_connection_found_n_check_your_connection));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        MenuItem item = menu.findItem(R.id.action_search);
        searchView.setMenuItem(item);
        return true;
    }

    public void visibleSearchBar() {
        searchView.setVisibility(View.VISIBLE);
    }

    public void makeSearchBarGone() {
        searchView.setVisibility(View.GONE);
    }

    MaterialSearchView.OnQueryTextListener onQueryTextListener = new MaterialSearchView.OnQueryTextListener() {
        @Override
        public boolean onQueryTextSubmit(String query) {
            searchInList(query);
            return false;
        }

        @Override
        public boolean onQueryTextChange(String newText) {
            searchInList(newText);
            return false;
        }
    };

    MaterialSearchView.SearchViewListener searchViewListener = new MaterialSearchView.SearchViewListener() {
        @Override
        public void onSearchViewShown() {
        }
        @Override
        public void onSearchViewClosed() {
            resetSearch();
        }
    };

    private void searchInList(String keyword) {
        if (TextUtils.isEmpty(keyword)) {
            updateCategoryList(staticInstance.getVideoCategoryList());
        } else {
            Log.e("keyword", keyword);
            filterList(keyword);
        }
    }

    public void resetSearch() {
        updateCategoryList(staticInstance.getVideoCategoryList());
    }

    ///// sumon work start here
    private List<VideoCategory> mFilterList;
    StaticInstance staticInstance;

    /// actual filter method
    public void filterList(String charText) {
        if (charText.length() != 0 && staticInstance.getVideoCategoryList() != null && staticInstance.getVideoCategoryList().size() > 0) {
            List list = new ArrayList<>();
            ListIterator<VideoCategory> itr = staticInstance.getVideoCategoryList().listIterator();
            while (itr.hasNext()) {
                VideoCategory videoCategory = itr.next();
                if (videoCategory.getCategoryName() != null) {
                    if (videoCategory.getCategoryName().toLowerCase().contains(charText.toLowerCase())) {
                        list.add(videoCategory);
                    }
                }
            }
            if (mFilterList != null && mFilterList.size() > 0) {
                mFilterList.clear();
            }
            if (list.size() > 0) {
                mFilterList.addAll(list);
            }
        }
        updateCategoryList(mFilterList);
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (staticInstance != null) {
            staticInstance.clearVideoCategoryList();
        }
    }


}
