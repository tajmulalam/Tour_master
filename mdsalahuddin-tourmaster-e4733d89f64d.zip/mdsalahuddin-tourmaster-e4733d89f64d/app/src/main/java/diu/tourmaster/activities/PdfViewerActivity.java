package diu.tourmaster.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.util.HashMap;

import diu.tourmaster.R;
import diu.tourmaster.controllers.CommonController;
import diu.tourmaster.utils.CustomToast;
import diu.tourmaster.utils.StaticAccess;
import diu.tourmaster.utils.ToolbarConfig;
import diu.tourmaster.utils.Utilities;

public class PdfViewerActivity extends BaseActivity {
    private int placeID = -1;
    private WebView wbPlaceGuide;
    private PdfViewerActivity activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdf_viewer);
        receiveBundle();
        initToolbar();
        initUI();
        apiCall();
    }

    private void apiCall() {
        HashMap<String, String> params = Utilities.getInstance().getRequestParams();
        params.put("tourism_place_id", String.valueOf(placeID));
        new CommonController(activity).callApi(CommonController.REQUEST_TOUR_GUIDE, params, true);
    }

    private void initUI() {

        wbPlaceGuide = findViewById(R.id.wbPlaceGuide);

    }

    public void loadUrl(String url) {
        wbPlaceGuide.getSettings().setLoadsImagesAutomatically(true);
        wbPlaceGuide.getSettings().setJavaScriptEnabled(true);
        wbPlaceGuide.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        wbPlaceGuide.setWebViewClient(new WebViewClient());
//        String filename ="http://www3.nd.edu/~cpoellab/teaching/cse40816/android_tutorial.pdf";
//        wbPlaceGuide.loadUrl("http://docs.google.com/gview?embedded=true&url=" + filename);
        wbPlaceGuide.loadUrl("http://docs.google.com/gview?embedded=true&url=" + url);
    }

    private void receiveBundle() {
        activity = this;
        placeID = getIntent() != null ? getIntent().getIntExtra(StaticAccess.KEY_PLACE_ID_INTENT, -1) : -1;
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle(getString(R.string.tour_guide));
        //ToolbarConfig.centerTitleAndSubtitle(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishTheActivity();
            }
        });
        ToolbarConfig.makeStatusBarTransparent(getWindow());
    }

    private void finishTheActivity() {
        finish();
    }


    public void showErrorMsg(String msg) {
        CustomToast.makeToastWarning(activity, msg);

    }
}
