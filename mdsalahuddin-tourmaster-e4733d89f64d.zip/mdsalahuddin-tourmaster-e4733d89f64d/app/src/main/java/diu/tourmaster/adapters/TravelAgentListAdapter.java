package diu.tourmaster.adapters;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.models.NearestTransaction;
import diu.tourmaster.models.TravelAgent;

/**
 * Created by tajmulalam on 1/12/18.
 */

public class TravelAgentListAdapter extends RecyclerView.Adapter<TravelAgentListAdapter.TravelAgentListViewHolder> {

    private Context mContext;
    private List<TravelAgent> travelAgentList;
    GoogleMap map;

    public TravelAgentListAdapter(Context mContext, List<TravelAgent> travelAgentList) {
        this.mContext = mContext;
        this.travelAgentList = travelAgentList;
    }

    @Override
    public TravelAgentListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.transaction_list_custom_row, null);
        return new TravelAgentListViewHolder(view);
    }


    public void onBindViewHolder(TravelAgentListViewHolder holder, final int position) {

        holder.tvTitle.setText(travelAgentList.get(position).getTravelAgentName());
        holder.tvAddress.setText(travelAgentList.get(position).getAddress());
        holder.tvMobile.setText(travelAgentList.get(position).getMobileNo());
        holder.tvMobile.setVisibility(View.VISIBLE);
        holder.ibtnCall.setVisibility(View.VISIBLE);
        holder.ibtnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!TextUtils.isEmpty(travelAgentList.get(position).getMobileNo())) {
                    Intent intent = new Intent(Intent.ACTION_DIAL);
                    intent.setData(Uri.parse("tel:" + travelAgentList.get(position).getMobileNo()));
                    mContext.startActivity(intent);
                }
            }
        });

        holder.ibtnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showInternetCheckerDialog(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return travelAgentList.size() > 0 ? travelAgentList.size() : 0;
    }

    public class TravelAgentListViewHolder extends RecyclerView.ViewHolder {
        //private MapView mapView;
        private TextView tvAddress;
        private TextView tvTitle, tvMobile;
        private ImageButton ibtnCall;
        private ImageButton ibtnMap;

        public TravelAgentListViewHolder(View itemView) {
            super(itemView);
           // mapView = itemView.findViewById(R.id.mapView);
            tvAddress = itemView.findViewById(R.id.tvAddress);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvMobile = itemView.findViewById(R.id.tvMobile);
            ibtnCall = itemView.findViewById(R.id.ibtnCall);
            ibtnMap = itemView.findViewById(R.id.ibtnMap);

            // mapView.onCreate();

        }
    }

    private void showInternetCheckerDialog(final int position) {
        final Dialog dialog = new Dialog(mContext, R.style.CustomAlertDialog);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog_show_map);
        dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        Button btnNetworkCheckerDone = dialog.findViewById(R.id.btnNetworkCheckerDone);
        MapView mapView = dialog.findViewById(R.id.mapView);
        mapView.onCreate(null);
        mapView.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(GoogleMap googleMap) {
                map = googleMap;
                map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                } else {
                    map.setMyLocationEnabled(true);
                }
                map.setTrafficEnabled(true);
                map.setIndoorEnabled(true);
                map.setBuildingsEnabled(true);
                map.getUiSettings().setZoomControlsEnabled(true);
                if (map != null) {
                    CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(new LatLng(Double.valueOf(travelAgentList.get(position).getLatitude()), Double.valueOf(travelAgentList.get(position).getLongitude())), 18);
                    map.animateCamera(cameraUpdate);
                    MarkerOptions marker = new MarkerOptions().position(new LatLng(Double.valueOf(travelAgentList.get(position).getLatitude()), Double.valueOf(travelAgentList.get(position).getLongitude())));
                    marker.title(travelAgentList.get(position).getTravelAgentName() + "\n" + travelAgentList.get(position).getAddress());
                    map.addMarker(marker);

                }
            }
        });
        mapView.onResume();
        btnNetworkCheckerDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }
}
