package diu.tourmaster.activities;

import android.graphics.Typeface;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.controllers.CommonController;
import diu.tourmaster.fragments.TransportsFragment;
import diu.tourmaster.models.Transport;
import diu.tourmaster.utils.StaticAccess;
import diu.tourmaster.utils.ToolbarConfig;
import diu.tourmaster.utils.Utilities;

public class TransportsActivity extends BaseActivity {
    private int placeID = -1;
    private TabLayout tlTransport;
    private TransportsActivity activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BaseActivity.setLocale(this);

        setContentView(R.layout.activity_transports);
        receiveIntent();
        initToolbar();
        initUI();
    }

    private void receiveIntent() {
        activity = this;
        placeID = getIntent() != null ? getIntent().getIntExtra(StaticAccess.KEY_PLACE_ID_INTENT, -1) : -1;
    }

    private void initUI() {
        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        tlTransport = findViewById(R.id.tlTransport);
        tlTransport.setTabTextColors(
                ContextCompat.getColor(activity, android.R.color.white),
                ContextCompat.getColor(activity, android.R.color.white)
        );
        TabLayout.Tab tab1 = tlTransport.newTab();
        tab1.setText(getString(R.string.bus));
        tlTransport.addTab(tab1);
        TabLayout.Tab tab2 = tlTransport.newTab();
        tab2.setText(getString(R.string.water));
        tlTransport.addTab(tab2);
        TabLayout.Tab tab3 = tlTransport.newTab();
        tab3.setText(getString(R.string.air));
        tlTransport.addTab(tab3);
        TabLayout.Tab tab4 = tlTransport.newTab();
        tab4.setText(getString(R.string.train));
        tlTransport.addTab(tab4);
        changeTabsFont();
        // perform setOnTabSelectedListener event on TabLayout
        tlTransport.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                // get the current selected tab's position and replace the fragment accordingly
                setSelectFragment(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        setSelectFragment(0);
    }
    private void changeTabsFont() {
        Typeface typeface = Typeface.createFromAsset(activity.getAssets(), "font/rancho3.ttf");

        ViewGroup vg = (ViewGroup) tlTransport.getChildAt(0);
        int tabsCount = vg.getChildCount();
        for (int j = 0; j < tabsCount; j++) {
            ViewGroup vgTab = (ViewGroup) vg.getChildAt(j);
            int tabChildsCount = vgTab.getChildCount();
            for (int i = 0; i < tabChildsCount; i++) {
                View tabViewChild = vgTab.getChildAt(i);
                if (tabViewChild instanceof TextView) {
                    ((TextView) tabViewChild).setTypeface(typeface);
                }
            }
        }
    }
    private void setSelectFragment(int position) {
        Fragment fragment = null;
        switch (position) {
            case 0:
                fragment = TransportsFragment.newInstance(StaticAccess.TAB_BUS, placeID);
                break;
            case 1:
                fragment = TransportsFragment.newInstance(StaticAccess.TAB_WATER, placeID);
                break;
            case 2:
                fragment = TransportsFragment.newInstance(StaticAccess.TAB_AIR, placeID);
                break;
            case 3:
                fragment = TransportsFragment.newInstance(StaticAccess.TAB_TRAIN, placeID);
                break;
        }
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.rlTransportContainer, fragment);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        ft.commit();
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle(getString(R.string.local_transport));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishTheActivity();
            }
        });
        ToolbarConfig.makeStatusBarTransparent(getWindow());
    }

    private void finishTheActivity() {
        finish();
    }

}
