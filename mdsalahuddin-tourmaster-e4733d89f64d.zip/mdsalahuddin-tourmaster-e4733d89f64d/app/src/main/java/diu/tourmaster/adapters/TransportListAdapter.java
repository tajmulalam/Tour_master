package diu.tourmaster.adapters;

import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.listener.PlaceClickListener;
import diu.tourmaster.models.TourismPlace;
import diu.tourmaster.models.Transport;
import diu.tourmaster.utils.Configs;

/**
 * Created by tajmulalam on 1/12/18.
 */

public class TransportListAdapter extends RecyclerView.Adapter<TransportListAdapter.TransportListViewHolder> {

    private Context mContext;
    private List<Transport> transportList;

    public TransportListAdapter(Context mContext, List<Transport> transportList) {
        this.mContext = mContext;
        this.transportList = transportList;
    }

    @Override
    public TransportListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.transport_list_custom_row, null);
        return new TransportListViewHolder(view);
    }

    public void onBindViewHolder(TransportListViewHolder holder, final int position) {
        holder.tvTitle.setText(transportList.get(position).getTransportName());
        holder.tvDescription.setText(transportList.get(position).getDescription());
    }

    @Override
    public int getItemCount() {
        return transportList.size() > 0 ? transportList.size() : 0;
    }

    public class TransportListViewHolder extends RecyclerView.ViewHolder {
        private TextView tvTitle;
        private TextView tvDescription;

        public TransportListViewHolder(View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvDescription = itemView.findViewById(R.id.tvDescription);
        }
    }
}
