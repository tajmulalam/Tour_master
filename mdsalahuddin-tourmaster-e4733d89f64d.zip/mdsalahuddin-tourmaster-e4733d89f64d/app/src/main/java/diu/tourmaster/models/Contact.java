package diu.tourmaster.models;

/**
 * Created by Md Tajmul Alam on 1/23/2018.
 */

public class Contact {

    private Integer contactId;
    private String helpLineFor;
    private String contactNumber;
    private String address;
    private Integer status;
    private String createdAt;

    public Integer getContactId() {
        return contactId;
    }

    public void setContactId(Integer contactId) {
        this.contactId = contactId;
    }

    public String getHelpLineFor() {
        return helpLineFor;
    }

    public void setHelpLineFor(String helpLineFor) {
        this.helpLineFor = helpLineFor;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}
