package diu.tourmaster.models;

import java.util.List;

/**
 * Created by tajmulalam on 1/12/18.
 */

public class SightSeeingPlace {
    private Integer sightseeingPlaceId;
    private Integer tourismPlaceID;
    private String sightseeingPlaceName;
    private String latitude;
    private String longitude;
    private String description;
    private Integer status;
    private String createdAt;
    private Photos photo;
    private List<Photos> allPhotos;

    public Integer getSightseeingPlaceId() {
        return sightseeingPlaceId;
    }

    public void setSightseeingPlaceId(Integer sightseeingPlaceId) {
        this.sightseeingPlaceId = sightseeingPlaceId;
    }

    public String getSightseeingPlaceName() {
        return sightseeingPlaceName;
    }

    public void setTourismPlaceID(Integer tourismPlaceID) {
        this.tourismPlaceID = tourismPlaceID;
    }

    public Integer getTourismPlaceID() {
        return tourismPlaceID;
    }

    public void setSightseeingPlaceName(String sightseeingPlaceName) {
        this.sightseeingPlaceName = sightseeingPlaceName;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public void setPhoto(Photos photo) {
        this.photo = photo;
    }

    public Photos getPhoto() {
        return photo;
    }

    public void setAllPhotos(List<Photos> allPhotos) {
        this.allPhotos = allPhotos;
    }

    public List<Photos> getAllPhotos() {
        return allPhotos;
    }
}
