package diu.tourmaster.fragments;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.BaseTransientBottomBar;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import diu.tourmaster.R;
import diu.tourmaster.activities.AccommodationActivity;
import diu.tourmaster.activities.FoodActivity;
import diu.tourmaster.activities.HelplineActivity;
import diu.tourmaster.activities.PdfViewerActivity;
import diu.tourmaster.activities.PlaceDetailsActivity;
import diu.tourmaster.activities.TourProductsActivity;
import diu.tourmaster.activities.TransactionsActivity;
import diu.tourmaster.activities.TransportsActivity;
import diu.tourmaster.activities.TravelAgentsActivity;
import diu.tourmaster.controllers.CommonController;
import diu.tourmaster.models.Accommodation;
import diu.tourmaster.models.TourProduct;
import diu.tourmaster.models.TravelAgent;
import diu.tourmaster.utils.StaticAccess;

/**
 * A simple {@link Fragment} subclass.
 */
public class FacilitiesFragment extends Fragment implements View.OnClickListener {

    private Context mContext;
    private int placeID = -1;
    private int page = -1;
    private LinearLayout lnAccommodation, lnTourGuide, lnFood, lnTransports, lnTravelAgents, lnTransaction, lnTourProduct, lnHelpline;

    public FacilitiesFragment() {
        // Required empty public constructor
    }

    // newInstance constructor for creating fragment with arguments
    public static FacilitiesFragment newInstance(int page, int placeID) {
        FacilitiesFragment facilitiesFragment = new FacilitiesFragment();
        Bundle args = new Bundle();
        args.putInt("someInt", page);
        args.putInt(StaticAccess.KEY_PLACE_ID_INTENT, placeID);
        facilitiesFragment.setArguments(args);
        return facilitiesFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        receiveBundle();
        View view = null;
        if (page == 0) {
            // Inflate the layout for this fragment
            view = inflater.inflate(R.layout.nav_fragment_facilities, container, false);
            view.findViewById(R.id.ivBlank).setVisibility(View.VISIBLE);
            getActivity().setTitle(getString(R.string.facilities));
        } else {
            view = inflater.inflate(R.layout.fragment_facilities, container, false);

        }

        mContext = getContext();
        initUI(view);
        return view;
    }

    private void receiveBundle() {
        Bundle bundle = getArguments();
        placeID = bundle != null ? bundle.getInt(StaticAccess.KEY_PLACE_ID_INTENT, -1) : -1;
        page = bundle != null ? bundle.getInt("someInt", -1) : -1;
    }

    private void initUI(View view) {
        lnAccommodation = view.findViewById(R.id.lnAccommodation);
        lnTourGuide = view.findViewById(R.id.lnTourGuide);
        lnFood = view.findViewById(R.id.lnFood);
        lnTransports = view.findViewById(R.id.lnTransports);
        lnTravelAgents = view.findViewById(R.id.lnTravelAgents);
        lnTransaction = view.findViewById(R.id.lnTransaction);
        lnTourProduct = view.findViewById(R.id.lnTourProduct);
        lnHelpline = view.findViewById(R.id.lnHelpline);
        lnTourGuide.setOnClickListener(this);
        lnAccommodation.setOnClickListener(this);
        lnFood.setOnClickListener(this);
        lnTransports.setOnClickListener(this);
        lnTravelAgents.setOnClickListener(this);
        lnTransaction.setOnClickListener(this);
        lnTourProduct.setOnClickListener(this);
        lnHelpline.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.lnAccommodation:
                mContext.startActivity(new Intent(mContext, AccommodationActivity.class).putExtra(StaticAccess.KEY_PLACE_ID_INTENT, placeID));
                break;
            case R.id.lnTourGuide:
                mContext.startActivity(new Intent(mContext, PdfViewerActivity.class).putExtra(StaticAccess.KEY_PLACE_ID_INTENT, placeID));
                break;
            case R.id.lnFood:
                mContext.startActivity(new Intent(mContext, FoodActivity.class).putExtra(StaticAccess.KEY_PLACE_ID_INTENT, placeID));
                break;
            case R.id.lnTransports:
                mContext.startActivity(new Intent(mContext, TransportsActivity.class).putExtra(StaticAccess.KEY_PLACE_ID_INTENT, placeID));
                break;
            case R.id.lnTravelAgents:
                mContext.startActivity(new Intent(mContext, TravelAgentsActivity.class).putExtra(StaticAccess.KEY_PLACE_ID_INTENT, placeID));
                break;
            case R.id.lnTransaction:
                mContext.startActivity(new Intent(mContext, TransactionsActivity.class).putExtra(StaticAccess.KEY_PLACE_ID_INTENT, placeID));
                break;
            case R.id.lnTourProduct:
                mContext.startActivity(new Intent(mContext, TourProductsActivity.class).putExtra(StaticAccess.KEY_PLACE_ID_INTENT, placeID));

                break;
            case R.id.lnHelpline:
                mContext.startActivity(new Intent(mContext, HelplineActivity.class).putExtra(StaticAccess.KEY_PLACE_ID_INTENT, placeID));
                break;
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        menu.clear();
    }
}
