package diu.tourmaster.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;

import java.util.List;

import diu.tourmaster.models.SightSeeingPlace;
import diu.tourmaster.models.TourismPlace;

/**
 * Created by tajmulalam on 1/15/18.
 */

import android.support.v7.widget.CardView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;


import diu.tourmaster.R;
import diu.tourmaster.utils.Configs;

/**
 * Created by tajmulalam on 1/12/18.
 */

public class SightSeeingPlaceListAdapter extends RecyclerView.Adapter<SightSeeingPlaceListAdapter.SightSeeingPlaceListViewHolder> {

    private Context mContext;
    private List<SightSeeingPlace> sightSeeingPlaces;
    private SightSeeingPlaceClickedListener sightSeeingPlaceClickedListener;

    public SightSeeingPlaceListAdapter(Context mContext, List<SightSeeingPlace> sightSeeingPlaces, SightSeeingPlaceClickedListener sightSeeingPlaceClickedListener) {
        this.mContext = mContext;
        this.sightSeeingPlaces = sightSeeingPlaces;
        this.sightSeeingPlaceClickedListener = sightSeeingPlaceClickedListener;
    }

    @Override
    public SightSeeingPlaceListAdapter.SightSeeingPlaceListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.place_list_custom_row, null);
        return new SightSeeingPlaceListViewHolder(view);
    }


    public void onBindViewHolder(SightSeeingPlaceListViewHolder holder, final int position) {
        String photoUrl = sightSeeingPlaces.get(position).getPhoto() != null ? Configs.BASE_URL + sightSeeingPlaces.get(position).getPhoto().getPhotoPath() : "";
        if (TextUtils.isEmpty(photoUrl)) {
            Picasso.with(mContext)
                    .load(R.drawable.placeholder)
                    .error(R.drawable.placeholder)
                    .into(holder.ivPlaceImage);
            holder.tvTitle.setText(sightSeeingPlaces.get(position).getSightseeingPlaceName());
        } else {
            Picasso.with(mContext)
                    .load(photoUrl)
                    .error(R.drawable.placeholder)
                    .into(holder.ivPlaceImage);
            holder.tvTitle.setText(sightSeeingPlaces.get(position).getSightseeingPlaceName());
        }
        holder.cvPlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sightSeeingPlaceClickedListener.sighSeeingPlaceClicked(sightSeeingPlaces.get(position));
            }
        });
        holder.tvTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sightSeeingPlaceClickedListener.sighSeeingPlaceClicked(sightSeeingPlaces.get(position));
            }
        });
        holder.ivPlaceImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sightSeeingPlaceClickedListener.sighSeeingPlaceClicked(sightSeeingPlaces.get(position));
            }
        });
    }

    @Override
    public int getItemCount() {
        return sightSeeingPlaces.size() > 0 ? sightSeeingPlaces.size() : 0;
    }

    public class SightSeeingPlaceListViewHolder extends RecyclerView.ViewHolder {
        private ImageView ivPlaceImage;
        private TextView tvTitle;
        private CardView cvPlace;

        public SightSeeingPlaceListViewHolder(View itemView) {
            super(itemView);
            ivPlaceImage = itemView.findViewById(R.id.ivPlaceImage);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            cvPlace = itemView.findViewById(R.id.cvPlace);
        }
    }

    public interface SightSeeingPlaceClickedListener {
        void sighSeeingPlaceClicked(SightSeeingPlace place);
    }
}
