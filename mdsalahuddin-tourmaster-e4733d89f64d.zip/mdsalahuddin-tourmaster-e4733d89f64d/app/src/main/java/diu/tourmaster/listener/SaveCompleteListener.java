package diu.tourmaster.listener;

/**
 * Created by tajmulalam on 11/6/17.
 */

public interface SaveCompleteListener {
    void isSavedComplete(boolean isSaved);
}
