package diu.tourmaster.adapters;

import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.models.VideoCategory;
import diu.tourmaster.models.VideoFile;

/**
 * Created by tajmulalam on 1/12/18.
 */

public class VideoListAdapter extends RecyclerView.Adapter<VideoListAdapter.VideoListViewHolder> {

    private Context mContext;
    private List<VideoFile> videoFileList;
    private VideoClickedListener videoClickedListener;

    public VideoListAdapter(Context mContext, List<VideoFile> videoFileList, VideoClickedListener videoClickedListener) {
        this.mContext = mContext;
        this.videoFileList = videoFileList;
        this.videoClickedListener = videoClickedListener;
    }

    @Override
    public VideoListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.video_category_list_custom_row, null);
        return new VideoListViewHolder(view);
    }


    public void onBindViewHolder(VideoListViewHolder holder, final int position) {
        Picasso.with(mContext)
                .load(R.drawable.ic_video)
                .error(R.drawable.ic_video)
                .into(holder.ivPlaceImage);

        holder.tvTitle.setText(videoFileList.get(position).getDescription());
        holder.cvPlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                videoClickedListener.videoClicked(videoFileList.get(position));
            }
        });
        holder.tvTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                videoClickedListener.videoClicked(videoFileList.get(position));

            }
        });
        holder.ivPlaceImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                videoClickedListener.videoClicked(videoFileList.get(position));

            }
        });
    }

    @Override
    public int getItemCount() {
        return videoFileList.size() > 0 ? videoFileList.size() : 0;
    }

    public class VideoListViewHolder extends RecyclerView.ViewHolder {
        private ImageView ivPlaceImage;
        private TextView tvTitle;
        private CardView cvPlace;

        public VideoListViewHolder(View itemView) {
            super(itemView);
            ivPlaceImage = itemView.findViewById(R.id.ivPlaceImage);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            cvPlace = itemView.findViewById(R.id.cvPlace);
        }
    }

    public interface VideoClickedListener {
        void videoClicked(VideoFile videoFile);
    }
}
