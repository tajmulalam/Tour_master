package diu.tourmaster.listener;

/**
 * Created by Md Tajmul Alam on 1/18/2018.
 */

public interface SearchTextGetListener {
    void searchText(String keyword);
    void resetSearch();
}
