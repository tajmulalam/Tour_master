package diu.tourmaster.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;

import com.google.android.gms.maps.model.LatLng;
import com.google.gson.Gson;

import diu.tourmaster.activities.MainActivity;
import diu.tourmaster.models.SightSeeingPlace;
import diu.tourmaster.models.TourismPlace;

/**
 * Created by tajmulalam on 1/10/18.
 */

public class SharedPreferenceValues {
    public static void setLocation(Context mContext, double latitude, double longitude) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences("LOCATION_DATA", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putLong("lat", Double.doubleToRawLongBits(latitude));
        editor.putLong("lng", Double.doubleToRawLongBits(longitude));
        editor.commit();
    }

    public static LatLng getLocation(Context mContext) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences("LOCATION_DATA", Context.MODE_PRIVATE);
        double lat = Double.longBitsToDouble(sharedPreferences.getLong("lat", -1));
        double lon = Double.longBitsToDouble(sharedPreferences.getLong("lng", -1));
        LatLng latLng = new LatLng(lat, lon);
        return latLng;
    }

    public static void clearLocation(Context mContext) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences("LOCATION_DATA", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("lat");
        editor.remove("lng");
        editor.commit();
    }

    public static void setWizardSelectedPlace(Context mContext, TourismPlace tourismPlace) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences("PLACE_WIZARD_DATA", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("detect_place", new Gson().toJson(tourismPlace));
        editor.commit();
    }

    public static TourismPlace getWizardSelectedPlace(Context mContext) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences("PLACE_WIZARD_DATA", Context.MODE_PRIVATE);
        String json = sharedPreferences.getString("detect_place", "");
        TourismPlace tourismPlace = new Gson().fromJson(json, TourismPlace.class);
        return tourismPlace;
    }

    public static void clearWizardPlace(Context mContext) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences("PLACE_WIZARD_DATA", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("detect_place");
        editor.commit();
    }

    public static void setLanguage(Context mContext, String language) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences("LANGUAGE_DATA", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("language", language);
        editor.commit();
    }

    public static String getLanguage(Context mContext) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences("LANGUAGE_DATA", Context.MODE_PRIVATE);
        return sharedPreferences.getString("language", "English");
    }

    public static void clearLanguage(Context mContext) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences("LANGUAGE_DATA", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("language");
        editor.commit();
    }

    public static void clearEmergencyNumber(Context mContext) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences("EMERGENCY_NUMBER_DATA", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("number");
        editor.commit();
    }

    public static String getNumber(Context mContext) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences("EMERGENCY_NUMBER_DATA", Context.MODE_PRIVATE);
        return sharedPreferences.getString("number", "");
    }


    public static void setEmergencyNumber(Context mContext, String number) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences("EMERGENCY_NUMBER_DATA", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("number", number);
        editor.commit();
    }
}


