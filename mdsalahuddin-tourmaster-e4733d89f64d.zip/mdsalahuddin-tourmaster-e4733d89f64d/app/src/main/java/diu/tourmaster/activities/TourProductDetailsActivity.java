package diu.tourmaster.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.controllers.CommonController;
import diu.tourmaster.models.Accommodation;
import diu.tourmaster.models.Photos;
import diu.tourmaster.models.TourProduct;
import diu.tourmaster.utils.Configs;
import diu.tourmaster.utils.CustomToast;
import diu.tourmaster.utils.StaticAccess;
import diu.tourmaster.utils.ToolbarConfig;
import diu.tourmaster.utils.Utilities;
import ss.com.bannerslider.banners.Banner;
import ss.com.bannerslider.banners.DrawableBanner;
import ss.com.bannerslider.banners.RemoteBanner;
import ss.com.bannerslider.views.BannerSlider;

public class TourProductDetailsActivity extends BaseActivity {
    private TextView tvProductName, tvProductDetails;
    private BannerSlider bannerSlider;
    private TourProductDetailsActivity activity;
    private CommonController commonController;
    private Integer productID = -1;
    private Integer placeID = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BaseActivity.setLocale(this);

        setContentView(R.layout.activity_tour_product_details);
        receiveIntent();
        initToolbar();
        initUI();
        callApi();
    }

    private void receiveIntent() {
        productID = getIntent() != null ? getIntent().getIntExtra(StaticAccess.KEY_PRODUCT_ID_INTENT, -1) : -1;
        placeID = getIntent() != null ? getIntent().getIntExtra(StaticAccess.KEY_PLACE_ID_INTENT, -1) : -1;
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishTheActivity();
            }
        });
        ToolbarConfig.makeStatusBarTransparent(getWindow());

    }

    private void finishTheActivity() {
        startActivity(new Intent(activity, TourProductsActivity.class).putExtra(StaticAccess.KEY_PLACE_ID_INTENT, placeID));
        finish();
    }

    private void initUI() {
        activity = this;
        commonController = new CommonController(activity);
        bannerSlider = findViewById(R.id.bannerSlider);
        tvProductName = findViewById(R.id.tvProductName);
        tvProductDetails = findViewById(R.id.tvProductDetails);
    }

    private void callApi() {
        HashMap<String, String> params = Utilities.getInstance().getRequestParams();
        params.put("product_id", String.valueOf(productID));
        commonController.callApi(CommonController.REQUEST_SINGLE_PRODUCT, params, true);
    }


    public void showErrorMsg(String msg) {
        CustomToast.makeToastWarning(activity, msg);

    }

    public void updateProduct(TourProduct tourProduct) {
        setTitle(tourProduct.getProductName());
        tvProductName.setText(tourProduct.getProductName());
        tvProductDetails.setText(tourProduct.getDescription());
        loadBannerSlider(tourProduct.getPhotosList());
    }

    public void loadBannerSlider(List<Photos> photosList) {
        List<Banner> banners = new ArrayList<>();
        if (photosList != null && photosList.size() > 0) {
            for (Photos photos : photosList) {
                //add banner using image url
                RemoteBanner remoteBanner = new RemoteBanner(Configs.BASE_URL + photos.getPhotoPath());
                remoteBanner.setScaleType(ImageView.ScaleType.FIT_XY);
                banners.add(remoteBanner);
                //add banner using resource drawable
            }
        } else {
            DrawableBanner drawableBanner = new DrawableBanner(R.drawable.placeholder);
            drawableBanner.setScaleType(ImageView.ScaleType.FIT_XY);
            banners.add(drawableBanner);
        }
        bannerSlider.setBanners(banners);
    }
}
