package diu.tourmaster.controllers;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.activities.AccommodationActivity;
import diu.tourmaster.activities.AccommodationDetailsActivity;
import diu.tourmaster.activities.FestivalCalenderActivity;
import diu.tourmaster.activities.FoodActivity;
import diu.tourmaster.activities.HelplineActivity;
import diu.tourmaster.activities.HeritageGalleryActivity;
import diu.tourmaster.activities.MainActivity;
import diu.tourmaster.activities.PdfViewerActivity;
import diu.tourmaster.activities.PlaceDetailsActivity;
import diu.tourmaster.activities.RestaurantDetailActivity;
import diu.tourmaster.activities.SightPlaceDetailsActivity;
import diu.tourmaster.activities.TourProductDetailsActivity;
import diu.tourmaster.activities.TourProductsActivity;
import diu.tourmaster.activities.TransactionsActivity;
import diu.tourmaster.activities.TransportsActivity;
import diu.tourmaster.activities.TravelAgentsActivity;
import diu.tourmaster.activities.VideoListActivity;
import diu.tourmaster.fragments.HelplineContactsFragment;
import diu.tourmaster.fragments.HomeFragment;
import diu.tourmaster.fragments.NavSightPlaceFragment;
import diu.tourmaster.fragments.PlaceDetailsFragment;
import diu.tourmaster.fragments.PlacesFragment;
import diu.tourmaster.fragments.SightSeeingPlacesFragment;
import diu.tourmaster.fragments.TransportsFragment;
import diu.tourmaster.listener.VolleyServiceResponseListener;
import diu.tourmaster.models.Accommodation;
import diu.tourmaster.models.Contact;
import diu.tourmaster.models.Festival;
import diu.tourmaster.models.NearestTransaction;
import diu.tourmaster.models.Photos;
import diu.tourmaster.models.Restaurant;
import diu.tourmaster.models.SightSeeingPlace;
import diu.tourmaster.models.SliderModel;
import diu.tourmaster.models.TourProduct;
import diu.tourmaster.models.TourismPlace;
import diu.tourmaster.models.Transport;
import diu.tourmaster.models.TravelAgent;
import diu.tourmaster.models.VideoCategory;
import diu.tourmaster.models.VideoFile;
import diu.tourmaster.utils.Configs;
import diu.tourmaster.utils.Utilities;

/**
 * Created by tajmulalam on 1/11/18.
 */

public class CommonController implements VolleyServiceResponseListener {
    private Context mContext;
    public static final int USER_LOCATION_REQUEST = 1;
    public static final int REQUEST_PLACE_LIST = 2;
    public static final int REQUEST_SINGLE_PLACE = 3;
    public static final int REQUEST_SIGHT_SEEING_PLACE_LIST = 4;
    public static final int REQUEST_SIGHT_SEEING_PLACE_LIST_FROM_NAV = 5;
    public static final int REQUEST_PlACE_WISE_ALL_SIGHT_PLACE_IMAGES = 6;
    public static final int REQUEST_SINGLE_SIGHT_PLACE = 7;
    public static final int REQUEST_ACCOMMODATIONS_BY_PLACE_ID = 8;
    public static final int REQUEST_SINGLE_ACCOMMODATION = 9;
    public static final int REQUEST_FESTIVALS = 10;
    public static final int REQUEST_TRANSPORT_LIST_BY_PLACE = 11;
    public static final int REQUEST_RESTAURANTS_BY_PLACE_ID = 12;
    public static final int REQUEST_SINGLE_RESTAURANT = 13;
    public static final int REQUEST_BANKS_BY_PLACE_ID = 14;
    public static final int REQUEST_TRAVEL_AGENT_BY_PLACE_ID = 15;
    public static final int REQUEST_TOUR_PRODUCTS_BY_PLACE_ID = 16;
    public static final int REQUEST_CONTACT_LIST_BY_PLACE = 17;
    public static final int REQUEST_SINGLE_PRODUCT = 18;
    public static final int REQUEST_VIDEO_CATEGORY_BY_PLACE_ID = 19;
    public static final int REQUEST_VIDEO_LIST_BY_CATEGORY_ID = 20;
    public static final int REQUEST_TOUR_GUIDE = 21;
    private int req = -1;

    public CommonController(Context mContext) {
        this.mContext = mContext;
    }

    public void callApi(int req, HashMap<String, String> params, boolean showLoader) {
        this.req = req;
        String json = "";
        switch (req) {
            case USER_LOCATION_REQUEST:
                json = new Gson().toJson(params);
                Log.e("body", json);
                Utilities.getInstance().makeServiceCall(Configs.URL_LOCATION_URL, mContext, json, this, showLoader);
                break;
            case REQUEST_PLACE_LIST:
                Utilities.getInstance().makeServiceCall(Configs.URL_PLACE_LIST, mContext, json, this, showLoader);
                break;
            case REQUEST_SINGLE_PLACE:
                json = new Gson().toJson(params);
                Log.e("body", json);
                Utilities.getInstance().makeServiceCall(Configs.URL_SINGLE_PLACE, mContext, json, this, showLoader);
                break;
            case REQUEST_SIGHT_SEEING_PLACE_LIST:
                json = new Gson().toJson(params);
                Log.e("body", json);
                Utilities.getInstance().makeServiceCall(Configs.URL_SIGHT_SEEING_PLACE_LIST, mContext, json, this, showLoader);
                break;
            case REQUEST_SIGHT_SEEING_PLACE_LIST_FROM_NAV:
                json = new Gson().toJson(params);
                Log.e("body", json);
                Utilities.getInstance().makeServiceCall(Configs.URL_SIGHT_SEEING_PLACE_LIST, mContext, json, this, showLoader);
                break;
            case REQUEST_PlACE_WISE_ALL_SIGHT_PLACE_IMAGES:
                json = new Gson().toJson(params);
                Log.e("body", json);
                Utilities.getInstance().makeServiceCall(Configs.URL_PlACE_WISE_ALL_SIGHT_PLACE_IMAGES, mContext, json, this, showLoader);
                break;
            case REQUEST_SINGLE_SIGHT_PLACE:
                json = new Gson().toJson(params);
                Log.e("body", json);
                Utilities.getInstance().makeServiceCall(Configs.URL_SINGLE_SIGHT_PLACE, mContext, json, this, showLoader);
                break;
            case REQUEST_ACCOMMODATIONS_BY_PLACE_ID:
                json = new Gson().toJson(params);
                Log.e("body", json);
                Utilities.getInstance().makeServiceCall(Configs.URL_ACCOMMODATIONS_BY_PLACE_ID, mContext, json, this, showLoader);
                break;
            case REQUEST_SINGLE_ACCOMMODATION:
                json = new Gson().toJson(params);
                Log.e("body", json);
                Utilities.getInstance().makeServiceCall(Configs.URL_SINGLE_ACCOMMODATION, mContext, json, this, showLoader);
                break;
            case REQUEST_FESTIVALS:
                /*json = new Gson().toJson(params);
                Log.e("body", json);*/
                Utilities.getInstance().makeServiceCall(Configs.URL_FESTIVAL_LIST, mContext, json, this, showLoader);
                break;
            case REQUEST_TRANSPORT_LIST_BY_PLACE:
                json = new Gson().toJson(params);
                Log.e("body", json);
                Utilities.getInstance().makeServiceCall(Configs.URL_TRANSPORT_LIST_BY_PLACE, mContext, json, this, showLoader);
                break;
            case REQUEST_RESTAURANTS_BY_PLACE_ID:
                json = new Gson().toJson(params);
                Log.e("body", json);
                Utilities.getInstance().makeServiceCall(Configs.URL_RESTAURANTS_BY_PLACE, mContext, json, this, showLoader);
                break;
            case REQUEST_SINGLE_RESTAURANT:
                json = new Gson().toJson(params);
                Log.e("body", json);
                Utilities.getInstance().makeServiceCall(Configs.URL_SINGLE_RESTAURANT, mContext, json, this, showLoader);
                break;
            case REQUEST_BANKS_BY_PLACE_ID:
                json = new Gson().toJson(params);
                Log.e("body", json);
                Utilities.getInstance().makeServiceCall(Configs.URL_BANKS_BY_PLACE, mContext, json, this, showLoader);
                break;
            case REQUEST_TRAVEL_AGENT_BY_PLACE_ID:
                json = new Gson().toJson(params);
                Log.e("body", json);
                Utilities.getInstance().makeServiceCall(Configs.URL_TRAVEL_AGENT_BY_PLACE, mContext, json, this, showLoader);
                break;
            case REQUEST_TOUR_PRODUCTS_BY_PLACE_ID:
                json = new Gson().toJson(params);
                Log.e("body", json);
                Utilities.getInstance().makeServiceCall(Configs.URL_TOUR_PRODUCTS_BY_PLACE, mContext, json, this, showLoader);
                break;
            case REQUEST_CONTACT_LIST_BY_PLACE:
                json = new Gson().toJson(params);
                Log.e("body", json);
                Utilities.getInstance().makeServiceCall(Configs.URL_CONTACT_LIST_BY_PLACE, mContext, json, this, showLoader);
                break;
            case REQUEST_SINGLE_PRODUCT:
                json = new Gson().toJson(params);
                Log.e("body", json);
                Utilities.getInstance().makeServiceCall(Configs.URL_SINGLE_PRODUCT, mContext, json, this, showLoader);
                break;
            case REQUEST_VIDEO_CATEGORY_BY_PLACE_ID:
               /* json = new Gson().toJson(params);*/
                Log.e("body", json);
                Utilities.getInstance().makeServiceCall(Configs.URL_VIDEO_CATEGORY_BY_PLACE, mContext, json, this, showLoader);
                break;
            case REQUEST_VIDEO_LIST_BY_CATEGORY_ID:
                json = new Gson().toJson(params);
                Log.e("body", json);
                Utilities.getInstance().makeServiceCall(Configs.URL_VIDEO_LIST, mContext, json, this, showLoader);
                break;
            case REQUEST_TOUR_GUIDE:
                json = new Gson().toJson(params);
                Log.e("body", json);
                Utilities.getInstance().makeServiceCall(Configs.URL_SINGLE_PLACE, mContext, json, this, showLoader);
                break;
        }
    }

    @Override
    public void onNetWorkFailure(String url, String msg) {
        switch (url) {
            case Configs.URL_LOCATION_URL:
                HomeFragment homeFr = (HomeFragment) ((MainActivity) mContext).getSupportFragmentManager().findFragmentById(R.id.rlContent);
                homeFr.showErrorMsg(msg);
                break;
            case Configs.URL_PLACE_LIST:
                PlacesFragment placeFr = (PlacesFragment) ((MainActivity) mContext).getSupportFragmentManager().findFragmentById(R.id.rlContent);
                placeFr.showErrorMsg(msg);
                break;
            case Configs.URL_SINGLE_PLACE:
                if (req != REQUEST_TOUR_GUIDE) {
                    List<android.support.v4.app.Fragment> fragmentList = ((PlaceDetailsActivity) mContext).getSupportFragmentManager().getFragments();
                    for (android.support.v4.app.Fragment fragment : fragmentList) {
                        if (fragment instanceof PlaceDetailsFragment) {
                            PlaceDetailsFragment placeDetailsFr = (PlaceDetailsFragment) fragment;
                            placeDetailsFr.showErrorMsg(msg);
                        }
                    }
                } else {
                    ((PdfViewerActivity) mContext).showErrorMsg(msg);

                }
                break;
            case Configs.URL_SIGHT_SEEING_PLACE_LIST:

                List<android.support.v4.app.Fragment> fragmentList2 = null;
                if (req != REQUEST_SIGHT_SEEING_PLACE_LIST_FROM_NAV) {
                    fragmentList2 = ((PlaceDetailsActivity) mContext).getSupportFragmentManager().getFragments();
                } else {
                    fragmentList2 = ((MainActivity) mContext).getSupportFragmentManager().getFragments();

                }
                if (fragmentList2 != null) {
                    for (android.support.v4.app.Fragment fragment : fragmentList2) {
                        if (req != REQUEST_SIGHT_SEEING_PLACE_LIST_FROM_NAV && fragment instanceof SightSeeingPlacesFragment) {
                            SightSeeingPlacesFragment sightSeeingPlacesFragment = (SightSeeingPlacesFragment) fragment;
                            sightSeeingPlacesFragment.showErrorMsg(msg);
                        } else if (req == REQUEST_SIGHT_SEEING_PLACE_LIST_FROM_NAV && fragment instanceof NavSightPlaceFragment) {
                            NavSightPlaceFragment navSightPlaceFragment = (NavSightPlaceFragment) fragment;
                            navSightPlaceFragment.showErrorMsg(msg);
                        }
                    }
                }
                break;
            case Configs.URL_PlACE_WISE_ALL_SIGHT_PLACE_IMAGES:
                ((PlaceDetailsActivity) mContext).showErrorMsg(msg);
                break;
            case Configs.URL_SINGLE_SIGHT_PLACE:
                ((SightPlaceDetailsActivity) mContext).showErrorMsg(msg);
                break;
            case Configs.URL_ACCOMMODATIONS_BY_PLACE_ID:
                ((AccommodationActivity) mContext).showErrorMsg(msg);
                break;
            case Configs.URL_SINGLE_ACCOMMODATION:
                ((AccommodationDetailsActivity) mContext).showErrorMsg(msg);
                break;
            case Configs.URL_FESTIVAL_LIST:
                ((FestivalCalenderActivity) mContext).showErrorMsg(msg);
                break;
            case Configs.URL_TRANSPORT_LIST_BY_PLACE:
                List<android.support.v4.app.Fragment> transportFragList = ((TransportsActivity) mContext).getSupportFragmentManager().getFragments();
                for (android.support.v4.app.Fragment fragment : transportFragList) {
                    if (fragment instanceof TransportsFragment) {
                        TransportsFragment transportsFragment = (TransportsFragment) fragment;
                        transportsFragment.showErrorMsg(msg);
                    }
                }
                break;
            case Configs.URL_RESTAURANTS_BY_PLACE:
                ((FoodActivity) mContext).showErrorMsg(msg);
                break;
            case Configs.URL_SINGLE_RESTAURANT:
                ((RestaurantDetailActivity) mContext).showErrorMsg(msg);
                break;
            case Configs.URL_BANKS_BY_PLACE:
                ((TransactionsActivity) mContext).showErrorMsg(msg);
                break;
            case Configs.URL_TRAVEL_AGENT_BY_PLACE:
                ((TravelAgentsActivity) mContext).showErrorMsg(msg);
                break;
            case Configs.URL_TOUR_PRODUCTS_BY_PLACE:
                ((TourProductsActivity) mContext).showErrorMsg(msg);
                break;
            case Configs.URL_CONTACT_LIST_BY_PLACE:
                List<android.support.v4.app.Fragment> helplineFragList = ((HelplineActivity) mContext).getSupportFragmentManager().getFragments();
                for (android.support.v4.app.Fragment fragment : helplineFragList) {
                    if (fragment instanceof HelplineContactsFragment) {
                        HelplineContactsFragment contactsFragment = (HelplineContactsFragment) fragment;
                        contactsFragment.showErrorMsg(msg);
                    }
                }
                break;
            case Configs.URL_SINGLE_PRODUCT:
                ((TourProductDetailsActivity) mContext).showErrorMsg(msg);
                break;
            case Configs.URL_VIDEO_CATEGORY_BY_PLACE:
                ((HeritageGalleryActivity) mContext).showErrorMsg(msg);
                break;
            case Configs.URL_VIDEO_LIST:
                ((VideoListActivity) mContext).showErrorMsg(msg);
                break;
        }
    }

    @Override
    public void onSuccessResponse(String url, String response) {
        Log.e("response", response);
        JSONObject mainJsonObj = null;

        try {
            mainJsonObj = new JSONObject(response);
            switch (url) {
                case Configs.URL_LOCATION_URL:
                    JSONArray detectPlacesJsArr = null;
                    List<TourismPlace> placeArrayList = new ArrayList<>();
                    if (!mainJsonObj.getString("detectedPlace").equalsIgnoreCase("[]")) {
                        detectPlacesJsArr = mainJsonObj.isNull("detectedPlace") ? null : (JSONArray) mainJsonObj.opt("detectedPlace");
                    }
                    if (detectPlacesJsArr != null && detectPlacesJsArr.length() > 0) {
                        TourismPlace tourismPlace = null;
                        for (int i = 0; i < detectPlacesJsArr.length(); i++) {
                            JSONObject placeObj = detectPlacesJsArr.getJSONObject(i);

                            tourismPlace = new TourismPlace();
                            tourismPlace.setTourismPlaceId(placeObj.optInt("tourism_place_id"));
                            tourismPlace.setPlaceName(placeObj.optString("place_name"));
                            tourismPlace.setLatitude(placeObj.optString("latitude"));
                            tourismPlace.setLongitude(placeObj.optString("longitude"));
                            tourismPlace.setDescription(placeObj.optString("description"));
                            tourismPlace.setStatus(placeObj.optInt("status"));
                            tourismPlace.setCreatedAt(placeObj.optString("created_at"));
                            placeArrayList.add(tourismPlace);
                        }
                    }
                    HomeFragment homeFr = (HomeFragment) ((MainActivity) mContext).getSupportFragmentManager().findFragmentById(R.id.rlContent);
                    if (homeFr != null)
                        homeFr.showUserLocation(placeArrayList);
                    break;
                case Configs.URL_PLACE_LIST:
                    JSONArray placeArr = new JSONArray();
                    if (!mainJsonObj.getString("tourismPlaces").equalsIgnoreCase("[]")) {
                        placeArr = mainJsonObj.isNull("tourismPlaces") ? null : (JSONArray) mainJsonObj.opt("tourismPlaces");

                    }

                    TourismPlace place = null;
                    List<TourismPlace> placeList = new ArrayList<>();
                    if (placeArr != null && placeArr.length() > 0) {
                        for (int i = 0; i < placeArr.length(); i++) {
                            JSONObject jsonObject = placeArr.getJSONObject(i);
                            place = new TourismPlace();
                            place.setTourismPlaceId(jsonObject.optInt("tourism_place_id"));
                            place.setPlaceName(jsonObject.optString("place_name"));
                            place.setLatitude(jsonObject.optString("latitude"));
                            place.setLongitude(jsonObject.optString("longitude"));
                            place.setDescription(jsonObject.optString("description"));
                            place.setStatus(jsonObject.optInt("status"));
                            place.setCreatedAt(jsonObject.optString("created_at"));
                            place.setCoverPhoto(jsonObject.optString("cover_photo"));
                            /*List<Photos> photosList = new ArrayList<>();
                            if (!jsonObject.isNull("photos")) {
                                JSONObject phtoObj = jsonObject.getJSONObject("photos");
                                Photos placePhoto = new Photos();
                                placePhoto.setPhotoId(phtoObj.optInt("photo_id"));
                                placePhoto.setPhotoPath(phtoObj.optString("photo_path"));
                                placePhoto.setPhotoFor(phtoObj.optString("photo_for"));
                                placePhoto.setCaption(phtoObj.optString("caption"));
                                placePhoto.setStatus(phtoObj.optInt("status"));
                                placePhoto.setCreatedAt(phtoObj.optString("created_at"));
                                photosList.add(placePhoto);
                            }
                            place.setPhotosList(photosList);*/
                            placeList.add(place);
                        }
                    }
                    PlacesFragment placeFr = (PlacesFragment) ((MainActivity) mContext).getSupportFragmentManager().findFragmentById(R.id.rlContent);
                    placeFr.updatePlaceList(placeList);
                    break;
                case Configs.URL_SINGLE_PLACE:
                    String tour_guide = "";
                    JSONObject singlePlaceObj = new JSONObject();
                    if (!mainJsonObj.getString("tourismPlaces").equalsIgnoreCase("[]") || !mainJsonObj.getString("tourismPlaces").equalsIgnoreCase("{}")) {
                        singlePlaceObj = mainJsonObj.isNull("tourismPlaces") ? null : (JSONObject) mainJsonObj.opt("tourismPlaces");

                    }

                    TourismPlace singlePlace = null;
                    if (singlePlaceObj != null && singlePlaceObj.length() > 0) {
                        singlePlace = new TourismPlace();
                        singlePlace.setTourismPlaceId(singlePlaceObj.optInt("tourism_place_id"));
                        singlePlace.setPlaceName(singlePlaceObj.optString("place_name"));
                        singlePlace.setLatitude(singlePlaceObj.optString("latitude"));
                        singlePlace.setLongitude(singlePlaceObj.optString("longitude"));
                        singlePlace.setDescription(singlePlaceObj.optString("description"));
                        singlePlace.setStatus(singlePlaceObj.optInt("status"));
                        singlePlace.setCreatedAt(singlePlaceObj.optString("created_at"));
                        tour_guide = singlePlaceObj.optString("tour_guide");
                    }
                    if (req == REQUEST_TOUR_GUIDE) {
                        ((PdfViewerActivity) mContext).loadUrl(Configs.BASE_URL + tour_guide);

                    } else {
                        List<android.support.v4.app.Fragment> fragmentList = ((PlaceDetailsActivity) mContext).getSupportFragmentManager().getFragments();
                        for (android.support.v4.app.Fragment fragment : fragmentList) {
                            if (fragment instanceof PlaceDetailsFragment) {
                                PlaceDetailsFragment placeDetailsFr = (PlaceDetailsFragment) fragment;
                                placeDetailsFr.updatePlace(singlePlace);
                            }
                        }
                    }

                    break;
                case Configs.URL_SIGHT_SEEING_PLACE_LIST:
                    JSONArray sightPlaceArr = new JSONArray();
                    if (!mainJsonObj.getString("sightseeing_places").equalsIgnoreCase("[]")) {
                        sightPlaceArr = mainJsonObj.isNull("sightseeing_places") ? null : (JSONArray) mainJsonObj.opt("sightseeing_places");

                    }
                    List<SightSeeingPlace> sightPlaceList = new ArrayList<>();
                    if (sightPlaceArr != null && sightPlaceArr.length() > 0) {
                        SightSeeingPlace sightSeeingPlace = null;
                        for (int i = 0; i < sightPlaceArr.length(); i++) {
                            JSONObject placeObj = sightPlaceArr.getJSONObject(i);

                            sightSeeingPlace = new SightSeeingPlace();
                            sightSeeingPlace.setSightseeingPlaceId(placeObj.optInt("sightseeing_place_id"));
                            sightSeeingPlace.setTourismPlaceID(placeObj.optInt("tourism_place_id"));
                            sightSeeingPlace.setSightseeingPlaceName(placeObj.optString("sightseeing_place_name"));
                            sightSeeingPlace.setLatitude(placeObj.optString("latitude"));
                            sightSeeingPlace.setLongitude(placeObj.optString("longitude"));
                            sightSeeingPlace.setDescription(placeObj.optString("description"));
                            sightSeeingPlace.setStatus(placeObj.optInt("status"));
                            sightSeeingPlace.setCreatedAt(placeObj.optString("created_at"));
                            if (placeObj.isNull("photos")) {

                            } else {
                                JSONObject phtoObj = placeObj.getJSONObject("photos");
                                Photos placePhoto = new Photos();
                                placePhoto.setPhotoId(phtoObj.optInt("photo_id"));
                                placePhoto.setPhotoPath(phtoObj.optString("photo_path"));
                                placePhoto.setPhotoFor(phtoObj.optString("photo_for"));
                                placePhoto.setCaption(phtoObj.optString("caption"));
                                placePhoto.setStatus(phtoObj.optInt("status"));
                                placePhoto.setCreatedAt(phtoObj.optString("created_at"));
                                sightSeeingPlace.setPhoto(placePhoto);
                            }
                            sightPlaceList.add(sightSeeingPlace);
                        }
                    }
                    List<android.support.v4.app.Fragment> fragmentList2 = null;
                    if (req != REQUEST_SIGHT_SEEING_PLACE_LIST_FROM_NAV) {
                        fragmentList2 = ((PlaceDetailsActivity) mContext).getSupportFragmentManager().getFragments();
                    } else {
                        fragmentList2 = ((MainActivity) mContext).getSupportFragmentManager().getFragments();

                    }
                    if (fragmentList2 != null) {
                        for (android.support.v4.app.Fragment fragment : fragmentList2) {
                            if (req != REQUEST_SIGHT_SEEING_PLACE_LIST_FROM_NAV && fragment instanceof SightSeeingPlacesFragment) {
                                SightSeeingPlacesFragment sightSeeingPlacesFragment = (SightSeeingPlacesFragment) fragment;
                                sightSeeingPlacesFragment.updateSightSeeingPlaceList(sightPlaceList);
                            } else if (req == REQUEST_SIGHT_SEEING_PLACE_LIST_FROM_NAV && fragment instanceof NavSightPlaceFragment) {
                                NavSightPlaceFragment navSightPlaceFragment = (NavSightPlaceFragment) fragment;
                                navSightPlaceFragment.updateSightSeeingPlaceList(sightPlaceList);
                            }
                        }
                    }
                    break;
                case Configs.URL_PlACE_WISE_ALL_SIGHT_PLACE_IMAGES:
                    JSONArray slidersArr = new JSONArray();
                    if (!mainJsonObj.getString("places_photo").equalsIgnoreCase("[]")) {
                        slidersArr = mainJsonObj.isNull("places_photo") ? null : (JSONArray) mainJsonObj.opt("places_photo");

                    }
                    List<SliderModel> sliderModelList = new ArrayList<>();
                    if (slidersArr != null && slidersArr.length() > 0) {
                        SliderModel slider = null;
                        for (int i = 0; i < slidersArr.length(); i++) {
                            JSONObject sliderObj = slidersArr.getJSONObject(i);
                            slider = new SliderModel();
                            slider.setSightseeing_place_name(sliderObj.optString("sightseeing_place_name"));
                            if (sliderObj.isNull("photos")) {

                            } else {
                                JSONObject phtoObj = sliderObj.getJSONObject("photos");
                                Photos placePhoto = new Photos();
                                placePhoto.setPhotoId(phtoObj.optInt("photo_id"));
                                placePhoto.setPhotoPath(phtoObj.optString("photo_path"));
                                placePhoto.setPhotoFor(phtoObj.optString("photo_for"));
                                placePhoto.setCaption(phtoObj.optString("caption"));
                                placePhoto.setStatus(phtoObj.optInt("status"));
                                placePhoto.setCreatedAt(phtoObj.optString("created_at"));
                                slider.setPhotos(placePhoto);
                            }
                            sliderModelList.add(slider);
                        }
                    }
                    ((PlaceDetailsActivity) mContext).loadBannerSlider(sliderModelList);
                    break;
                case Configs.URL_SINGLE_SIGHT_PLACE:
                    JSONObject singleSightPlaceObj = new JSONObject();
                    if (!mainJsonObj.getString("sightseeingPlace").equalsIgnoreCase("[]") || !mainJsonObj.getString("sightseeingPlace").equalsIgnoreCase("{}")) {
                        singleSightPlaceObj = mainJsonObj.isNull("sightseeingPlace") ? null : (JSONObject) mainJsonObj.opt("sightseeingPlace");

                    }

                    SightSeeingPlace singleSightPlace = null;
                    if (singleSightPlaceObj != null && singleSightPlaceObj.length() > 0) {
                        singleSightPlace = new SightSeeingPlace();
                        singleSightPlace.setSightseeingPlaceId(singleSightPlaceObj.optInt("sightseeing_place_id"));
                        singleSightPlace.setSightseeingPlaceName(singleSightPlaceObj.optString("sightseeing_place_name"));
                        singleSightPlace.setLatitude(singleSightPlaceObj.optString("latitude"));
                        singleSightPlace.setLongitude(singleSightPlaceObj.optString("longitude"));
                        singleSightPlace.setDescription(singleSightPlaceObj.optString("description"));
                        singleSightPlace.setStatus(singleSightPlaceObj.optInt("status"));
                        singleSightPlace.setCreatedAt(singleSightPlaceObj.optString("created_at"));
                        if (!singleSightPlaceObj.isNull("photos")) {
                            List<Photos> photosList = new ArrayList<>();
                            JSONArray phtoArr = singleSightPlaceObj.getJSONArray("photos");
                            if (phtoArr != null && phtoArr.length() > 0) {
                                for (int i = 0; i < phtoArr.length(); i++) {
                                    JSONObject photoObj = phtoArr.getJSONObject(i);
                                    Photos placePhoto = new Photos();
                                    placePhoto.setPhotoId(photoObj.optInt("photo_id"));
                                    placePhoto.setPhotoPath(photoObj.optString("photo_path"));
                                    placePhoto.setPhotoFor(photoObj.optString("photo_for"));
                                    placePhoto.setCaption(photoObj.optString("caption"));
                                    placePhoto.setStatus(photoObj.optInt("status"));
                                    placePhoto.setCreatedAt(photoObj.optString("created_at"));
                                    photosList.add(placePhoto);
                                }
                            }
                            singleSightPlace.setAllPhotos(photosList);
                        }

                    }
                    ((SightPlaceDetailsActivity) mContext).updatePlace(singleSightPlace);
                    break;
                case Configs.URL_ACCOMMODATIONS_BY_PLACE_ID:
                    JSONArray accommodationJsArr = new JSONArray();
                    if (!mainJsonObj.getString("accommodationList").equalsIgnoreCase("[]")) {
                        accommodationJsArr = mainJsonObj.isNull("accommodationList") ? null : (JSONArray) mainJsonObj.opt("accommodationList");

                    }
                    List<Accommodation> accommodationList = new ArrayList<>();
                    if (accommodationJsArr != null && accommodationJsArr.length() > 0) {
                        Accommodation accommodation = null;
                        for (int i = 0; i < accommodationJsArr.length(); i++) {
                            JSONObject accommodationObj = accommodationJsArr.getJSONObject(i);
                            accommodation = new Accommodation();
                            accommodation.setAccomodationId(accommodationObj.optInt("accomodation_id"));
                            accommodation.setHotelName(accommodationObj.optString("hotel_name"));
                            accommodation.setStandard(accommodationObj.optInt("standard"));
                            accommodation.setLatitude(accommodationObj.optString("latitude"));
                            accommodation.setLongitude(accommodationObj.optString("longitude"));
                            accommodation.setAddress(accommodationObj.optString("address"));
                            accommodation.setMobileNo(accommodationObj.optString("mobile_no"));
                            accommodation.setDescription(accommodationObj.optString("description"));
                            accommodation.setStatus(accommodationObj.optInt("status"));
                            accommodation.setCreatedAt(accommodationObj.optString("created_at"));
                            if (accommodationObj.isNull("photos")) {

                            } else {
                                JSONObject phtoObj = accommodationObj.getJSONObject("photos");
                                Photos accoPhoto = new Photos();
                                accoPhoto.setPhotoId(phtoObj.optInt("photo_id"));
                                accoPhoto.setPhotoPath(phtoObj.optString("photo_path"));
                                accoPhoto.setPhotoFor(phtoObj.optString("photo_for"));
                                accoPhoto.setCaption(phtoObj.optString("caption"));
                                accoPhoto.setStatus(phtoObj.optInt("status"));
                                accoPhoto.setCreatedAt(phtoObj.optString("created_at"));
                                accommodation.setPhotos(accoPhoto);
                            }
                            accommodationList.add(accommodation);
                        }
                    }
                    ((AccommodationActivity) mContext).updateAccommodationList(accommodationList);
                    break;
                case Configs.URL_SINGLE_ACCOMMODATION:
                    JSONObject singleAccommodationJsObj = new JSONObject();
                    if (!mainJsonObj.getString("accommodationDetails").equalsIgnoreCase("[]") || !mainJsonObj.getString("accommodationDetails").equalsIgnoreCase("{}")) {
                        singleAccommodationJsObj = mainJsonObj.isNull("accommodationDetails") ? null : (JSONObject) mainJsonObj.opt("accommodationDetails");

                    }
                    Accommodation accommodation = null;
                    if (singleAccommodationJsObj != null && singleAccommodationJsObj.length() > 0) {
                        accommodation = new Accommodation();
                        accommodation.setAccomodationId(singleAccommodationJsObj.optInt("accomodation_id"));
                        accommodation.setHotelName(singleAccommodationJsObj.optString("hotel_name"));
                        accommodation.setStandard(singleAccommodationJsObj.optInt("standard"));
                        accommodation.setLatitude(singleAccommodationJsObj.optString("latitude"));
                        accommodation.setLongitude(singleAccommodationJsObj.optString("longitude"));
                        accommodation.setAddress(singleAccommodationJsObj.optString("address"));
                        accommodation.setMobileNo(singleAccommodationJsObj.optString("mobile_no"));
                        accommodation.setDescription(singleAccommodationJsObj.optString("description"));
                        accommodation.setStatus(singleAccommodationJsObj.optInt("status"));
                        accommodation.setCreatedAt(singleAccommodationJsObj.optString("created_at"));
                        if (!singleAccommodationJsObj.isNull("photos")) {
                            List<Photos> photosList = new ArrayList<>();
                            JSONArray phtoArr = singleAccommodationJsObj.getJSONArray("photos");
                            if (phtoArr != null && phtoArr.length() > 0) {
                                for (int i = 0; i < phtoArr.length(); i++) {
                                    JSONObject photoObj = phtoArr.getJSONObject(i);
                                    Photos accommodationPhoto = new Photos();
                                    accommodationPhoto.setPhotoId(photoObj.optInt("photo_id"));
                                    accommodationPhoto.setPhotoPath(photoObj.optString("photo_path"));
                                    accommodationPhoto.setPhotoFor(photoObj.optString("photo_for"));
                                    accommodationPhoto.setCaption(photoObj.optString("caption"));
                                    accommodationPhoto.setStatus(photoObj.optInt("status"));
                                    accommodationPhoto.setCreatedAt(photoObj.optString("created_at"));
                                    photosList.add(accommodationPhoto);
                                }
                            }
                            accommodation.setPhotosList(photosList);
                        }

                    }
                    ((AccommodationDetailsActivity) mContext).updateAccommodation(accommodation);
                    break;
                case Configs.URL_FESTIVAL_LIST:
                    JSONArray festivaljsArr = new JSONArray();
                    if (!mainJsonObj.getString("festivals").equalsIgnoreCase("[]")) {
                        festivaljsArr = mainJsonObj.isNull("festivals") ? null : (JSONArray) mainJsonObj.opt("festivals");

                    }
                    List<Festival> festivalList = new ArrayList<>();
                    if (festivaljsArr != null && festivaljsArr.length() > 0) {
                        Festival festival = null;
                        for (int i = 0; i < festivaljsArr.length(); i++) {
                            JSONObject festivalJsonObj = festivaljsArr.getJSONObject(i);

                            festival = new Festival();
                            festival.setFestivalId(festivalJsonObj.optInt("festival_id"));
                            festival.setFestivalAt(festivalJsonObj.optString("festival_at"));
                            festival.setDescription(festivalJsonObj.optString("description"));
                            festival.setStatus(festivalJsonObj.optInt("status"));
                            festival.setCreatedAt(festivalJsonObj.optString("created_at"));
                            festivalList.add(festival);
                        }
                    }
                    ((FestivalCalenderActivity) mContext).updateList(festivalList);

                    break;
                case Configs.URL_TRANSPORT_LIST_BY_PLACE:

                    JSONArray transportJsArr = new JSONArray();
                    if (!mainJsonObj.getString("transports").equalsIgnoreCase("[]")) {
                        transportJsArr = mainJsonObj.isNull("transports") ? null : (JSONArray) mainJsonObj.opt("transports");

                    }
                    List<Transport> transportList = new ArrayList<>();
                    if (transportJsArr != null && transportJsArr.length() > 0) {
                        Transport transport = null;
                        for (int i = 0; i < transportJsArr.length(); i++) {
                            JSONObject transportJsonObj = transportJsArr.getJSONObject(i);
                            transport = new Transport();
                            transport.setTrasportId(transportJsonObj.optInt("trasport_id"));
                            transport.setTransportName(transportJsonObj.optString("transport_name"));
                            transport.setTransportType(transportJsonObj.optString("transport_type"));
                            transport.setDescription(transportJsonObj.optString("description"));
                            transport.setStatus(transportJsonObj.optInt("status"));
                            transport.setCreatedAt(transportJsonObj.optString("created_at"));
                            transportList.add(transport);
                        }
                    }
                    List<android.support.v4.app.Fragment> transportFragList = ((TransportsActivity) mContext).getSupportFragmentManager().getFragments();
                    for (android.support.v4.app.Fragment fragment : transportFragList) {
                        if (fragment instanceof TransportsFragment) {
                            TransportsFragment transportsFragment = (TransportsFragment) fragment;
                            transportsFragment.updateList(transportList);
                        }
                    }
                    break;
                case Configs.URL_RESTAURANTS_BY_PLACE:
                    JSONArray restaurantJsArr = new JSONArray();
                    if (!mainJsonObj.getString("restaurantList").equalsIgnoreCase("[]")) {
                        restaurantJsArr = mainJsonObj.isNull("restaurantList") ? null : (JSONArray) mainJsonObj.opt("restaurantList");

                    }
                    List<Restaurant> restaurantList = new ArrayList<>();
                    if (restaurantJsArr != null && restaurantJsArr.length() > 0) {
                        Restaurant restaurant = null;
                        for (int i = 0; i < restaurantJsArr.length(); i++) {
                            JSONObject restaurantObj = restaurantJsArr.getJSONObject(i);
                            restaurant = new Restaurant();
                            restaurant.setRestaurantId(restaurantObj.optInt("restaurant_id"));
                            restaurant.setRestaurantName(restaurantObj.optString("restaurant_name"));
                            restaurant.setLatitude(restaurantObj.optString("latitude"));
                            restaurant.setLongitude(restaurantObj.optString("longitude"));
                            restaurant.setAddress(restaurantObj.optString("address"));
                            restaurant.setMobileNo(restaurantObj.optString("mobile_no"));
                            restaurant.setDescription(restaurantObj.optString("description"));
                            restaurant.setStatus(restaurantObj.optInt("status"));
                            restaurant.setCreatedAt(restaurantObj.optString("created_at"));
                            if (restaurantObj.isNull("photos")) {
                            } else {
                                JSONObject phtoObj = restaurantObj.getJSONObject("photos");
                                Photos restaurantPhoto = new Photos();
                                restaurantPhoto.setPhotoId(phtoObj.optInt("photo_id"));
                                restaurantPhoto.setPhotoPath(phtoObj.optString("photo_path"));
                                restaurantPhoto.setPhotoFor(phtoObj.optString("photo_for"));
                                restaurantPhoto.setCaption(phtoObj.optString("caption"));
                                restaurantPhoto.setStatus(phtoObj.optInt("status"));
                                restaurantPhoto.setCreatedAt(phtoObj.optString("created_at"));
                                restaurant.setPhotos(restaurantPhoto);
                            }
                            restaurantList.add(restaurant);
                        }
                    }
                    ((FoodActivity) mContext).updateRestaurantsList(restaurantList);
                    break;
                case Configs.URL_SINGLE_RESTAURANT:

                    JSONObject singleRestaurantJspObj = new JSONObject();
                    if (!mainJsonObj.getString("restaurantDetails").equalsIgnoreCase("[]") || !mainJsonObj.getString("restaurantDetails").equalsIgnoreCase("{}")) {
                        singleRestaurantJspObj = mainJsonObj.isNull("restaurantDetails") ? null : (JSONObject) mainJsonObj.opt("restaurantDetails");

                    }
                    Restaurant restaurant = null;
                    if (singleRestaurantJspObj != null && singleRestaurantJspObj.length() > 0) {
                        restaurant = new Restaurant();
                        restaurant.setRestaurantId(singleRestaurantJspObj.optInt("restaurant_id"));
                        restaurant.setRestaurantName(singleRestaurantJspObj.optString("restaurant_name"));
                        restaurant.setLatitude(singleRestaurantJspObj.optString("latitude"));
                        restaurant.setLongitude(singleRestaurantJspObj.optString("longitude"));
                        restaurant.setAddress(singleRestaurantJspObj.optString("address"));
                        restaurant.setMobileNo(singleRestaurantJspObj.optString("mobile_no"));
                        restaurant.setDescription(singleRestaurantJspObj.optString("description"));
                        restaurant.setStatus(singleRestaurantJspObj.optInt("status"));
                        restaurant.setCreatedAt(singleRestaurantJspObj.optString("created_at"));
                        if (!singleRestaurantJspObj.isNull("photos")) {
                            List<Photos> photosList = new ArrayList<>();
                            JSONArray phtoArr = singleRestaurantJspObj.getJSONArray("photos");
                            if (phtoArr != null && phtoArr.length() > 0) {
                                for (int i = 0; i < phtoArr.length(); i++) {
                                    JSONObject photoObj = phtoArr.getJSONObject(i);
                                    Photos resturantAPhoto = new Photos();
                                    resturantAPhoto.setPhotoId(photoObj.optInt("photo_id"));
                                    resturantAPhoto.setPhotoPath(photoObj.optString("photo_path"));
                                    resturantAPhoto.setPhotoFor(photoObj.optString("photo_for"));
                                    resturantAPhoto.setCaption(photoObj.optString("caption"));
                                    resturantAPhoto.setStatus(photoObj.optInt("status"));
                                    resturantAPhoto.setCreatedAt(photoObj.optString("created_at"));
                                    photosList.add(resturantAPhoto);
                                }
                            }
                            restaurant.setPhotosList(photosList);
                        }

                    }
                    ((RestaurantDetailActivity) mContext).updateRestaurant(restaurant);
                    break;
                case Configs.URL_BANKS_BY_PLACE:
                    JSONArray transactionsJsArr = new JSONArray();
                    if (!mainJsonObj.getString("nearestTransections").equalsIgnoreCase("[]")) {
                        transactionsJsArr = mainJsonObj.isNull("nearestTransections") ? null : (JSONArray) mainJsonObj.opt("nearestTransections");

                    }
                    List<NearestTransaction> transactionList = new ArrayList<>();
                    if (transactionsJsArr != null && transactionsJsArr.length() > 0) {
                        NearestTransaction nearestTransaction = null;
                        for (int i = 0; i < transactionsJsArr.length(); i++) {
                            JSONObject transactionJsObj = transactionsJsArr.getJSONObject(i);
                            nearestTransaction = new NearestTransaction();
                            nearestTransaction.setBoothId(transactionJsObj.optInt("booth_id"));
                            nearestTransaction.setBankOrBoothName(transactionJsObj.optString("bank_or_booth_name"));
                            nearestTransaction.setLatitude(transactionJsObj.optString("latitude"));
                            nearestTransaction.setLongitude(transactionJsObj.optString("longitude"));
                            nearestTransaction.setAddress(transactionJsObj.optString("address"));
                            nearestTransaction.setDescription(transactionJsObj.optString("description"));
                            nearestTransaction.setStatus(transactionJsObj.optInt("status"));
                            nearestTransaction.setCreatedAt(transactionJsObj.optString("created_at"));
                            transactionList.add(nearestTransaction);
                        }
                    }
                    ((TransactionsActivity) mContext).updateTransactionList(transactionList);
                    break;
                case Configs.URL_TRAVEL_AGENT_BY_PLACE:

                    JSONArray travelAgentJsArr = new JSONArray();
                    if (!mainJsonObj.getString("travelAgents").equalsIgnoreCase("[]")) {
                        travelAgentJsArr = mainJsonObj.isNull("travelAgents") ? null : (JSONArray) mainJsonObj.opt("travelAgents");
                    }
                    List<TravelAgent> travelAgentList = new ArrayList<>();
                    if (travelAgentJsArr != null && travelAgentJsArr.length() > 0) {
                        TravelAgent travelAgent = null;
                        for (int i = 0; i < travelAgentJsArr.length(); i++) {
                            JSONObject travelAgentJsObj = travelAgentJsArr.getJSONObject(i);
                            travelAgent = new TravelAgent();
                            travelAgent.setAgentId(travelAgentJsObj.optInt("agent_id"));
                            travelAgent.setTravelAgentName(travelAgentJsObj.optString("travel_agent_name"));
                            travelAgent.setLatitude(travelAgentJsObj.optString("latitude"));
                            travelAgent.setLongitude(travelAgentJsObj.optString("longitude"));
                            travelAgent.setAddress(travelAgentJsObj.optString("address"));
                            travelAgent.setMobileNo(travelAgentJsObj.optString("mobile_no"));
                            travelAgent.setDescription(travelAgentJsObj.optString("description"));
                            travelAgent.setStatus(travelAgentJsObj.optInt("status"));
                            travelAgent.setCreatedAt(travelAgentJsObj.optString("created_at"));
                            travelAgentList.add(travelAgent);
                        }
                    }
                    ((TravelAgentsActivity) mContext).updateTravelAgentList(travelAgentList);
                    break;
                case Configs.URL_TOUR_PRODUCTS_BY_PLACE:
                    JSONArray tourProductJsArr = new JSONArray();
                    if (!mainJsonObj.getString("tourProducts").equalsIgnoreCase("[]")) {
                        tourProductJsArr = mainJsonObj.isNull("tourProducts") ? null : (JSONArray) mainJsonObj.opt("tourProducts");

                    }
                    List<TourProduct> tourProductList = new ArrayList<>();
                    if (tourProductJsArr != null && tourProductJsArr.length() > 0) {
                        TourProduct tourProduct = null;
                        for (int i = 0; i < tourProductJsArr.length(); i++) {
                            JSONObject tourProductJsObj = tourProductJsArr.getJSONObject(i);

                            tourProduct = new TourProduct();
                            tourProduct.setProductId(tourProductJsObj.optInt("product_id"));
                            tourProduct.setProductName(tourProductJsObj.optString("product_name"));
                            tourProduct.setDescription(tourProductJsObj.optString("description"));
                            tourProduct.setStatus(tourProductJsObj.optInt("status"));
                            tourProduct.setCreatedAt(tourProductJsObj.optString("created_at"));
                            if (tourProductJsObj.isNull("photos")) {

                            } else {
                                JSONObject phtoObj = tourProductJsObj.getJSONObject("photos");
                                Photos tourProductPhoto = new Photos();
                                tourProductPhoto.setPhotoId(phtoObj.optInt("photo_id"));
                                tourProductPhoto.setPhotoPath(phtoObj.optString("photo_path"));
                                tourProductPhoto.setPhotoFor(phtoObj.optString("photo_for"));
                                tourProductPhoto.setCaption(phtoObj.optString("caption"));
                                tourProductPhoto.setStatus(phtoObj.optInt("status"));
                                tourProductPhoto.setCreatedAt(phtoObj.optString("created_at"));
                                tourProduct.setPhotos(tourProductPhoto);
                            }
                            tourProductList.add(tourProduct);
                        }
                    }
                    ((TourProductsActivity) mContext).updateTourProductList(tourProductList);
                    break;
                case Configs.URL_CONTACT_LIST_BY_PLACE:
                    JSONArray contactJsArr = new JSONArray();
                    if (!mainJsonObj.getString("helipline").equalsIgnoreCase("[]")) {
                        contactJsArr = mainJsonObj.isNull("helipline") ? null : (JSONArray) mainJsonObj.opt("helipline");

                    }
                    List<Contact> contactList = new ArrayList<>();
                    if (contactJsArr != null && contactJsArr.length() > 0) {
                        Contact contact = null;
                        for (int i = 0; i < contactJsArr.length(); i++) {
                            JSONObject contactJsonObj = contactJsArr.getJSONObject(i);
                            contact = new Contact();
                            contact.setContactId(contactJsonObj.optInt("contact_id"));
                            contact.setHelpLineFor(contactJsonObj.optString("help_line_for"));
                            contact.setContactNumber(contactJsonObj.optString("contact_number"));
                            contact.setAddress(contactJsonObj.optString("address"));
                            contact.setStatus(contactJsonObj.optInt("status"));
                            contact.setCreatedAt(contactJsonObj.optString("created_at"));
                            contactList.add(contact);
                        }
                    }

                    List<android.support.v4.app.Fragment> helplineFragList = ((HelplineActivity) mContext).getSupportFragmentManager().getFragments();
                    for (android.support.v4.app.Fragment fragment : helplineFragList) {
                        if (fragment instanceof HelplineContactsFragment) {
                            HelplineContactsFragment contactsFragment = (HelplineContactsFragment) fragment;
                            contactsFragment.updateList(contactList);
                        }
                    }
                    break;
                case Configs.URL_SINGLE_PRODUCT:
                    JSONObject singleTourProductJsObj = new JSONObject();
                    if (!mainJsonObj.getString("productDetails").equalsIgnoreCase("[]") || !mainJsonObj.getString("productDetails").equalsIgnoreCase("{}")) {
                        singleTourProductJsObj = mainJsonObj.isNull("productDetails") ? null : (JSONObject) mainJsonObj.opt("productDetails");
                    }
                    TourProduct tourProduct = null;
                    if (singleTourProductJsObj != null && singleTourProductJsObj.length() > 0) {
                        tourProduct = new TourProduct();
                        tourProduct.setProductId(singleTourProductJsObj.optInt("product_id"));
                        tourProduct.setProductName(singleTourProductJsObj.optString("product_name"));
                        tourProduct.setDescription(singleTourProductJsObj.optString("description"));
                        tourProduct.setStatus(singleTourProductJsObj.optInt("status"));
                        tourProduct.setCreatedAt(singleTourProductJsObj.optString("created_at"));
                        if (!singleTourProductJsObj.isNull("photos")) {
                            List<Photos> photosList = new ArrayList<>();
                            JSONArray phtoArr = singleTourProductJsObj.getJSONArray("photos");
                            if (phtoArr != null && phtoArr.length() > 0) {
                                for (int i = 0; i < phtoArr.length(); i++) {
                                    JSONObject photoObj = phtoArr.getJSONObject(i);
                                    Photos productPhoto = new Photos();
                                    productPhoto.setPhotoId(photoObj.optInt("photo_id"));
                                    productPhoto.setPhotoPath(photoObj.optString("photo_path"));
                                    productPhoto.setPhotoFor(photoObj.optString("photo_for"));
                                    productPhoto.setCaption(photoObj.optString("caption"));
                                    productPhoto.setStatus(photoObj.optInt("status"));
                                    productPhoto.setCreatedAt(photoObj.optString("created_at"));
                                    photosList.add(productPhoto);
                                }
                            }
                            tourProduct.setPhotosList(photosList);
                        }
                    }
                    ((TourProductDetailsActivity) mContext).updateProduct(tourProduct);
                    break;
                case Configs.URL_VIDEO_CATEGORY_BY_PLACE:
                    JSONArray categoryJsArr = new JSONArray();
                    if (!mainJsonObj.getString("categories").equalsIgnoreCase("[]")) {
                        categoryJsArr = mainJsonObj.isNull("categories") ? null : (JSONArray) mainJsonObj.opt("categories");

                    }
                    List<VideoCategory> categoryList = new ArrayList<>();
                    if (categoryJsArr != null && categoryJsArr.length() > 0) {
                        VideoCategory videoCategory = null;
                        for (int i = 0; i < categoryJsArr.length(); i++) {
                            JSONObject contactJsonObj = categoryJsArr.getJSONObject(i);
                            videoCategory = new VideoCategory();
                            videoCategory.setCategoryId(contactJsonObj.optInt("category_id"));
                            videoCategory.setCategoryName(contactJsonObj.optString("category_name"));
                            videoCategory.setStatus(contactJsonObj.optInt("status"));
                            videoCategory.setCreatedAt(contactJsonObj.optString("created_at"));
                            categoryList.add(videoCategory);
                        }
                    }
                    if (categoryList.size() > 0) {
                        ((HeritageGalleryActivity) mContext).updateCategoryList(categoryList);
                    }
                    break;
                case Configs.URL_VIDEO_LIST:
                    JSONArray videosJsArr = new JSONArray();
                    if (!mainJsonObj.getString("videos").equalsIgnoreCase("[]")) {
                        videosJsArr = mainJsonObj.isNull("videos") ? null : (JSONArray) mainJsonObj.opt("videos");

                    }
                    List<VideoFile> videoFileList = new ArrayList<>();
                    if (videosJsArr != null && videosJsArr.length() > 0) {
                        VideoFile videoFile = null;
                        for (int i = 0; i < videosJsArr.length(); i++) {
                            JSONObject contactJsonObj = videosJsArr.getJSONObject(i);
                            videoFile = new VideoFile();
                            videoFile.setVideoId(contactJsonObj.optInt("video_id"));
                            videoFile.setVideoLink(contactJsonObj.optString("video_link"));
                            videoFile.setDescription(contactJsonObj.optString("description"));
                            videoFile.setStatus(contactJsonObj.optInt("status"));
                            videoFile.setCreatedAt(contactJsonObj.optString("created_at"));
                            videoFileList.add(videoFile);
                        }
                    }
                    if (videoFileList.size() > 0) {
                        ((VideoListActivity) mContext).updateVideoList(videoFileList);
                    }
                    break;
            }
        } catch (JSONException e) {
            this.onErrorResponse(url, e.getMessage());
        }

    }

    @Override
    public void onErrorResponse(String url, String response) {
        switch (url) {
            case Configs.URL_LOCATION_URL:
                HomeFragment homeFr = (HomeFragment) ((MainActivity) mContext).getSupportFragmentManager().findFragmentById(R.id.rlContent);
                homeFr.showErrorMsg(response);
                break;
            case Configs.URL_PLACE_LIST:
                PlacesFragment placeFr = (PlacesFragment) ((MainActivity) mContext).getSupportFragmentManager().findFragmentById(R.id.rlContent);
                placeFr.showErrorMsg(response);
                break;
            case Configs.URL_SINGLE_PLACE:
                List<android.support.v4.app.Fragment> fragmentList = ((PlaceDetailsActivity) mContext).getSupportFragmentManager().getFragments();
                for (android.support.v4.app.Fragment fragment : fragmentList) {
                    if (fragment instanceof PlaceDetailsFragment) {
                        PlaceDetailsFragment placeDetailsFr = (PlaceDetailsFragment) fragment;
                        placeDetailsFr.showErrorMsg(response);
                    }
                }
                break;
            case Configs.URL_SIGHT_SEEING_PLACE_LIST:
                List<android.support.v4.app.Fragment> fragmentList2 = null;
                if (req != REQUEST_SIGHT_SEEING_PLACE_LIST_FROM_NAV) {
                    fragmentList2 = ((PlaceDetailsActivity) mContext).getSupportFragmentManager().getFragments();
                } else {
                    fragmentList2 = ((MainActivity) mContext).getSupportFragmentManager().getFragments();

                }
                if (fragmentList2 != null) {
                    for (android.support.v4.app.Fragment fragment : fragmentList2) {
                        if (req != REQUEST_SIGHT_SEEING_PLACE_LIST_FROM_NAV && fragment instanceof SightSeeingPlacesFragment) {
                            SightSeeingPlacesFragment sightSeeingPlacesFragment = (SightSeeingPlacesFragment) fragment;
                            sightSeeingPlacesFragment.showErrorMsg(response);
                        } else if (req == REQUEST_SIGHT_SEEING_PLACE_LIST_FROM_NAV && fragment instanceof NavSightPlaceFragment) {
                            NavSightPlaceFragment navSightPlaceFragment = (NavSightPlaceFragment) fragment;
                            navSightPlaceFragment.showErrorMsg(response);
                        }
                    }
                }
                break;
            case Configs.URL_PlACE_WISE_ALL_SIGHT_PLACE_IMAGES:
                ((PlaceDetailsActivity) mContext).showErrorMsg(response);
                break;
            case Configs.URL_SINGLE_SIGHT_PLACE:
                ((SightPlaceDetailsActivity) mContext).showErrorMsg(response);
                break;
            case Configs.URL_ACCOMMODATIONS_BY_PLACE_ID:
                ((AccommodationActivity) mContext).showErrorMsg(response);
                break;
            case Configs.URL_SINGLE_ACCOMMODATION:
                ((AccommodationDetailsActivity) mContext).showErrorMsg(response);
                break;
            case Configs.URL_FESTIVAL_LIST:
                ((FestivalCalenderActivity) mContext).showErrorMsg(response);
                break;
            case Configs.URL_TRANSPORT_LIST_BY_PLACE:
                List<android.support.v4.app.Fragment> transportFragList = ((TransportsActivity) mContext).getSupportFragmentManager().getFragments();
                for (android.support.v4.app.Fragment fragment : transportFragList) {
                    if (fragment instanceof TransportsFragment) {
                        TransportsFragment transportsFragment = (TransportsFragment) fragment;
                        transportsFragment.showErrorMsg(response);
                    }
                }
                break;
            case Configs.URL_RESTAURANTS_BY_PLACE:
                ((FoodActivity) mContext).showErrorMsg(response);
                break;
            case Configs.URL_SINGLE_RESTAURANT:
                ((RestaurantDetailActivity) mContext).showErrorMsg(response);
                break;
            case Configs.URL_BANKS_BY_PLACE:
                ((TransactionsActivity) mContext).showErrorMsg(response);
                break;
            case Configs.URL_TRAVEL_AGENT_BY_PLACE:
                ((TravelAgentsActivity) mContext).showErrorMsg(response);
                break;
            case Configs.URL_TOUR_PRODUCTS_BY_PLACE:
                ((TourProductsActivity) mContext).showErrorMsg(response);
                break;
            case Configs.URL_CONTACT_LIST_BY_PLACE:
                List<android.support.v4.app.Fragment> helplineFragList = ((HelplineActivity) mContext).getSupportFragmentManager().getFragments();
                for (android.support.v4.app.Fragment fragment : helplineFragList) {
                    if (fragment instanceof HelplineContactsFragment) {
                        HelplineContactsFragment contactsFragment = (HelplineContactsFragment) fragment;
                        contactsFragment.showErrorMsg(response);
                    }
                }
                break;
            case Configs.URL_SINGLE_PRODUCT:
                ((TourProductDetailsActivity) mContext).showErrorMsg(response);
                break;
            case Configs.URL_VIDEO_CATEGORY_BY_PLACE:
                ((HeritageGalleryActivity) mContext).showErrorMsg(response);
                break;
            case Configs.URL_VIDEO_LIST:
                ((VideoListActivity) mContext).showErrorMsg(response);
                break;
        }
    }
}