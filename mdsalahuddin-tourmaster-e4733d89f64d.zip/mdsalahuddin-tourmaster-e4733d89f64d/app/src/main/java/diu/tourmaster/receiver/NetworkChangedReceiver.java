package diu.tourmaster.receiver;

import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RelativeLayout;

import diu.tourmaster.R;
import diu.tourmaster.activities.NoInternetActivity;
import diu.tourmaster.utils.ConnectionChecker;

import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;

/**
 * Created by tajmulalam on 2/1/18.
 */

public class NetworkChangedReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        context.startActivity(new Intent(context, NoInternetActivity.class).addFlags(FLAG_ACTIVITY_NEW_TASK));
        // for setting store for log size
    }


}
