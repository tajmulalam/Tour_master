package diu.tourmaster.activities;

import android.app.ActionBar;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.controllers.CommonController;
import diu.tourmaster.fragments.FacilitiesFragment;
import diu.tourmaster.fragments.PlaceDetailsFragment;
import diu.tourmaster.fragments.SightSeeingPlacesFragment;
import diu.tourmaster.models.SliderModel;
import diu.tourmaster.utils.Configs;
import diu.tourmaster.utils.CustomToast;
import diu.tourmaster.utils.StaticAccess;
import diu.tourmaster.utils.ToolbarConfig;
import diu.tourmaster.utils.Utilities;
import ss.com.bannerslider.banners.Banner;
import ss.com.bannerslider.banners.DrawableBanner;
import ss.com.bannerslider.banners.RemoteBanner;
import ss.com.bannerslider.views.BannerSlider;

public class PlaceDetailsActivity extends BaseActivity {
    private int placeID = -1;
    private PlaceDetailsActivity activity;
    TabLayout tabLayout;
    BannerSlider bannerSlider;
    CommonController commonController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BaseActivity.setLocale(this);

        setContentView(R.layout.activity_place_details);
        receiveIntent();
        initToolbar();
        initUI();
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //ToolbarConfig.centerTitleAndSubtitle(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishTheActivity();
            }
        });
        ToolbarConfig.makeStatusBarTransparent(getWindow());
    }

    private void finishTheActivity() {
        finish();
    }


    private void receiveIntent() {
        activity = this;
        commonController = new CommonController(activity);
        if (getIntent() != null) {
            placeID = getIntent().getIntExtra(StaticAccess.KEY_PLACE_ID_INTENT, -1);
        }
    }

    private void initUI() {
        tabLayout = (TabLayout) findViewById(R.id.TLplaceFeature);
        tabLayout.setTabTextColors(
                ContextCompat.getColor(activity, android.R.color.white),
                ContextCompat.getColor(activity, android.R.color.white)
        );
        tabLayout.setSelectedTabIndicatorColor(Color.WHITE);
        TabLayout.Tab firstTab = tabLayout.newTab();
        firstTab.setText(R.string.place_description);
        //firstTab.setIcon(R.drawable.ic_logo); // set an icon for the
        tabLayout.addTab(firstTab); // add  the tab at in the TabLayout
        TabLayout.Tab secondTab = tabLayout.newTab();
        secondTab.setText(R.string.sight_places); // set the Text for the second Tab
        tabLayout.addTab(secondTab); // add  the tab  in the TabLayout
        TabLayout.Tab thirdTab = tabLayout.newTab();
        thirdTab.setText(getString(R.string.facilities)); // set the Text for the first Tab
        tabLayout.addTab(thirdTab); // add  the tab at in the TabLayout
        changeTabsFont();
        // perform setOnTabSelectedListener event on TabLayout
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                // get the current selected tab's position and replace the fragment accordingly
                setSelectFragment(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        bannerSlider = (BannerSlider) findViewById(R.id.bannerSlider);
        bannerApiCall();

    }
    private void changeTabsFont() {
        Typeface typeface = Typeface.createFromAsset(activity.getAssets(), "font/rancho3.ttf");

        ViewGroup vg = (ViewGroup) tabLayout.getChildAt(0);
        int tabsCount = vg.getChildCount();
        for (int j = 0; j < tabsCount; j++) {
            ViewGroup vgTab = (ViewGroup) vg.getChildAt(j);
            int tabChildsCount = vgTab.getChildCount();
            for (int i = 0; i < tabChildsCount; i++) {
                View tabViewChild = vgTab.getChildAt(i);
                if (tabViewChild instanceof TextView) {
                    ((TextView) tabViewChild).setTypeface(typeface);
                }
            }
        }
    }
    private void bannerApiCall() {
        HashMap<String, String> params = Utilities.getInstance().getRequestParams();
        params.put("tourism_place_id", String.valueOf(placeID));
        commonController.callApi(CommonController.REQUEST_PlACE_WISE_ALL_SIGHT_PLACE_IMAGES, params, true);
    }

    public void loadBannerSlider(List<SliderModel> sliderModelList) {
        List<Banner> banners = new ArrayList<>();
        if (sliderModelList.size() > 0) {
            for (SliderModel slider : sliderModelList) {
                //add banner using image url
                if (slider.getPhotos() != null) {
                    RemoteBanner remoteBanner = new RemoteBanner(Configs.BASE_URL + slider.getPhotos().getPhotoPath());
                    remoteBanner.setScaleType(ImageView.ScaleType.FIT_XY);
                    banners.add(remoteBanner);
                    //add banner using resource drawable
                }
            }
        } else {
            DrawableBanner drawableBanner = new DrawableBanner(R.drawable.placeholder);
            drawableBanner.setScaleType(ImageView.ScaleType.FIT_XY);
            banners.add(drawableBanner);
        }
        bannerSlider.setBanners(banners);
        setSelectFragment(0);
    }

    private void setSelectFragment(int position) {
        Fragment fragment = null;
        Bundle bundle = null;
        switch (position) {
            case 0:
                fragment = new PlaceDetailsFragment();
                bundle = new Bundle();
                bundle.putInt(StaticAccess.KEY_PLACE_ID_INTENT, placeID);
                fragment.setArguments(bundle);
                break;
            case 1:
                fragment = new SightSeeingPlacesFragment();
                bundle = new Bundle();
                bundle.putInt(StaticAccess.KEY_PLACE_ID_INTENT, placeID);
                fragment.setArguments(bundle);
                break;
            case 2:
                fragment = FacilitiesFragment.newInstance(1, placeID);
                break;
        }
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.rlPlaceDes, fragment);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        ft.commit();
    }

    @Override
    protected void onResume() {
        super.onResume();

    }
/*
    public void centerTitleAndSubtitle(Toolbar toolbar) {
        // Save current title and subtitle
        final CharSequence originalTitle = toolbar.getTitle();
        final CharSequence originalSubtitle = toolbar.getSubtitle();

        // Temporarily modify title and subtitle to help detecting each
        toolbar.setTitle("title");
        toolbar.setSubtitle("subtitle");

        for (int i = 0; i < toolbar.getChildCount(); i++) {
            View view = toolbar.getChildAt(i);

            if (view instanceof TextView) {
                TextView textView = (TextView) view;


                if (textView.getText().equals("title")) {
                    // Customize title's TextView
                    Toolbar.LayoutParams params = new Toolbar.LayoutParams(Toolbar.LayoutParams.WRAP_CONTENT, Toolbar.LayoutParams.MATCH_PARENT);
                    params.gravity = Gravity.CENTER_HORIZONTAL;
                    params.setMargins(0, 25, 0, 0);
                    textView.setLayoutParams(params);

                } else if (textView.getText().equals("subtitle")) {
                    // Customize subtitle's TextView
                    Toolbar.LayoutParams params = new Toolbar.LayoutParams(Toolbar.LayoutParams.WRAP_CONTENT, Toolbar.LayoutParams.MATCH_PARENT);
                    params.gravity = Gravity.CENTER_HORIZONTAL;
                    params.setMargins(0, 25, 0, 0);
                    textView.setLayoutParams(params);
                }
            }

            // Restore title and subtitle
            toolbar.setTitle(originalTitle);
            toolbar.setSubtitle(originalSubtitle);
        }
    }*/


    public void showErrorMsg(String msg) {
        CustomToast.makeToastWarning(activity, msg);
    }
}
