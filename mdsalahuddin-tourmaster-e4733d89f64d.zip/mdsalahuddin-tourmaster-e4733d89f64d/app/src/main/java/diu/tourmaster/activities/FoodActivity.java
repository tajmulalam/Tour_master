package diu.tourmaster.activities;

import android.content.Intent;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.miguelcatalan.materialsearchview.MaterialSearchView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;

import diu.tourmaster.R;
import diu.tourmaster.adapters.AccommodationListAdapter;
import diu.tourmaster.adapters.EmptyAdapter;
import diu.tourmaster.adapters.RestaurantsListAdapter;
import diu.tourmaster.controllers.CommonController;
import diu.tourmaster.listener.SearchTextGetListener;
import diu.tourmaster.models.Accommodation;
import diu.tourmaster.models.Restaurant;
import diu.tourmaster.utils.ConnectionChecker;
import diu.tourmaster.utils.CustomToast;
import diu.tourmaster.utils.StaticAccess;
import diu.tourmaster.utils.StaticInstance;
import diu.tourmaster.utils.ToolbarConfig;
import diu.tourmaster.utils.Utilities;

public class FoodActivity extends BaseActivity implements RestaurantsListAdapter.RestaurantClickedListener {
    private RecyclerView rvRestaurantList;
    private FoodActivity activity;
    private int placeID = -1;
    private MaterialSearchView searchView;
    private RecyclerView.Adapter adapter;
    private List<Restaurant> mList;
private SwipeRefreshLayout swFood;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BaseActivity.setLocale(this);
        setContentView(R.layout.activity_food);
        initStaticInstance();
        receiveBundle();
        initToolbar();
        initUI();
        callApi();
    }

    private void initStaticInstance() {
        mList = new ArrayList<>();
        mFilterList = new ArrayList<>();
        staticInstance = StaticInstance.getInstance();
    }

    private void receiveBundle() {
        activity = this;
        placeID = getIntent() != null ? getIntent().getIntExtra(StaticAccess.KEY_PLACE_ID_INTENT, -1) : -1;
    }

    private void callApi() {
        HashMap<String, String> params = Utilities.getInstance().getRequestParams();
        params.put("tourism_place_id", String.valueOf(placeID));
        new CommonController(activity).callApi(CommonController.REQUEST_RESTAURANTS_BY_PLACE_ID, params, true);
    }

    private void initUI() {
        searchView = (MaterialSearchView) findViewById(R.id.search_view);
        searchView.setOnQueryTextListener(onQueryTextListener);
        searchView.setOnSearchViewListener(searchViewListener);
        rvRestaurantList = findViewById(R.id.rvRestaurantList);
        swFood = findViewById(R.id.swFood);
        rvRestaurantList.setHasFixedSize(true);
        rvRestaurantList.setLayoutManager(new LinearLayoutManager(activity));
        swFood.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                callApi();
            }
        });
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle(getString(R.string.restaurant));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishTheActivity();
            }
        });
        ToolbarConfig.makeStatusBarTransparent(getWindow());

    }

    private void finishTheActivity() {
        finish();
    }

    boolean isInstanceFull = false;

    public void updateRestaurantsList(List<Restaurant> restaurantList) {
        this.mList = restaurantList;
        if (!isInstanceFull) {
            staticInstance.setRestaurantList(restaurantList);
            isInstanceFull = true;
        }
        adapter = new RestaurantsListAdapter(activity, restaurantList, this);
        rvRestaurantList.setAdapter(adapter);
        if (swFood.isRefreshing()){
            swFood.setRefreshing(false);
        }
    }

    public void showErrorMsg(String msg) {
        CustomToast.makeToastWarning(activity, msg);
        rvRestaurantList.setAdapter(new EmptyAdapter());
        if (swFood.isRefreshing()){
            swFood.setRefreshing(false);
        }
        //Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void restaurantClicked(Restaurant restaurant) {
        if (ConnectionChecker.isOnline(activity)) {
            Intent intent = new Intent(activity, RestaurantDetailActivity.class);
            intent.putExtra(StaticAccess.KEY_RESTAURANT_ID_INTENT, restaurant.getRestaurantId());
            intent.putExtra(StaticAccess.KEY_PLACE_ID_INTENT, placeID);
            startActivity(intent);
            finish();
        }else {
            CustomToast.makeToastWarning(activity,getString(R.string.no_internet_connection_found_n_check_your_connection));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        MenuItem item = menu.findItem(R.id.action_search);
        searchView.setMenuItem(item);
        return true;
    }

    public void visibleSearchBar() {
        searchView.setVisibility(View.VISIBLE);
    }

    public void makeSearchBarGone() {
        searchView.setVisibility(View.GONE);
    }

    MaterialSearchView.OnQueryTextListener onQueryTextListener = new MaterialSearchView.OnQueryTextListener() {
        @Override
        public boolean onQueryTextSubmit(String query) {
            searchInList(query);
            return false;
        }

        @Override
        public boolean onQueryTextChange(String newText) {
            searchInList(newText);
            return false;
        }
    };
    MaterialSearchView.SearchViewListener searchViewListener = new MaterialSearchView.SearchViewListener() {
        @Override
        public void onSearchViewShown() {

        }

        @Override
        public void onSearchViewClosed() {
            resetSearch();
        }
    };

    private void searchInList(String keyword) {
        if (TextUtils.isEmpty(keyword)) {
            updateRestaurantsList(staticInstance.getRestaurantList());
        } else {
            Log.e("keyword", keyword);
            filterList(keyword);
        }
    }

    public void resetSearch() {
        updateRestaurantsList(staticInstance.getRestaurantList());
    }

    ///// sumon work start here
    private List<Restaurant> mFilterList;
    StaticInstance staticInstance;

    /// actual filter method
    public void filterList(String charText) {
        if (charText.length() != 0 && staticInstance.getRestaurantList() != null && staticInstance.getRestaurantList().size() > 0) {
            List list = new ArrayList<>();
            ListIterator<Restaurant> itr = staticInstance.getRestaurantList().listIterator();
            while (itr.hasNext()) {
                Restaurant restaurant = itr.next();
                if (restaurant.getRestaurantName() != null) {
                    if (restaurant.getRestaurantName().toLowerCase().contains(charText.toLowerCase())) {
                        list.add(restaurant);
                    }
                }
            }
            if (mFilterList != null && mFilterList.size() > 0) {
                mFilterList.clear();
            }
            if (list.size() > 0) {
                mFilterList.addAll(list);
            }
        }
        updateRestaurantsList(mFilterList);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (staticInstance != null) {
            staticInstance.clearRestaurantList();
        }
    }
}
