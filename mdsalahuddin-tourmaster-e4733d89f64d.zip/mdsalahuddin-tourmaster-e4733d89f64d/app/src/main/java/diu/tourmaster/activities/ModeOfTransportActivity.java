package diu.tourmaster.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import diu.tourmaster.R;
import diu.tourmaster.utils.ToolbarConfig;

public class ModeOfTransportActivity extends BaseActivity implements View.OnClickListener {
    private ImageView ivSelectSource, ivSelectDestination;
    private TextView tvSourceLocation, tvDestinationLocation;
    private Button btnSearch;
    private TextView tvBusCount, tvAirCount, tvWaterCount, tvTrainCount;
    private LinearLayout lnBusCount, lnAirCount, lnWaterCount, lnTrainCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BaseActivity.setLocale(this);
        setContentView(R.layout.activity_mode_of_transport);
        initToolbar();
        initUI();
    }

    private void initUI() {
        ivSelectSource = findViewById(R.id.ivSelectSource);
        ivSelectDestination = findViewById(R.id.ivSelectDestination);
        tvSourceLocation = findViewById(R.id.tvSourceLocation);
        tvDestinationLocation = findViewById(R.id.tvDestinationLocation);
        btnSearch = findViewById(R.id.btnSearch);
        tvBusCount = findViewById(R.id.tvBusCount);
        tvAirCount = findViewById(R.id.tvAirCount);
        tvWaterCount = findViewById(R.id.tvWaterCount);
        tvTrainCount = findViewById(R.id.tvTrainCount);
        lnBusCount = findViewById(R.id.lnBusCount);
        lnAirCount = findViewById(R.id.lnAirCount);
        lnWaterCount = findViewById(R.id.lnWaterCount);
        lnTrainCount = findViewById(R.id.lnTrainCount);
    }

    private void initToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle(getString(R.string.mode_of_transport));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishTheActivity();
            }
        });
        ToolbarConfig.makeStatusBarTransparent(getWindow());

    }

    private void finishTheActivity() {
        finish();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ivSelectSource:
                break;
            case R.id.ivSelectDestination:
                break;
            case R.id.tvSourceLocation:
                break;
            case R.id.tvDestinationLocation:
                break;
            case R.id.btnSearch:
                break;
            case R.id.tvBusCount:
                break;
            case R.id.tvAirCount:
                break;
            case R.id.tvWaterCount:
                break;
            case R.id.tvTrainCount:
                break;
            case R.id.lnBusCount:
                break;
            case R.id.lnAirCount:
                break;
            case R.id.lnWaterCount:
                break;
            case R.id.lnTrainCount:
                break;
        }
    }
}
