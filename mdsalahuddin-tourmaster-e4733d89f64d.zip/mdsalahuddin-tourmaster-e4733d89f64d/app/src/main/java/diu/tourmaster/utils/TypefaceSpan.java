package diu.tourmaster.utils;

import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.TextPaint;
import android.text.style.MetricAffectingSpan;

/**
 * Created by tajmulalam on 2/2/18.
 */

public class TypefaceSpan extends MetricAffectingSpan {
    private final Typeface typeface;

    public TypefaceSpan(Typeface typeface) {
        this.typeface = typeface;
    }

    private static void apply(Paint paint, Typeface typeface) {
        paint.setTypeface(typeface);
    }

    @Override
    public void updateDrawState(TextPaint textPaint) {
        apply(textPaint, typeface);
    }

    @Override
    public void updateMeasureState(TextPaint textPaint) {
        apply(textPaint, typeface);
    }
}
