package diu.tourmaster.models;

/**
 * Created by tajmulalam on 1/12/18.
 */


public class Photos {

    private Integer photoId;
    private String photoPath;
    private String photoFor;
    private String caption;
    private Integer status;
    private String createdAt;

    public Integer getPhotoId() {
        return photoId;
    }

    public void setPhotoId(Integer photoId) {
        this.photoId = photoId;
    }

    public String getPhotoPath() {
        return photoPath;
    }

    public void setPhotoPath(String photoPath) {
        this.photoPath = photoPath;
    }

    public String getPhotoFor() {
        return photoFor;
    }

    public void setPhotoFor(String photoFor) {
        this.photoFor = photoFor;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }


}