package diu.tourmaster.adapters;

import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import diu.tourmaster.R;
import diu.tourmaster.models.Restaurant;
import diu.tourmaster.utils.Configs;
import diu.tourmaster.utils.StaticAccess;

/**
 * Created by tajmulalam on 1/12/18.
 */

public class RestaurantsListAdapter extends RecyclerView.Adapter<RestaurantsListAdapter.RestaurantsListViewHolder> {

    private Context mContext;
    private List<Restaurant> restaurantList;
    private RestaurantClickedListener restaurantClickedListener;

    public RestaurantsListAdapter(Context mContext, List<Restaurant> restaurantList, RestaurantClickedListener restaurantClickedListener) {
        this.mContext = mContext;
        this.restaurantList = restaurantList;
        this.restaurantClickedListener = restaurantClickedListener;
    }

    @Override
    public RestaurantsListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.place_list_custom_row, null);
        return new RestaurantsListViewHolder(view);
    }


    public void onBindViewHolder(RestaurantsListViewHolder holder, final int position) {
        String photoUrl = restaurantList.get(position).getPhotos() != null ? Configs.BASE_URL + restaurantList.get(position).getPhotos().getPhotoPath() : "";

        if (TextUtils.isEmpty(photoUrl)) {
            Picasso.with(mContext)
                    .load(R.drawable.placeholder)
                    .error(R.drawable.placeholder)
                    .into(holder.ivPlaceImage);
        } else {
            Picasso.with(mContext)
                    .load(photoUrl)
                    .error(R.drawable.placeholder)
                    .into(holder.ivPlaceImage);
        }
        holder.tvTitle.setText(restaurantList.get(position).getRestaurantName());
        holder.cvPlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                restaurantClickedListener.restaurantClicked(restaurantList.get(position));
            }
        });
        holder.tvTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                restaurantClickedListener.restaurantClicked(restaurantList.get(position));

            }
        });
        holder.ivPlaceImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                restaurantClickedListener.restaurantClicked(restaurantList.get(position));

            }
        });
    }

    @Override
    public int getItemCount() {
        return restaurantList.size() > 0 ? restaurantList.size() : 0;
    }

    public class RestaurantsListViewHolder extends RecyclerView.ViewHolder {
        private ImageView ivPlaceImage;
        private TextView tvTitle;
        private CardView cvPlace;

        public RestaurantsListViewHolder(View itemView) {
            super(itemView);
            ivPlaceImage = itemView.findViewById(R.id.ivPlaceImage);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            cvPlace = itemView.findViewById(R.id.cvPlace);
        }
    }

    public interface RestaurantClickedListener {
        void restaurantClicked(Restaurant restaurant);
    }
}
